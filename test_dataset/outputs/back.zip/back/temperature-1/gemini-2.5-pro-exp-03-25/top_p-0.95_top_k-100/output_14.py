import collections
import sys

# Set higher recursion depth limit for deep DFS cases, although unlikely needed for N, M <= 200
# sys.setrecursionlimit(200*200 + 10) # Increase recursion depth limit if needed

def solve():
    """
    Solves the Pacific Atlantic Water Flow problem.
    Contains the main logic and the test execution framework.
    """

    def pacificAtlantic(heights: list[list[int]]) -> list[list[int]]:
        """
        Finds cells from which water can flow to both Pacific and Atlantic oceans.

        Args:
            heights: An m x n integer matrix representing cell heights.

        Returns:
            A list of [row, col] coordinates of cells that can reach both oceans.
        """
        if not heights or not heights[0]:
            return []

        m, n = len(heights), len(heights[0])
        pacific_reachable = set()
        atlantic_reachable = set()
        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

        def dfs(r, c, reachable_set):
            """
            Performs Depth First Search starting from (r, c) to find all cells
            reachable based on the non-decreasing height condition (reverse flow).

            Args:
                r: Current row.
                c: Current column.
                reachable_set: The set (pacific_reachable or atlantic_reachable)
                               to add reachable cells to.
            """
            # Check if already visited for this ocean's traversal
            if (r, c) in reachable_set:
                return
            reachable_set.add((r, c))

            # Explore neighbors
            for dr, dc in directions:
                nr, nc = r + dr, c + dc
                # Check boundaries
                if 0 <= nr < m and 0 <= nc < n:
                    # Check reverse flow condition (can flow from neighbor to current cell)
                    # Also implicitly checks if neighbor was already visited by the recursive call's entry check
                    if heights[nr][nc] >= heights[r][c]:
                        dfs(nr, nc, reachable_set)

        # Start DFS from all Pacific border cells
        for r in range(m):
            dfs(r, 0, pacific_reachable)
        for c in range(n): # Start from c=0 to cover top row including (0,0)
            dfs(0, c, pacific_reachable) # DFS handles already visited cells

        # Start DFS from all Atlantic border cells
        for r in range(m):
            dfs(r, n - 1, atlantic_reachable)
        for c in range(n): # Start from c=0 to cover bottom row including (m-1, n-1)
            dfs(m - 1, c, atlantic_reachable) # DFS handles already visited cells


        # Find the intersection of the two sets
        common_cells = pacific_reachable.intersection(atlantic_reachable)

        # Convert the set of tuples to a list of lists and sort for consistent output
        result = sorted([list(cell) for cell in common_cells])

        return result

    # --- Test Harness ---
    test_cases = [
        {
            "input": [[1,2,2,3,5],[3,2,3,4,4],[2,4,5,3,1],[6,7,1,4,5],[5,1,1,2,4]],
            "expected": [[0,4],[1,3],[1,4],[2,2],[3,0],[3,1],[4,0]]
        },
        {
            "input": [[2,1],[1,2]],
            "expected": [[0,0],[0,1],[1,0],[1,1]]
        },
        {
            "input": [[1]],
            "expected": [[0,0]]
        },
         {
            "input": [[]],
            "expected": []
        },
        {
            "input": [[1,1],[1,1]],
            "expected": [[0,0],[0,1],[1,0],[1,1]]
        },
        {
            "input": [[3,3,3],[3,0,3],[3,3,3]],
             # Cells that can reach Pacific: all
             # Cells that can reach Atlantic: all except (1,1)
             # Intersection: all except (1,1)
            "expected": [[0,0],[0,1],[0,2],[1,0],[1,2],[2,0],[2,1],[2,2]]
        },
        {
             "input": [[10,10,10],[10,1,10],[10,10,10]],
             # Pacific reachable: all border cells + (1,0), (0,1), (2,1), (1,2)
             # Atlantic reachable: all border cells + (1,0), (0,1), (2,1), (1,2)
             # Intersection: All border cells + neighbors = all cells except (1,1)
             "expected": [[0,0],[0,1],[0,2],[1,0],[1,2],[2,0],[2,1],[2,2]]
         }
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, test in enumerate(test_cases):
        heights_input = test["input"]
        expected_output = test["expected"]

        # Sort expected output for consistent comparison
        expected_output.sort()

        # Run the student's function
        try:
            actual_output = pacificAtlantic(heights_input)
            # Sort actual output for consistent comparison
            actual_output.sort()

            # Compare actual vs expected
            if actual_output == expected_output:
                print(f"Test {i+1}: True")
                correct_count += 1
            else:
                print(f"Test {i+1}: False")
                # print(f"  Input: {heights_input}")
                # print(f"  Expected: {expected_output}")
                # print(f"  Actual: {actual_output}")
        except Exception as e:
            print(f"Test {i+1}: False (Error: {e})")
            # import traceback
            # traceback.print_exc()


    print(f"{correct_count}/{total_tests} tests passed.")

# Execute the solve function containing the implementation and tests
solve()