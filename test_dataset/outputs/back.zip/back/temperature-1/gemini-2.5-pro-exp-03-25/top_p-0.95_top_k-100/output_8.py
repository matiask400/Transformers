import sys
import io

def solve():
    """
    Solves the Move Zeroes problem. Implements the core logic and the testing harness.
    """

    def moveZeroes(nums: list[int]) -> None:
        """
        Moves all 0's to the end of the list in-place while maintaining the
        relative order of the non-zero elements.

        Args:
            nums: The list of integers to modify.
        """
        # write_idx keeps track of the position where the next non-zero element should be placed.
        write_idx = 0
        n = len(nums)

        # Iterate through the array with read_idx
        for read_idx in range(n):
            # If the current element is non-zero
            if nums[read_idx] != 0:
                # If the read pointer is ahead of the write pointer,
                # it means we have encountered zeros and need to swap
                # the current non-zero element into the write position.
                # If read_idx == write_idx, the non-zero element is already
                # in its correct relative place, so we just advance write_idx.
                if read_idx != write_idx:
                    nums[write_idx], nums[read_idx] = nums[read_idx], nums[write_idx]
                # Move the write pointer forward to the next position
                # for a non-zero element.
                write_idx += 1

        # The elements from write_idx onwards are implicitly the zeros
        # that were swapped to the end or were already there past the last non-zero element.
        # No explicit filling of zeros is needed with this swap approach.


    # --- Testing Harness ---
    test_cases = [
        {'input': ([0, 1, 0, 3, 12],), 'expected': [1, 3, 12, 0, 0]},
        {'input': ([0],), 'expected': [0]},
        {'input': ([1],), 'expected': [1]},
        {'input': ([1, 2, 3],), 'expected': [1, 2, 3]},
        {'input': ([0, 0, 0],), 'expected': [0, 0, 0]},
        {'input': ([1, 0, 2, 0, 3],), 'expected': [1, 2, 3, 0, 0]},
        {'input': ([-1, 0, 5, 0, -10, 0],), 'expected': [-1, 5, -10, 0, 0, 0]},
        {'input': ([2, 1],), 'expected': [2, 1]},
        {'input': ([0,0,0,0,1],), 'expected': [1,0,0,0,0]},
    ]

    correct_count = 0
    total_tests = len(test_cases)

    # Capture stdout for cleaner output
    original_stdout = sys.stdout
    string_io = io.StringIO()
    # sys.stdout = string_io # Redirect stdout if needed, but direct print is fine for this format

    for i, test in enumerate(test_cases):
        input_args = test['input']
        expected_output = test['expected']

        # The function modifies the list in-place, so we need to pass a copy
        # if we want to compare against the original input later or avoid
        # test interference. For comparing the *result*, we compare the modified list.
        nums_copy = list(input_args[0]) # Make a copy of the input list

        # Run the function (it modifies nums_copy in-place)
        moveZeroes(nums_copy)
        actual_output = nums_copy # The result is the modified list itself

        # Compare the modified list with the expected list
        if actual_output == expected_output:
            print(f"True")
            correct_count += 1
        else:
            # print(f"Test Case {i+1} Failed:")
            # print(f"  Input: {input_args[0]}")
            # print(f"  Expected Output: {expected_output}")
            # print(f"  Actual Output: {actual_output}")
            print(f"False")

    # Restore stdout
    # sys.stdout = original_stdout
    # captured_output = string_io.getvalue()
    # print(captured_output) # Print captured output if redirection was used

    print(f"{correct_count}/{total_tests}")

# Execute the solver function containing the implementation and tests
if __name__ == "__main__":
    solve()