from functools import reduce
import operator

def xorGame(nums):
    xor_sum = reduce(operator.xor, nums, 0)
    return xor_sum == 0 or len(nums) % 2 == 0

def run_tests():
    test_cases = [
        {"nums": [1, 1, 2], "expected": False},
        {"nums": [1, 2, 3], "expected": True},
        {"nums": [2, 2, 2], "expected": False},
        {"nums": [1, 2, 4], "expected": False},
        {"nums": [0], "expected": True},
        {"nums": [1], "expected": False},
        {"nums": [0, 0], "expected": True},
        {"nums": [1, 0], "expected": True},
        {"nums": [2, 3, 4, 5], "expected": True},
        {"nums": [2, 3, 4], "expected": False},
        {"nums": [0, 0, 0], "expected": True},
        {"nums": [0, 0, 1], "expected": False},
        {"nums": [1, 1, 1, 1], "expected": True},
        {"nums": [1, 1, 1, 2], "expected": True},
        {"nums": [1, 1, 1, 1, 1], "expected": False}
    ]
    
    correct_count = 0
    total_count = len(test_cases)
    
    for i, case in enumerate(test_cases):
        nums = case["nums"]
        expected_output = case["expected"]
        actual_output = xorGame(nums)
        if actual_output == expected_output:
            print(f"Test case {i+1}: True")
            correct_count += 1
        else:
            print(f"Test case {i+1}: False (Input: {nums}, Expected: {expected_output}, Actual: {actual_output})")
            
    print(f"\n{correct_count} correct out of {total_count}")

if __name__ == '__main__':
    run_tests()