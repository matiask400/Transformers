def maxIncreaseKeepingSkyline(grid):
    rows = len(grid)
    cols = len(grid[0])
    tb_skyline = [0] * cols
    lr_skyline = [0] * rows

    for j in range(cols):
        max_height = 0
        for i in range(rows):
            max_height = max(max_height, grid[i][j])
        tb_skyline[j] = max_height

    for i in range(rows):
        max_height = 0
        for j in range(cols):
            max_height = max(max_height, grid[i][j])
        lr_skyline[i] = max_height

    new_grid = [[0] * cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            new_grid[i][j] = min(tb_skyline[j], lr_skyline[i])

    original_sum = sum(sum(row) for row in grid)
    new_sum = sum(sum(row) for row in new_grid)
    return new_sum - original_sum

def run_tests():
    test_cases = [
        {
            "grid": [[3,0,8,4],[2,4,5,7],[9,2,6,3],[0,3,1,0]],
            "expected_output": 35
        },
        {
            "grid": [[0,0,0],[0,0,0],[0,0,0]],
            "expected_output": 0
        },
        {
            "grid": [[1]],
            "expected_output": 0
        },
        {
            "grid": [[1,2],[3,4]],
            "expected_output": 0
        },
        {
            "grid": [[1,2,3],[4,5,6],[7,8,9]],
            "expected_output": 0
        },
        {
            "grid": [[5,5],[5,5]],
            "expected_output": 0
        },
        {
            "grid": [[1,0],[0,1]],
            "expected_output": 2
        },
        {
            "grid": [[1,1],[0,0]],
            "expected_output": 1
        }
    ]

    num_correct = 0
    for i, case in enumerate(test_cases):
        grid = case["grid"]
        expected_output = case["expected_output"]
        actual_output = maxIncreaseKeepingSkyline(grid)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {grid}")
            print(f"  Expected Output: {expected_output}")
            print(f"  Actual Output: {actual_output}")

    print(f"\nCorrect tests: {num_correct}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()