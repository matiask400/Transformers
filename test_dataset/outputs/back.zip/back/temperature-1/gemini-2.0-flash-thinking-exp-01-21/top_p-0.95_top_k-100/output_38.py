class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def list_to_tree(lst):
    if not lst:
        return None
    root = TreeNode(lst[0])
    queue = [root]
    i = 1
    while i < len(lst):
        current_node = queue.pop(0)
        if i < len(lst) and lst[i] is not None:
            current_node.left = TreeNode(lst[i])
            queue.append(current_node.left)
        i += 1
        if i < len(lst) and lst[i] is not None:
            current_node.right = TreeNode(lst[i])
            queue.append(current_node.right)
        i += 1
    return root

def tree_to_list(root):
    if not root:
        return []
    result = []
    queue = [root]
    while queue:
        current_node = queue.pop(0)
        if current_node:
            result.append(current_node.val)
            queue.append(current_node.left)
            queue.append(current_node.right)
        else:
            result.append(None)

    while result and result[-1] is None:
        result.pop()
    return result

def containsOne(node):
    if not node:
        return False
    if node.val == 1:
        return True
    return containsOne(node.left) or containsOne(node.right)

def pruneTree(root):
    if not root:
        return None
    root.left = pruneTree(root.left)
    root.right = pruneTree(root.right)
    if not containsOne(root):
        return None
    return root

def solve():
    test_cases = [
        ([1, None, 0, 0, 1], [1, None, 0, None, 1]),
        ([1, 0, 1, 0, 0, 0, 1], [1, None, 1, None, 1]),
        ([1, 1, 0, 1, 1, 0, 1, 0], [1, 1, 0, 1, 1, None, 1])
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for input_tree_list, expected_output_list in test_cases:
        root = list_to_tree(input_tree_list)
        pruned_root = pruneTree(root)
        output_list = tree_to_list(pruned_root)

        if output_list == expected_output_list:
            print('True')
            correct_tests += 1
        else:
            print('False')

    print(f"{correct_tests}/{total_tests}")

if __name__ == '__main__':
    solve()