def solve():
    def largest_component_size(A):
        n = len(A)
        parent = list(range(n))
        size = [1] * n

        def find(i):
            if parent[i] == i:
                return i
            parent[i] = find(parent[i])
            return parent[i]

        def union(i, j):
            root_i = find(i)
            root_j = find(j)
            if root_i != root_j:
                if size[root_i] < size[root_j]:
                    root_i, root_j = root_j, root_i
                parent[root_j] = root_i
                size[root_i] += size[root_j]
                return True
            return False

        def get_prime_factors(num):
            factors = set()
            d = 2
            temp_num = num
            while d * d <= temp_num:
                if temp_num % d == 0:
                    factors.add(d)
                    while temp_num % d == 0:
                        temp_num //= d
                d += 1
            if temp_num > 1:
                factors.add(temp_num)
            return factors

        num_to_index = {num: index for index, num in enumerate(A)}

        for i in range(n):
            factors = get_prime_factors(A[i])
            for factor in factors:
                for j in range(i + 1, n):
                    if A[j] % factor == 0:
                        union(i, j)

        max_size = 0
        for s in size:
            max_size = max(max_size, s)
        return max_size

    test_cases = [
        ([4, 6, 15, 35], 4),
        ([20, 50, 9, 63], 2),
        ([2, 3, 6, 7, 4, 12, 21, 39], 8),
        ([1], 1),
        ([2, 3], 1),
        ([6, 7], 1),
        ([2, 4], 2),
        ([6, 10], 2),
        ([2, 3, 4, 5, 6, 7], 4),
        ([2, 3, 4, 5, 6, 7, 8, 9, 10], 7)

    ]

    correct_count = 0
    for input_array, expected_output in test_cases:
        output = largest_component_size(input_array)
        if output == expected_output:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{len(test_cases)}")

solve()