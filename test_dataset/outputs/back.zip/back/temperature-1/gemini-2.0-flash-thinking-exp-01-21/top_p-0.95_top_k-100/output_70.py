def solve():
    def test_function(func, test_cases):
        correct_count = 0
        total_count = len(test_cases)
        for input_val, expected_output in test_cases:
            try:
                output = func(input_val)
                if output == expected_output:
                    print('True')
                    correct_count += 1
                else:
                    print('False')
            except Exception as e:
                print('False')
        print(f'{correct_count}/{total_count}')

    # Example function to be tested (replace with your actual function)
    def example_function(input_str):
        parts = input_str.split()
        if len(parts) != 2:
            return "Invalid Input"
        try:
            a = int(parts[0])
            b = int(parts[1])
            return a + b
        except ValueError:
            return "Invalid Input"

    # Example test cases (replace with your actual test cases)
    test_cases = [
        ("1 2", 3),
        ("5 5", 10),
        ("-1 1", 0),
        ("0 0", 0),
        ("10 -5", 5),
        ("abc 2", "Invalid Input"),
        ("1 abc", "Invalid Input"),
        ("abc def", "Invalid Input"),
        ("1", "Invalid Input"),
        ("1 2 3", "Invalid Input"),
        ("  1   2  ", "Invalid Input"), # Expect "Invalid Input" because of split() behavior, if intended to handle extra spaces, need to trim/clean input in function
        ("   1 2", "Invalid Input"),
        ("1 2   ", "Invalid Input"),
    ]

    test_function(example_function, test_cases)

solve()