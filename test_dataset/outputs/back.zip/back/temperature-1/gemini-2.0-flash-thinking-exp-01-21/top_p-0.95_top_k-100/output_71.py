def solve():
    def can_reorder(arr):
        if len(arr) % 2 != 0:
            return False
        counts = {}
        for x in arr:
            counts[x] = counts.get(x, 0) + 1
        unique_nums = sorted(list(counts.keys()))

        for x in unique_nums:
            while counts.get(x, 0) > 0:
                y = 2 * x
                if counts.get(y, 0) == 0:
                    return False
                counts[x] -= 1
                counts[y] -= 1
        return True

    test_cases = [
        ([3, 1, 3, 6], False),
        ([2, 1, 2, 6], False),
        ([4, -2, 2, -4], True),
        ([1, 2, 4, 16, 8, 4], False),
        ([0, 0], True),