class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def build_bst(nodes):
    if not nodes:
        return None
    root = TreeNode(nodes[0])
    for i in range(1, len(nodes)):
        insert_node(root, nodes[i])
    return root

def insert_node(root, val):
    if not root:
        return TreeNode(val)
    if val < root.val:
        if root.left:
            insert_node(root.left, val)
        else:
            root.left = TreeNode(val)
    else:
        if root.right:
            insert_node(root.right, val)
        else:
            root.right = TreeNode(val)

def find_closest_k_values(root, target, k):
    def inorder_traversal(node, values):
        if not node:
            return
        inorder_traversal(node.left, values)
        values.append(node.val)
        inorder_traversal(node.right, values)

    values = []
    inorder_traversal(root, values)

    values.sort(key=lambda x: abs(x - target))
    return values[:k]

def run_tests():
    test_cases = [
        {
            "root": [4, 2, 5, 1, 3],
            "target": 3.714286,
            "k": 2,
            "expected": [4, 3]
        },
        {
            "root": [1],
            "target": 0.000000,
            "k": 1,
            "expected": [1]
        },
        {
            "root": [4,2,5,1,3],
            "target": 3,
            "k": 2,
            "expected": [3, 2]
        },
        {
            "root": [10,5,15,3,7,13,18,1,null,6,8,11,14,16,20],
            "target": 12.5,
            "k": 3,
            "expected": [13, 11, 14]
        },
        {
            "root": [4,2,5,1,3],
            "target": 6,
            "k": 2,
            "expected": [5, 4]
        }
    ]

    correct_tests = 0
    for i, test_case in enumerate(test_cases):
        root_nodes = test_case["root"]
        target = test_case["target"]
        k = test_case["k"]
        expected = sorted(test_case["expected"])

        root_bst = None
        if root_nodes and root_nodes[0] is not None:
            root_bst = TreeNode(root_nodes[0])
            queue = [root_bst]
            node_index = 1
            while queue and node_index < len(root_nodes):
                current_node = queue.pop(0)
                if root_nodes[node_index] is not None:
                    current_node.left = TreeNode(root_nodes[node_index])
                    queue.append(current_node.left)
                node_index += 1
                if node_index < len(root_nodes) and root_nodes[node_index] is not None:
                    current_node.right = TreeNode(root_nodes[node_index])
                    queue.append(current_node.right)
                node_index += 1

        if root_bst is None and root_nodes and root_nodes[0] is not None: # handle single node list input format for build_bst
            root_bst = build_bst(root_nodes)
        elif root_bst is None and root_nodes is None or (root_nodes and root_nodes[0] is None):
            pass # handle empty tree if needed

        actual = sorted(find_closest_k_values(root_bst, target, k))

        if actual == expected:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Expected: {expected}")
            print(f"  Actual:   {actual}")

    print(f"\nCorrect tests: {correct_tests}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()