def evaluate_rpn(tokens):
    stack = []
    for token in tokens:
        if token.isdigit() or (token.startswith('-') and token[1:].isdigit()):
            stack.append(int(token))
        else:
            operand2 = stack.pop()
            operand1 = stack.pop()
            if token == '+':
                result = operand1 + operand2
            elif token == '-':
                result = operand1 - operand2
            elif token == '*':
                result = operand1 * operand2
            elif token == '/':
                result = int(operand1 / operand2)
            stack.append(result)
    return stack[0]

def test_evaluate_rpn():
    test_cases = [
        (["2","1","+","3","*"], 9),
        (["4","13","5","/","+"], 6),
        (["10","6","9","3","+","-11","*","/","*","17","+","5","+"], 22),
        (["18"], 18),
        (["-1", "-1", "+"], -2),
        (["-3", "3", "/"], -1),
        (["3", "-3", "/"], -1),
        (["10", "0", "/"], 0),
        (["-10", "3", "/"], -3)
    ]
    correct_count = 0
    for tokens, expected_output in test_cases:
        actual_output = evaluate_rpn(tokens)
        if actual_output == expected_output:
            print('True')
            correct_count += 1
        else:
            print('False')
    print(f'{correct_count}/{len(test_cases)}')

if __name__ == '__main__':
    test_evaluate_rpn()