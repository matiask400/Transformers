def eraseOverlapIntervals(intervals):
    if not intervals:
        return 0
    intervals.sort(key=lambda x: x[1])
    count = 1
    end = intervals[0][1]
    for i in range(1, len(intervals)):
        if intervals[i][0] >= end:
            count += 1
            end = intervals[i][1]
    return len(intervals) - count

def run_tests():
    test_cases = [
        ([[1,2],[2,3],[3,4],[1,3]], 1),
        ([[1,2],[1,2],[1,2]], 2),
        ([[1,2],[2,3]], 0),
        ([], 0),
        ([[1,10],[2,3],[3,4],[4,5]], 1),
        ([[1,4],[0,2],[3,6]], 1),
    ]
    correct_tests = 0
    for i, (input_intervals, expected_output) in enumerate(test_cases):
        output = eraseOverlapIntervals(input_intervals)
        if output == expected_output:
            print(f'Test {i+1}: True')
            correct_tests += 1
        else:
            print(f'Test {i+1}: False')
    print(f'{correct_tests}/{len(test_cases)}')

if __name__ == '__main__':
    run_tests()