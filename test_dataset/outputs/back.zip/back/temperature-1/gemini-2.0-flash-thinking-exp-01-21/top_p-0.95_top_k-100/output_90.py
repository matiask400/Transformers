import sqlite3

def execute_query(conn, query):
    """Executes an SQL query and returns the result."""
    cursor = conn.cursor()
    cursor.execute(query)
    return cursor.fetchall()

def compare_output(actual_output, expected_output):
    """Compares the actual output with the expected output."""
    if set(actual_output) == set(expected_output): # Use set for unordered comparison
        return True
    else:
        return False

def test_sql_query(db_name, create_table_sql, insert_data_sql, query_sql, expected_output):
    """Tests an SQL query against expected output."""
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()

    try:
        cursor.executescript(create_table_sql)
        for insert_sql in insert_data_sql:
            cursor.execute(insert_sql)
        conn.commit()

        actual_output = execute_query(conn, query_sql)
        test_passed = compare_output(actual_output, expected_output)

    except sqlite3.Error as e:
        print(f"Database error: {e}")
        test_passed = False
    finally:
        conn.close()

    return test_passed

def run_tests():
    """Runs all test cases and prints the results."""
    tests = []

    # Test Case 1: Basic join and filter
    tests.append({
        'db_name': ':memory:',
        'create_table_sql': """
            CREATE TABLE Employees (
                employee_id INTEGER PRIMARY KEY,
                name VARCHAR(50),
                department VARCHAR(50)
            );

            CREATE TABLE Salaries (
                salary_id INTEGER PRIMARY KEY,
                employee_id INTEGER,
                salary INTEGER,
                FOREIGN KEY (employee_id) REFERENCES Employees(employee_id)
            );
        """,
        'insert_data_sql': [
            "INSERT INTO Employees (employee_id, name, department) VALUES (1, 'Alice', 'Sales');",
            "INSERT INTO Employees (employee_id, name, department) VALUES (2, 'Bob', 'Marketing');",
            "INSERT INTO Employees (employee_id, name, department) VALUES (3, 'Charlie', 'Sales');",
            "INSERT INTO Salaries (salary_id, employee_id, salary) VALUES (1, 1, 60000);",
            "INSERT INTO Salaries (salary_id, employee_id, salary) VALUES (2, 2, 70000);",
            "INSERT INTO Salaries (salary_id, employee_id, salary) VALUES (3, 3, 80000);"
        ],
        'query_sql': "SELECT e.name FROM Employees e JOIN Salaries s ON e.employee_id = s.employee_id WHERE s.salary > 65000;",
        'expected_output': [('Bob',), ('Charlie',)]
    })

    # Test Case 2: No matching records
    tests.append({
        'db_name': ':memory:',
        'create_table_sql': """
            CREATE TABLE Products (
                product_id INTEGER PRIMARY KEY,
                name VARCHAR(50),
                price DECIMAL(10, 2)
            );
        """,
        'insert_data_sql': [
            "INSERT INTO Products (product_id, name, price) VALUES (1, 'Laptop', 1200.00);",
            "INSERT INTO Products (product_id, name, price) VALUES (2, 'Mouse', 25.00);"
        ],
        'query_sql': "SELECT name FROM Products WHERE price > 2000;",
        'expected_output': []
    })

    # Test Case 3: Select all records from a table
    tests.append({
        'db_name': ':memory:',
        'create_table_sql': """
            CREATE TABLE Departments (
                dept_id INTEGER PRIMARY KEY,
                dept_name VARCHAR(50)
            );
        """,
        'insert_data_sql': [
            "INSERT INTO Departments (dept_id, dept_name) VALUES (1, 'HR');",
            "INSERT INTO Departments (dept_id, dept_name) VALUES (2, 'IT');"
        ],
        'query_sql': "SELECT dept_name FROM Departments;",
        'expected_output': [('HR',), ('IT',)]
    })

    # Test Case 4: Order By clause
    tests.append({
        'db_name': ':memory:',
        'create_table_sql': """
            CREATE TABLE Students (
                student_id INTEGER PRIMARY KEY,
                name VARCHAR(50),
                grade INTEGER
            );
        """,
        'insert_data_sql': [
            "INSERT INTO Students (student_id, name, grade) VALUES (1, 'Alice', 85);",
            "INSERT INTO Students (student_id, name, grade) VALUES (2, 'Bob', 90);",
            "INSERT INTO Students (student_id, name, grade) VALUES (3, 'Charlie', 78);"
        ],
        'query_sql': "SELECT name FROM Students ORDER BY grade DESC;",
        'expected_output': [('Bob',), ('Alice',), ('Charlie',)]
    })

    # Test Case 5: Empty Table
    tests.append({
        'db_name': ':memory:',
        'create_table_sql': """
            CREATE TABLE EmptyTable (
                id INTEGER PRIMARY KEY,
                value VARCHAR(50)
            );
        """,
        'insert_data_sql': [],
        'query_sql': "SELECT * FROM EmptyTable;",
        'expected_output': []
    })


    correct_tests = 0
    total_tests = len(tests)

    for i, test_case in enumerate(tests):
        print(f"Test Case {i+1}: ", end="")
        if test_sql_query(**test_case):
            print("True")
            correct_tests += 1
        else:
            print("False")

    print(f"\n{correct_tests} correct tests out of {total_tests}")

if __name__ == '__main__':
    run_tests()