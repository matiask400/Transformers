def solve():
    def calculate_money(n):
        full_weeks = n // 7
        remaining_days = n % 7
        total_amount = 0

        for week_num in range(1, full_weeks + 1):
            start_amount = week_num
            for day_offset in range(7):
                total_amount += start_amount + day_offset

        if remaining_days > 0:
            start_amount = full_weeks + 1
            for day_offset in range(remaining_days):
                total_amount += start_amount + day_offset
        return total_amount

    test_cases = [
        (4, 10),
        (10, 37),
        (20, 96),
        (1, 1),
        (7, 28),
        (8, 30),
        (14, 56),
        (15, 59),
        (21, 84),
        (22, 88),
        (28, 112),
        (29, 117),
        (30, 123),
        (31, 129),
        (32, 135),
        (33, 141),
        (34, 147),
        (35, 154),
        (36, 161),
        (37, 168),
        (38, 175),
        (39, 182),
        (40, 189),
        (41, 196),
        (42, 203),
        (43, 211),
        (44, 219),
        (45, 227),
        (46, 235),
        (47, 243),
        (48, 251),
        (49, 259),
        (50, 267),
        (100, 545),
        (1000, 49555)
    ]

    correct_count = 0
    for input_n, expected_output in test_cases:
        actual_output = calculate_money(input_n)
        if actual_output == expected_output:
            print('True')
            correct_count += 1
        else:
            print('False')
    print(f'{correct_count}/{len(test_cases)}')

solve()