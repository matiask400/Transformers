def find_peak_element_linear(nums):
    n = len(nums)
    if n == 1:
        return 0
    for i in range(n):
        if i == 0:
            if nums[i] > nums[i + 1]:
                return i
        elif i == n - 1:
            if nums[i] > nums[i - 1]:
                return i
        else:
            if nums[i] > nums[i - 1] and nums[i] > nums[i + 1]:
                return i
    return -1 # Should not reach here as peak is guaranteed to exist

def find_peak_element_binary(nums):
    left, right = 0, len(nums) - 1
    while left < right:
        mid = (left + right) // 2
        if nums[mid] < nums[mid + 1]:
            left = mid + 1
        else:
            right = mid
    return left

def test_find_peak_element():
    test_cases = [
        ([1, 2, 3, 1], [2]),
        ([1, 2, 1, 3, 5, 6, 4], [1, 5]),
        ([1], [0]),
        ([1, 2], [1]),
        ([2, 1], [0]),
        ([1,2,3,4,5], [4]),
        ([5,4,3,2,1], [0]),
        ([3,2,3,4,5], [4]),
        ([5,4,5,4,3], [0, 2]),
    ]
    linear_correct_count = 0
    binary_correct_count = 0
    total_tests = len(test_cases)

    print("Linear Search Tests:")
    for i, (nums, expected_outputs) in enumerate(test_cases):
        linear_output_index = find_peak_element_linear(nums)
        linear_output = -1
        if linear_output_index != -1:
            linear_output = nums[linear_output_index]

        if linear_output_index != -1 and linear_output_index in expected_outputs or (linear_output_index != -1 and linear_output_index in expected_outputs) :
             if linear_output_index in expected_outputs or (linear_output_index in expected_outputs and linear_output in [nums[idx] for idx in expected_outputs]):
                print(f"Test {i+1}: True")
                linear_correct_count += 1
             else:
                print(f"Test {i+1}: False")
        else:
             print(f"Test {i+1}: False")


    print(f"Linear Correct: {linear_correct_count}/{total_tests}")

    print("\nBinary Search Tests:")
    for i, (nums, expected_outputs) in enumerate(test_cases):
        binary_output_index = find_peak_element_binary(nums)
        binary_output = -1
        if binary_output_index != -1:
            binary_output = nums[binary_output_index]

        if binary_output_index != -1 and binary_output_index in expected_outputs or (binary_output_index != -1 and binary_output_index in expected_outputs) :
             if binary_output_index in expected_outputs or (binary_output_index in expected_outputs and binary_output in [nums[idx] for idx in expected_outputs]):
                print(f"Test {i+1}: True")
                binary_correct_count += 1
             else:
                print(f"Test {i+1}: False")
        else:
             print(f"Test {i+1}: False")


    print(f"Binary Correct: {binary_correct_count}/{total_tests}")


test_find_peak_element()