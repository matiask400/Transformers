def isPrefixOfWord(sentence: str, searchWord: str) -> int:
    words = sentence.split(" ")
    for index, word in enumerate(words):
        if word.startswith(searchWord):
            return index + 1
    return -1

def run_tests():
    test_cases = [
        {"sentence": "i love eating burger", "searchWord": "burg", "expected": 4},
        {"sentence": "this problem is an easy problem", "searchWord": "pro", "expected": 2},
        {"sentence": "i am tired", "searchWord": "you", "expected": -1},
        {"sentence": "i use triple pillow", "searchWord": "pill", "expected": 4},
        {"sentence": "hello from the other side", "searchWord": "they", "expected": -1},
        {"sentence": "hellohello", "searchWord": "ell", "expected": 1},
        {"sentence": "hello hello", "searchWord": "hel", "expected": 1},
        {"sentence": "a b c d", "searchWord": "b", "expected": 2},
        {"sentence": "a b c d", "searchWord": "e", "expected": -1},
        {"sentence": "ab cd ef", "searchWord": "ab", "expected": 1},
        {"sentence": "ab cd ef", "searchWord": "cd", "expected": 2},
        {"sentence": "ab cd ef", "searchWord": "ef", "expected": 3},
        {"sentence": "ab cd ef", "searchWord": "a", "expected": 1},
        {"sentence": "ab cd ef", "searchWord": "c", "expected": 2},
        {"sentence": "ab cd ef", "searchWord": "e", "expected": 3},
        {"sentence": "ab cd ef", "searchWord": "abc", "expected": -1},
        {"sentence": "ab cd ef", "searchWord": "cde", "expected": -1},
        {"sentence": "ab cd ef", "searchWord": "efg", "expected": -1},
    ]

    correct_count = 0
    for i, test_case in enumerate(test_cases):
        sentence = test_case["sentence"]
        searchWord = test_case["searchWord"]
        expected = test_case["expected"]
        actual = isPrefixOfWord(sentence, searchWord)
        if actual == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False, Input: sentence='{sentence}', searchWord='{searchWord}', Expected: {expected}, Actual: {actual}")

    print(f"\n{correct_count}/{len(test_cases)}")

if __name__ == "__main__":
    run_tests()