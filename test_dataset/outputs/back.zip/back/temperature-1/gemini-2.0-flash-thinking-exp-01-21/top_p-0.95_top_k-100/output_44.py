def is_palindrome(s):
    return s == s[::-1]

def min_steps_to_empty(s):
    if not s:
        return 0
    if is_palindrome(s):
        return 1
    else:
        return 2

def run_tests():
    tests = [
        {"input": "ababa", "expected": 1},
        {"input": "abb", "expected": 2},
        {"input": "baabb", "expected": 2},
        {"input": "a", "expected": 1},
        {"input": "b", "expected": 1},
        {"input": "aa", "expected": 1},
        {"input": "bb", "expected": 1},
        {"input": "aba", "expected": 1},
        {"input": "bab", "expected": 1},
        {"input": "abc", "expected": 2}, # Although constraint is 'a' and 'b' only, for robustness
        {"input": "abca", "expected": 2}, # Although constraint is 'a' and 'b' only, for robustness
        {"input": "abcb", "expected": 2}, # Although constraint is 'a' and 'b' only, for robustness
        {"input": "abbba", "expected": 1},
        {"input": "abbb", "expected": 2},
        {"input": "baaa", "expected": 2},
        {"input": "aaaa", "expected": 1},
        {"input": "bbbb", "expected": 1},
        {"input": "aabb", "expected": 2},
        {"input": "abba", "expected": 1},
    ]

    correct_count = 0
    for i, test in enumerate(tests):
        input_s = test["input"]
        expected_output = test["expected"]
        actual_output = min_steps_to_empty(input_s)
        if actual_output == expected_output:
            print(True)
            correct_count += 1
        else:
            print(False)
        # print(f"Test {i+1}: Input: '{input_s}', Expected: {expected_output}, Actual: {actual_output}, Result: {'True' if actual_output == expected_output else 'False'}")

    print(f"{correct_count}/{len(tests)}")

if __name__ == '__main__':
    run_tests()