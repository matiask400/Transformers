def is_prime(n):
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

def count_set_bits(n):
    count = 0
    while n > 0:
        n &= (n - 1)
        count += 1
    return count

def count_prime_set_bits(L, R):
    count = 0
    for num in range(L, R + 1):
        set_bits = count_set_bits(num)
        if is_prime(set_bits):
            count += 1
    return count

def run_tests():
    test_cases = [
        {"input": {"L": 6, "R": 10}, "expected_output": 4},
        {"input": {"L": 10, "R": 15}, "expected_output": 5},
        {"input": {"L": 1, "R": 1}, "expected_output": 0},
        {"input": {"L": 2, "R": 2}, "expected_output": 1},
        {"input": {"L": 3, "R": 3}, "expected_output": 1},
        {"input": {"L": 4, "R": 4}, "expected_output": 0},
        {"input": {"L": 5, "R": 5}, "expected_output": 1},
        {"input": {"L": 0, "R": 0}, "expected_output": 0},
        {"input": {"L": 1, "R": 6}, "expected_output": 3},
        {"input": {"L": 1, "R": 32}, "expected_output": 13},
        {"input": {"L": 1, "R": 64}, "expected_output": 20},
        {"input": {"L": 990, "R": 1000}, "expected_output": 4}
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        input_data = test_case["input"]
        expected_output = test_case["expected_output"]
        actual_output = count_prime_set_bits(input_data["L"], input_data["R"])

        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"{correct_tests}/{total_tests}")

if __name__ == '__main__':
    run_tests()