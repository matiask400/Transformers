def nextGreaterElement(nums1, nums2):
    """
    Finds the next greater numbers for nums1's elements in nums2.

    Args:
        nums1: An integer array (subset of nums2) with unique elements.
        nums2: An integer array with unique elements.

    Returns:
        A list of next greater numbers for each element in nums1.
    """
    result = []
    for n1 in nums1:
        n1_index_in_nums2 = -1
        for i in range(len(nums2)):
            if nums2[i] == n1:
                n1_index_in_nums2 = i
                break

        next_greater = -1
        for j in range(n1_index_in_nums2 + 1, len(nums2)):
            if nums2[j] > n1:
                next_greater = nums2[j]
                break
        result.append(next_greater)
    return result

def run_tests():
    tests = [
        {
            "nums1": [4, 1, 2],
            "nums2": [1, 3, 4, 2],
            "expected": [-1, 3, -1]
        },
        {
            "nums1": [2, 4],
            "nums2": [1, 2, 3, 4],
            "expected": [3, -1]
        },
        {
            "nums1": [1],
            "nums2": [1],
            "expected": [-1]
        },
        {
            "nums1": [3],
            "nums2": [1, 2, 3, 4],
            "expected": [-1]
        },
        {
            "nums1": [1, 2, 3],
            "nums2": [1, 2, 3, 4],
            "expected": [2, 3, 4]
        },
        {
            "nums1": [1, 2, 3],
            "nums2": [3, 2, 1],
            "expected": [-1, -1, -1]
        }
    ]

    correct_count = 0
    for i, test in enumerate(tests):
        nums1 = test["nums1"]
        nums2 = test["nums2"]
        expected = test["expected"]
        output = nextGreaterElement(nums1, nums2)
        if output == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: nums1={nums1}, nums2={nums2}")
            print(f"  Expected: {expected}")
            print(f"  Output: {output}")

    print(f"\n{correct_count}/{len(tests)} correct tests")

if __name__ == '__main__':
    run_tests()