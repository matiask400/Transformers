def find_smallest_index(arr):
    """
    Given a sorted array of distinct integers arr, return the smallest index i that satisfies arr[i] == i.
    If there is no such index, return -1.
    """
    left, right = 0, len(arr) - 1
    result = -1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == mid:
            result = mid
            right = mid - 1  # Search for smaller index in the left half
        elif arr[mid] < mid:
            left = mid + 1  # Search in the right half
        else:
            right = mid - 1  # Search in the left half
    return result

def run_tests():
    test_cases = [
        ([-10,-5,0,3,7], 3),
        ([0,2,5,8,17], 0),
        ([-10,-5,3,4,7,9], -1),
        ([-1, 0, 1, 2, 4], 4),
        ([-2, 0, 2, 3, 6, 7, 9], 2),
        ([-2, -1, 1, 3, 5, 6, 8], 2),
        ([-2, -1, 0, 3, 5, 6, 8], 3),
        ([-5, -3, -1, 2, 4, 5], 5),
        ([-5, -3, -1, 0, 4, 6], 4),
        ([-5, -3, -1, 0, 1, 7], 4),
        ([-5, -3, -1, 0, 1, 2], 5),
        ([-1, -1, 0, 1, 2], -1), # Example to check for distinct integers (although problem states distinct)
        ([0], 0),
        ([-1], -1),
        ([1], -1),
    ]
    num_correct = 0
    for i, (arr, expected_output) in enumerate(test_cases):
        actual_output = find_smallest_index(arr)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{num_correct}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()