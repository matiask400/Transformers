def isBoomerang(points):
    """
    Given an array points where points[i] = [xi, yi] represents a point on the X-Y plane,
    return true if these points are a boomerang.

    A boomerang is a set of three points that are all distinct and not in a straight line.

    Example 1:
    Input: points = [[1,1],[2,3],[3,2]]
    Output: true

    Example 2:
    Input: points = [[1,1],[2,2],[3,3]]
    Output: false

    Constraints:
    points.length == 3
    points[i].length == 2
    0 <= xi, yi <= 100
    """
    p1, p2, p3 = points
    if p1 == p2 or p1 == p3 or p2 == p3:
        return False

    x1, y1 = p1
    x2, y2 = p2
    x3, y3 = p3

    # Check for collinearity using the area formula
    area = x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)
    if area == 0:
        return False
    else:
        return True

def run_tests():
    test_cases = [
        ([[1,1],[2,3],[3,2]], True),
        ([[1,1],[2,2],[3,3]], False),
        ([[1,1],[2,2],[2,2]], False),
        ([[0,0],[1,0],[2,0]], False),
        ([[0,0],[0,1],[0,2]], False),
        ([[0,0],[1,1],[2,0]], True),
        ([[0,0],[0,0],[0,0]], False),
    ]
    correct_count = 0
    for i, (points, expected_output) in enumerate(test_cases):
        actual_output = isBoomerang(points)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{correct_count}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()