def solve():
    def get_prefix_end(s):
        if not s:
            return -1
        for i in range(len(s)):
            if i > 0 and s[i] != s[0]:
                return i - 1
        return len(s) - 1

    def get_suffix_start(s):
        if not s:
            return len(s)
        for i in range(len(s) - 1, -1, -1):
            if i < len(s) - 1 and s[i] != s[-1]:
                return i + 1
        return 0

    def process_string(s):
        current_s = s
        while True:
            n = len(current_s)
            if n == 0:
                return 0
            prefix_end = get_prefix_end(current_s)
            suffix_start = get_suffix_start(current_s)

            if prefix_end < suffix_start and current_s and current_s[0] == current_s[-1]:
                current_s = current_s[prefix_end + 1:suffix_start]
            else:
                return len(current_s)

    test_cases = [
        ("ca", 2),
        ("cabaabac", 0),
        ("aabccabba", 3),
        ("aaa", 0),
        ("abc", 3),
        ("aba", 1),
        ("aabbcc", 6),
        ("aabbbaa", 3),
        ("bbbaaaabbb", 0),
        ("a", 1),
        ("", 0) # Added empty string test case for robustness
    ]

    results = []
    for input_str, expected_output in test_cases:
        output = process_string(input_str)
        if output == expected_output:
            print("True")
            results.append(True)
        else:
            print("False")
            results.append(False)
            print(f"Input: '{input_str}', Expected Output: {expected_output}, Your Output: {output}")

    correct_tests = sum(results)
    total_tests = len(test_cases)
    print(f"{correct_tests}/{total_tests}")

solve()