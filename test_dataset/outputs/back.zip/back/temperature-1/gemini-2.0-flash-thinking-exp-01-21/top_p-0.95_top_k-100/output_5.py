def largeGroupPositions(s):
    """
    Finds the intervals of every large group in a string.

    Args:
        s: A string of lowercase letters.

    Returns:
        A list of intervals, where each interval is a list of two integers [start, end],
        representing the start and end indices of a large group. The intervals are sorted
        in increasing order by start index.
    """
    large_groups_intervals = []
    i = 0
    while i < len(s):
        start_index = i
        char = s[i]
        end_index = i
        while end_index + 1 < len(s) and s[end_index + 1] == char:
            end_index += 1
        length = end_index - start_index + 1
        if length >= 3:
            large_groups_intervals.append([start_index, end_index])
        i = end_index + 1
    return large_groups_intervals

def run_tests():
    tests = [
        {"input": "abbxxxxzzy", "expected_output": [[3, 6]]},
        {"input": "abc", "expected_output": []},
        {"input": "abcdddeeeeaabbbcd", "expected_output": [[3, 5], [6, 9], [12, 14]]},
        {"input": "aba", "expected_output": []},
        {"input": "nnnora", "expected_output": [[0, 2]]},
        {"input": "aaaa", "expected_output": [[0, 3]]},
        {"input": "bbanana", "expected_output": []},
        {"input": "mississippi", "expected_output": [[2, 3], [5, 6]]},
        {"input": "ssesseeessseeseeessse", "expected_output": [[0, 2], [4, 6], [8, 10], [12, 14], [16, 18]]},
    ]
    correct_tests = 0
    for i, test in enumerate(tests):
        input_s = test["input"]
        expected_output = test["expected_output"]
        actual_output = largeGroupPositions(input_s)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{correct_tests}/{len(tests)}")

if __name__ == '__main__':
    run_tests()