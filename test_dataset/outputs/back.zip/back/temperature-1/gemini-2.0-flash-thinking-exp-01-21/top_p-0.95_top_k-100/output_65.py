def numSubarraysWithSumS(A, S):
    count = 0
    n = len(A)
    for i in range(n):
        for j in range(i, n):
            current_sum = sum(A[i:j+1])
            if current_sum == S:
                count += 1
    return count

def run_tests():
    test_cases = [
        ([1,0,1,0,1], 2, 4),
        ([0,0,0], 0, 6),
        ([1,1,1], 3, 1),
        ([1,1,1], 2, 3),
        ([1,1,1], 0, 0),
        ([0,0,0], 1, 0),
        ([1,0,0,1,0], 1, 9) # Based on detailed breakdown, corrected expected output
    ]
    correct_tests = 0
    total_tests = len(test_cases)
    for i, (A, S, expected_output) in enumerate(test_cases):
        result = numSubarraysWithSumS(A, S)
        if result == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")
    print(f"Correct tests: {correct_tests}/{total_tests}")

if __name__ == '__main__':
    run_tests()