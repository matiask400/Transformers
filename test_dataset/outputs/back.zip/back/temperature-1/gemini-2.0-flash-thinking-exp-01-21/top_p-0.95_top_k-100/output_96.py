def solve():
    def knows_wrapper(a, b, graph_):
        return graph_[a][b] == 1

    def findCelebrity(n, knows_func):
        candidate = 0
        for i in range(1, n):
            if knows_func(candidate, i):
                candidate = i
        
        for i in range(n):
            if i == candidate:
                continue
            if knows_func(candidate, i):
                return -1
            if not knows_func(i, candidate):
                return -1
        return candidate

    test_cases = [
        ([[1,1,0],[0,1,0],[1,1,1]], 1),
        ([[1,0,1],[1,1,0],[0,1,1]], -1),
        ([[1,0],[1,1]], 1),
        ([[1,0],[0,1]], -1),
        ([[1,1],[0,1]], 0),
        ([[1,1,1],[1,1,1],[0,0,1]], 2),
        ([[1,1,1],[1,1,1],[1,1,1]], -1),
        ([[1,1,1],[0,1,1],[0,0,1]], 2),
        ([[1,0],[0,1]], -1),
        ([[1,1],[1,1]], -1),
        ([[1,0],[0,1]], -1),
        ([[1,0,0,0,0],[1,1,0,0,0],[1,0,1,0,0],[1,0,0,1,0],[1,0,0,0,1]], -1),
        ([[1,0,0,0,0],[1,1,0,0,0],[1,1,1,0,0],[1,1,1,1,0],[0,0,0,0,1]], 4),
        ([[1,0,0,0],[1,1,0,0],[1,1,1,0],[0,0,0,1]], 3)
    ]

    num_correct = 0
    for i, (graph, expected_output) in enumerate(test_cases):
        n_people = len(graph)
        
        def current_knows(a, b):
            return knows_wrapper(a, b, graph)
            
        actual_output = findCelebrity(n_people, current_knows)
        if actual_output == expected_output:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")

    print(f"{num_correct}/{len(test_cases)}")

solve()