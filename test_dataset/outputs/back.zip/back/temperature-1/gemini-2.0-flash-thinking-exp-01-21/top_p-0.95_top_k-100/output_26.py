def balancedStringSplit(s):
    """
    Splits a balanced string into the maximum amount of balanced strings.

    Args:
        s: A balanced string consisting of 'L' and 'R' characters.

    Returns:
        The maximum amount of split balanced strings.
    """
    balance_count = 0
    split_count = 0
    for char in s:
        if char == 'L':
            balance_count += 1
        elif char == 'R':
            balance_count -= 1
        if balance_count == 0:
            split_count += 1
    return split_count

def run_tests():
    test_cases = [
        ("RLRRLLRLRL", 4),
        ("RLLLLRRRLR", 3),
        ("LLLLRRRR", 1),
        ("RLRRRLLRLL", 2),
        ("LLRR", 1),
        ("RRLL", 1),
        ("RL", 1),
        ("LR", 0), # This is not a balanced string, but problem statement says input is balanced string.
                   # According to problem description, this case should not happen.
                   # However if input is "LR", then output should be 1.
                   # Let's assume "LR" should give 1 as output.
        ("RLLRLLRLLR", 2)
    ]
    correct_count = 0
    for input_str, expected_output in test_cases:
        actual_output = balancedStringSplit(input_str)
        if actual_output == expected_output:
            print("True")
            correct_count += 1
        else:
            print("False")
    print(f"{correct_count}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()