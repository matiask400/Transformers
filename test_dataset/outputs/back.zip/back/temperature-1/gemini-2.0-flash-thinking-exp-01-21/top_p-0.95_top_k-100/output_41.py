import heapq

def min_cost_to_hire_workers(quality, wage, k):
    n = len(quality)
    workers = []
    for i in range(n):
        ratio = wage[i] / quality[i]
        workers.append((ratio, quality[i], wage[i]))
    
    workers.sort(key=lambda x: x[0])
    
    min_cost = float('inf')
    current_quality_sum = 0
    quality_heap = []
    
    for ratio, qual, w in workers:
        heapq.heappush(quality_heap, qual)
        current_quality_sum += qual
        
        if len(quality_heap) > k:
            smallest_quality = heapq.heappop(quality_heap)
            current_quality_sum -= smallest_quality
            
        if len(quality_heap) == k:
            current_cost = ratio * current_quality_sum
            min_cost = min(min_cost, current_cost)
            
    return min_cost

def solve():
    test_cases = [
        (([10, 20, 5], [70, 50, 30], 2), 105.00000),
        (([3, 1, 10, 10, 1], [4, 8, 2, 2, 7], 3), 30.66667),
    ]
    
    for i, (input_args, expected_output) in enumerate(test_cases):
        quality, wage, k = input_args
        output = min_cost_to_hire_workers(quality, wage, k)
        if abs(output - expected_output) < 1e-5:
            print(True)
        else:
            print(False)
        
    correct_tests = 0
    total_