def assign_bikes(workers, bikes):
    n = len(workers)
    m = len(bikes)
    distances = []
    for i in range(n):
        for j in range(m):
            dist = abs(workers[i][0] - bikes[j][0]) + abs(workers[i][1] - bikes[j][1])
            distances.append((dist, i, j))

    distances.sort(key=lambda x: (x[0], x[1], x[2]))

    ans = [-1] * n
    worker_assigned = [False] * n
    bike_assigned = [False] * m

    for dist, worker_index, bike_index in distances:
        if not worker_assigned[worker_index] and not bike_assigned[bike_index]:
            ans[worker_index] = bike_index
            worker_assigned[worker_index] = True
            bike_assigned[bike_index] = True

    return ans

def test_assign_bikes():
    test_cases = [
        {
            "workers": [[0,0],[2,1]],
            "bikes": [[1,2],[3,3]],
            "expected_output": [1,0]
        },
        {
            "workers": [[0,0],[1,1],[2,0]],
            "bikes": [[1,0],[2,2],[2,1]],
            "expected_output": [0,2,1]
        },
        {
            "workers": [[0,0]],
            "bikes": [[1,0]],
            "expected_output": [0]
        },
        {
            "workers": [[0,0], [0,1]],
            "bikes": [[1,0], [1,1]],
            "expected_output": [0, 1]
        },
        {
            "workers": [[0,0], [0,1]],
            "bikes": [[1,1], [1,0]],
            "expected_output": [1, 0]
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        workers = test_case["workers"]
        bikes = test_case["bikes"]
        expected_output = test_case["expected_output"]
        output = assign_bikes(workers, bikes)
        if output == expected_output:
            print(f'Test {i+1}: True')
            correct_tests += 1
        else:
            print(f'Test {i+1}: False, Input: workers={workers}, bikes={bikes}, Expected: {expected_output}, Output: {output}')

    print(f'{correct_tests}/{total_tests}')

test_assign_bikes()