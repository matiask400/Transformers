def is_k_palindrome(s: str, k: int) -> bool:
    n = len(s)
    memo = {}

    def solve(l, r, k_remaining):
        if k_remaining < 0:
            return False
        if l >= r:
            return True
        if (l, r, k_remaining) in memo:
            return memo[(l, r, k_remaining)]

        if s[l] == s[r]:
            res = solve(l + 1, r - 1, k_remaining)
        else:
            res = solve(l + 1, r, k_remaining - 1) or solve(l, r - 1, k_remaining - 1)
        memo[(l, r, k_remaining)] = res
        return res

    return solve(0, n - 1, k)

def run_tests():
    test_cases = [
        {"input": {"s": "abcdeca", "k": 2}, "expected": True},
        {"input": {"s": "abbababa", "k": 1}, "expected": True},
        {"input": {"s": "aaaa", "k": 0}, "expected": True},
        {"input": {"s": "aaaa", "k": 1}, "expected": True},
        {"input": {"s": "aba", "k": 0}, "expected": True},
        {"input": {"s": "ab", "k": 0}, "expected": False},
        {"input": {"s": "ab", "k": 1}, "expected": True},
        {"input": {"s": "ab", "k": 2}, "expected": True},
        {"input": {"s": "acb", "k": 1}, "expected": True},
        {"input": {"s": "racecar", "k": 0}, "expected": True},
        {"input": {"s": "madam", "k": 0}, "expected": True},
        {"input": {"s": "level", "k": 0}, "expected": True},
        {"input": {"s": "noon", "k": 0}, "expected": True},
        {"input": {"s": "rotor", "k": 0}, "expected": True},
        {"input": {"s": "stats", "k": 0}, "expected": True},
        {"input": {"s": "google", "k": 1}, "expected": False},
        {"input": {"s": "google", "k": 2}, "expected": True},
        {"input": {"s": "leetcode", "k": 1}, "expected": False},
        {"input": {"s": "leetcode", "k": 2}, "expected": False},
        {"input": {"s": "leetcode", "k": 3}, "expected": False},
        {"input": {"s": "leetcode", "k": 4}, "expected": True},
        {"input": {"s": "mbadm", "k": 2}, "expected": True},
        {"input": {"s": "mbdadbm", "k": 1}, "expected": True},
    ]

    correct_count = 0
    for i, test_case in enumerate(test_cases):
        input_data = test_case["input"]
        s = input_data["s"]
        k = input_data["k"]
        expected_output = test_case["expected"]
        actual_output = is_k_palindrome(s, k)
        if actual_output == expected_output:
            print(True)
            correct_count += 1
        else:
            print(False)
    print(f"{correct_count}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()