import collections

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def distanceK(root, target, K):
    """
    Finds all nodes that are at a distance K from the target node in a binary tree.

    Args:
        root: The root of the binary tree.
        target: The target node in the binary tree.
        K: The distance K.

    Returns:
        A list of the values of all nodes that are distance K from the target node.
    """
    parent_map = {}  # Node -> Parent mapping

    def build_parent_map(node, parent):
        if node:
            parent_map[node] = parent
            build_parent_map(node.left, node)
            build_parent_map(node.right, node)

    build_parent_map(root, None)

    queue = collections.deque([(target, 0)])
    visited = {target}
    result = []

    while queue:
        current_node, distance = queue.popleft()

        if distance == K:
            result.append(current_node.val)

        if distance < K:
            # Explore children
            if current_node.left and current_node.left not in visited:
                queue.append((current_node.left, distance + 1))
                visited.add(current_node.left)
            if current_node.right and current_node.right not in visited:
                queue.append((current_node.right, distance + 1))
                visited.add(current_node.right)

            # Explore parent
            parent = parent_map.get(current_node)
            if parent and parent not in visited:
                queue.append((parent, distance + 1))
                visited.add(parent)

    return result

def create_tree_from_list(values):
    """
    Creates a binary tree from a list of values, where None represents null nodes.
    """
    if not values:
        return None
    root = TreeNode(values[0])
    queue = collections.deque([root])
    i = 1
    while queue and i < len(values):
        current_node = queue.popleft()
        if i < len(values) and values[i] is not None:
            current_node.left = TreeNode(values[i])
            queue.append(current_node.left)
        i += 1
        if i < len(values) and values[i] is not None:
            current_node.right = TreeNode(values[i])
            queue.append(current_node.right)
        i += 1
    return root

def find_node(root, target_val):
    """
    Finds a node in the tree with the given target value.
    """
    if not root:
        return None
    if root.val == target_val:
        return root
    left_search = find_node(root.left, target_val)
    if left_search:
        return left_search
    return find_node(root.right, target_val)

def run_tests():
    test_cases = [
        {
            "root": [3,5,1,6,2,0,8,None,None,7,4],
            "target": 5,
            "K": 2,
            "expected_output": [7, 4, 1]
        },
        {
            "root": [0,1,None,None,2,None,3,None,4],
            "target": 0,
            "K": 2,
            "expected_output": [2]
        },
        {
            "root": [0,1,None,None,2,None,3,None,4],
            "target": 4,
            "K": 0,
            "expected_output": [4]
        },
        {
            "root": [0,1,None,None,2,None,3,None,4],
            "target": 0,
            "K": 4,
            "expected_output": [4]
        },
        {
            "root": [0,1,None,None,2,None,3,None,4],
            "target": 4,
            "K": 2,
            "expected_output": [1]
        },
        {
            "root": [1],
            "target": 1,
            "K": 3,
            "expected_output": []
        },
        {
            "root": [1,2,None,3,None,4,None,5],
            "target": 3,
            "K": 2,
            "expected_output": [1, 5]
        }


    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        root_list = test_case["root"]
        target_val = test_case["target"]
        K = test_case["K"]
        expected_output = sorted(test_case["expected_output"])

        root_node = create_tree_from_list(root_list)
        target_node = find_node(root_node, target_val)

        if target_node:
            actual_output = sorted(distanceK(root_node, target_node, K))
            if actual_output == expected_output:
                print(f"Test {i+1}: True")
                num_correct += 1
            else:
                print(f"Test {i+1}: False")
        else:
            print(f"Test {i+1}: False (Target node not found in tree - which should not happen based on problem description)")


    print(f"\n{num_correct} correct out of {total_tests}")

if __name__ == '__main__':
    run_tests()