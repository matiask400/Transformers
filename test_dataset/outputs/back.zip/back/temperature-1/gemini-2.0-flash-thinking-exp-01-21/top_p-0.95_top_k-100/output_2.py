def smallest_integer_divisible_by_k(k: int) -> int:
    if k % 2 == 0 or k % 5 == 0 and k != 1:
        return -1
    remainder = 0
    length = 0
    remainders_seen = set()
    while True:
        length += 1
        remainder = (remainder * 10 + 1) % k
        if remainder == 0:
            return length
        if remainder in remainders_seen:
            return -1
        remainders_seen.add(remainder)

def run_tests():
    tests = [
        (1, 1),
        (2, -1),
        (3, 3),
        (4, -1),
        (5, -1),
        (6, -1),
        (7, 6),
        (8, -1),
        (9, 9),
        (10, -1),
        (11, 10),
        (37, 3),
        (99, 18),
        (999, 27),
        (1000, -1)
    ]
    correct_count = 0
    for input_k, expected_output in tests:
        actual_output = smallest_integer_divisible_by_k(input_k)
        if actual_output == expected_output:
            print('True')
            correct_count += 1
        else:
            print('False')
    print(f'{correct_count}/{len(tests)}')

if __name__ == '__main__':
    run_tests()