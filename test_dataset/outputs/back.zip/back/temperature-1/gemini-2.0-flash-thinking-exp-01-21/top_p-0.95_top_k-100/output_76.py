class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def getMinimumDifference(root):
    inorder_values = []

    def inorder(node, values_list):
        if not node:
            return
        inorder(node.left, values_list)
        values_list.append(node.val)
        inorder(node.right, values_list)

    inorder(root, inorder_values)

    min_diff = float('inf')
    for i in range(1, len(inorder_values)):
        diff = abs(inorder_values[i] - inorder_values[i-1])
        min_diff = min(min_diff, diff)
    return min_diff

def run_tests():
    test_cases = [
        {
            "input": TreeNode(1, None, TreeNode(3, TreeNode(2), None)),
            "expected_output": 1
        },
        {
            "input": TreeNode(4, TreeNode(2, TreeNode(1), TreeNode(3)), TreeNode(6)),
            "expected_output": 1
        },
        {
            "input": TreeNode(10, TreeNode(5, TreeNode(3), TreeNode(7)), TreeNode(15, TreeNode(12), TreeNode(18))),
            "expected_output": 2
        },
        {
            "input": TreeNode(236, TreeNode(104, None, TreeNode(227)), TreeNode(701, TreeNode(911), None)),
            "expected_output": 9
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        input_tree = test_case["input"]
        expected_output = test_case["expected_output"]
        actual_output = getMinimumDifference(input_tree)

        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"\n{correct_tests}/{total_tests}")

if __name__ == '__main__':
    run_tests()