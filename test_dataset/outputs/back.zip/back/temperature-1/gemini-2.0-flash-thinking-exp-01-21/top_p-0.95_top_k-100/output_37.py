def subarray_sum_range(nums, left, right):
    n = len(nums)
    subarray_sums = []
    for i in range(n):
        current_sum = 0
        for j in range(i, n):
            current_sum += nums[j]
            subarray_sums.append(current_sum)
    subarray_sums.sort()
    total_sum = 0
    mod = 10**9 + 7
    for i in range(left - 1, right):
        total_sum = (total_sum + subarray_sums[i]) % mod
    return total_sum

def run_test(nums, left, right, expected_output):
    actual_output = subarray_sum_range(nums, left, right)
    if actual_output == expected_output:
        print("True")
    else:
        print("False")
    print(f"Output: {actual_output}, Expected: {expected_output}")

def solve():
    nums = [1, 2, 3, 4]
    n = len(nums)
    left = 1
    right = 5
    expected_output = 13
    run_test(nums, left, right, expected_output)

    nums = [1, 2, 3, 4]
    n = len(nums)
    left = 3
    right = 4
    expected_output = 6
    run_test(nums, left, right, expected_output)

    nums = [1, 2, 3, 4]
    n = len(nums)
    left = 1
    right = 10
    expected_output = 50
    run_test(nums, left, right, expected_output)

    nums = [1, 2]
    n = len(nums)
    left = 1
    right = 3
    expected_output = 4
    run_test(nums, left, right, expected_output)

    nums = [100]
    n = len(nums)
    left = 1
    right = 1
    expected_output = 100
    run_test(nums, left, right, expected_output)

    nums = [1, 2, 3, 4, 5]
    n = len(nums)
    left = 6
    right = 10
    expected_output = 25
    run_test(nums, left, right, expected_output)

    nums = [4,5,6]
    n = len(nums)
    left = 3
    right = 7
    expected_output = 34
    run_test(nums, left, right, expected_output)

    nums = [3,5,1,6]
    n = len(nums)
    left = 2
    right = 6
    expected_output = 25
    run_test(nums, left, right, expected_output)

    correct_tests = 0
    total_tests = 9
    test_results = []

    def run_test_internal(nums, left, right, expected_output):
        nonlocal correct_tests, test_results
        actual_output = subarray_sum_range(nums, left, right)
        if actual_output == expected_output:
            print("True")
            test_results.append(True)
            correct_tests += 1
        else:
            print("False")
            test_results.append(False)
        print(f"Output: {actual_output}, Expected: {expected_output}")

    nums = [1, 2, 3, 4]
    n = len(nums)
    left = 1
    right = 5
    expected_output = 13
    run_test_internal(nums, left, right, expected_output)

    nums = [1, 2, 3, 4]
    n = len(nums)
    left = 3
    right = 4
    expected_output = 6
    run_test_internal(nums, left, right, expected_output)

    nums = [1, 2, 3, 4]
    n = len(nums)
    left = 1
    right = 10
    expected_output = 50
    run_test_internal(nums, left, right, expected_output)

    nums = [1, 2]
    n = len(nums)
    left = 1
    right = 3
    expected_output = 4
    run_test_internal(nums, left, right, expected_output)

    nums = [100]
    n = len(nums)
    left = 1
    right = 1
    expected_output = 100
    run_test_internal(nums, left, right, expected_output)

    nums = [1, 2, 3, 4, 5]
    n = len(nums)
    left = 6
    right = 10
    expected_output = 25
    run_test_internal(nums, left, right, expected_output)

    nums = [4,5,6]
    n = len(nums)
    left = 3
    right = 7
    expected_output = 34
    run_test_internal(nums, left, right, expected_output)

    nums = [3,5,1,6]
    n = len(nums)
    left = 2
    right = 6
    expected_output = 25
    run_test_internal(nums, left, right, expected_output)

    nums = [5, 3, 9, 7, 2]
    n = len(nums)
    left = 5
    right = 9
    expected_output = 49
    run_test_internal(nums, left, right, expected_output)


    print(f"\n{correct_tests}/{total_tests}")

if __name__ == '__main__':
    solve()