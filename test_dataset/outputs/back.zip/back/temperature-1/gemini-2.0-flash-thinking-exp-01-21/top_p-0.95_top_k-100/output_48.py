def solve():
    def get_magical_string(n):
        if n <= 0:
            return []
        if n <= 3:
            return [1, 2, 2][:n]

        s = [1, 2, 2]
        pointer = 2
        current_digit = 1
        while len(s) < n:
            count = s[pointer]
            for _ in range(count):
                s.append(current_digit)
                if len(s) == n:
                    return s[:n]
            current_digit = 3 - current_digit
            pointer += 1
        return s[:n]

    def count_ones(s):
        count = 0
        for digit in s:
            if digit == 1:
                count += 1
        return count

    def test_function(n, expected_output):
        magical_s = get_magical_string(n)
        output = count_ones(magical_s)
        if output == expected_output:
            print('True')
        else:
            print('False')
        return output == expected_output

    test_results = []

    # Example 1
    test_results.append(test_function(6, 3))

    # Test case 1
    test_results.append(test_function(1, 1))

    # Test case 2
    test_results.append(test_function(2, 1))

    # Test case 3
    test_results.append(test_function(3, 1))

    # Test case 4
    test_results.append(test_function(4, 2))

    # Test case 5
    test_results.append(test_function(5, 3))

    # Test case 7
    test_results.append(test_function(7, 4))

    # Test case 8
    test_results.append(test_function(8, 4))

    # Test case 9
    test_results.append(test_function(9, 4))

    # Test case 10
    test_results.append(test_function(10, 5))

    # Test case 20
    test_results.append(test_function(20, 9))

    # Test case 50
    test_results.append(test_function(50, 21))

    # Test case 100
    test_results.append(test_function(100, 47))


    correct_tests = sum(test_results)
    total_tests = len(test_results)
    print(f"{correct_tests}/{total_tests}")

solve()