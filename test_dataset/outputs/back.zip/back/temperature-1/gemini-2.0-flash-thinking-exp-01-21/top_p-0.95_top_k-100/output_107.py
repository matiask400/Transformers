import sqlite3

def execute_sql_test(sql_query, expected_output):
    """
    Executes an SQL query on an in-memory SQLite database and compares the output with the expected output.

    Args:
        sql_query (str): The SQL query to execute.
        expected_output (list): The expected output of the SQL query as a list of tuples.

    Returns:
        bool: True if the test passed, False otherwise.
    """
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()

    # Create a dummy table and insert some data for testing purposes
    cursor.execute('''
        CREATE TABLE Employees (
            id INT PRIMARY KEY,
            name VARCHAR(255),
            department VARCHAR(255),
            salary INT
        )
    ''')
    cursor.executemany('''
        INSERT INTO Employees (id, name, department, salary) VALUES (?, ?, ?, ?)
    ''', [
        (1, 'Alice', 'Sales', 50000),
        (2, 'Bob', 'Marketing', 60000),
        (3, 'Charlie', 'Sales', 55000),
        (4, 'David', 'Engineering', 70000),
        (5, 'Eve', 'Marketing', 65000)
    ])
    conn.commit()

    cursor.execute(sql_query)
    actual_output = cursor.fetchall()

    conn.close()

    if actual_output == expected_output:
        print('True')
        return True
    else:
        print('False')
        print(f"  Expected: {expected_output}")
        print(f"  Actual:   {actual_output}")
        return False

if __name__ == '__main__':
    test_cases = [
        {
            'query': "SELECT name FROM Employees WHERE department = 'Sales'",
            'expected_output': [('Alice',), ('Charlie',)]
        },
        {
            'query': "SELECT department, AVG(salary) FROM Employees GROUP BY department",
            'expected_output': [('Engineering', 70000.0), ('Marketing', 62500.0), ('Sales', 52500.0)]
        },
        {
            'query': "SELECT COUNT(*) FROM Employees WHERE salary > 60000",
            'expected_output': [(2,)]
        },
        {
            'query': "SELECT name FROM Employees WHERE department = 'HR'",
            'expected_output': []
        },
        {
            'query': "SELECT id, name FROM Employees ORDER BY name DESC LIMIT 2",
            'expected_output': [(5, 'Eve'), (4, 'David')]
        },
        {
            'query': "SELECT department, SUM(salary) FROM Employees GROUP BY department ORDER BY SUM(salary) DESC",
            'expected_output': [('Engineering', 70000), ('Marketing', 125000), ('Sales', 105000)]
        },
        {
            'query': "SELECT name FROM Employees WHERE department = 'Marketing' AND salary > 62000",
            'expected_output': [('Eve',)]
        },
         {
            'query': "SELECT DISTINCT department FROM Employees",
            'expected_output': [('Sales',), ('Marketing',), ('Engineering',)]
        },
        {
            'query': "SELECT name FROM Employees WHERE salary = (SELECT MAX(salary) FROM Employees)",
            'expected_output': [('David',)]
        },
        {
            'query': "SELECT department, COUNT(*) FROM Employees GROUP BY department HAVING COUNT(*) > 1",
            'expected_output': [('Marketing', 2), ('Sales', 2)]
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for test_case in test_cases:
        if execute_sql_test(test_case['query'], test_case['expected_output']):
            correct_tests += 1

    print(f"{correct_tests}/{total_tests}")