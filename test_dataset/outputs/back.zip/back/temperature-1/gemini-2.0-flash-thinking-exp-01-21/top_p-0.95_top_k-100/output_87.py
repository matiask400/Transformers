def count_distinct_subsequences(s: str) -> int:
    MOD = 10**9 + 7
    dp = [0] * (len(s) + 1)
    dp[0] = 1
    last_occurrence = {}
    for i in range(len(s)):
        dp[i + 1] = (2 * dp[i]) % MOD
        char = s[i]
        if char in last_occurrence:
            j = last_occurrence[char]
            dp[i + 1] = (dp[i + 1] - dp[j] + MOD) % MOD
        last_occurrence[char] = dp[i]
    return (dp[len(s)] - 1 + MOD) % MOD

def test_count_distinct_subsequences():
    test_cases = [
        ("abc", 7),
        ("aba", 6),
        ("aaa", 3),
        ("abcd", 15),
        ("abcade", 55),
        ("aabbcc", 27),
        ("abcdefghijklmnopqrstuvwxyz", 67108863)
    ]
    num_tests = len(test_cases)
    correct_tests = 0
    for i, (input_str, expected_output) in enumerate(test_cases):
        actual_output = count_distinct_subsequences(input_str)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False (Input: '{input_str}', Expected: {expected_output}, Actual: {actual_output})")
    print(f"\nCorrect tests: {correct_tests}/{num_tests}")

if __name__ == '__main__':
    test_count_distinct_subsequences()