import heapq

def rearrange_string(s: str, k: int) -> str:
    if k == 0:
        return s
    counts = {}
    for char in s:
        counts[char] = counts.get(char, 0) + 1
    
    heap = []
    for char, count in counts.items():
        heapq.heappush(heap, (-count, char))
        
    result = ""
    while heap:
        current_count, current_char = heapq.heappop(heap)
        result += current_char
        current_count += 1
        wait_queue = []
        if current_count < 0:
            wait_queue.append((current_count, current_char))
        
        for _ in range(k - 1):
            if heap:
                next_count, next_char = heapq.heappop(heap)
                result += next_char
                next_count += 1
                if next_count < 0:
                    wait_queue.append((next_count, next_char))
            else:
                if wait_queue:
                    return ""
                else:
                    break
                    
        for item in wait_queue:
            heapq.heappush(heap, item)
            
    if len(result) == len(s):
        return result
    else:
        return ""

def run_tests():
    test_cases = [
        {"s": "aabbcc", "k": 3, "expected": "abcabc"},
        {"s": "aaabc", "k": 3, "expected": ""},
        {"s": "aaadbbcc", "k": 2, "expected": "abacabcd"},
        {"s": "aabb", "k": 0, "expected": "aabb"},
        {"s": "a", "k": 3, "expected": "a"},
        {"s": "aaaaabbbbcccdde", "k": 2, "expected": "abcdaebabcdcba"},
        {"s": "aabbccddeeffgghhiijjkkllmmnnooppqqrrssttuuvvwwxxyyzz", "k": 1, "expected": "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"},
        {"s": "aabbccddeeffgghhiijjkkllmmnnooppqqrrssttuuvvwwxxyyzz", "k": 26, "expected": "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"},
        {"s": "vvvlo", "k": 2, "expected": "vlvov"},
        {"s": "aabbccddee", "k": 3, "expected": "abcdeabcd"},
        {"s": "aaabbbcdd", "k": 3, "expected": "abcdababd"},
        {"s": "aaabbbcdd", "k": 2, "expected": "abacabadbd"},
        {"s": "aaaabbcc", "k": 2, "expected": "abacabadc"},
        {"s": "aaaabbcc", "k": 3, "expected": "abcabaca"}

    ]
    
    correct_count = 0
    for i, case in enumerate(test_cases):
        actual_output = rearrange_string(case["s"], case["k"])
        expected_output = case["expected"]
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            
    print(f"Correct tests: {correct_count}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()