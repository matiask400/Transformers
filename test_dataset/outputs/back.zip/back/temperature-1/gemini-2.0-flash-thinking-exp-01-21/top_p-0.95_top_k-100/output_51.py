def f(x):
    count = 0
    i = 5
    while x // i >= 1:
        count += x // i
        i *= 5
    return count

def solve():
    k = int(input())

    def get_start_x(target_k):
        low = 0
        high = 20 * target_k + 5 if target_k > 0 else 5
        start_x = -1
        while low <= high:
            mid = (low + high) // 2
            if f(mid) >= target_k:
                start_x = mid
                high = mid - 1
            else:
                low = mid + 1
        return start_x

    def get_end_x(start_x_val, target_k):
        low = start_x_val
        high = start_x_val + 5
        end_x = -1
        while low <= high:
            mid = (low + high) // 2
            if f(mid) <= target_k:
                end_x = mid
                low = mid + 1
            else:
                high = mid - 1
        return end_x

    start_x = get_start_x(k)
    if start_x == -1 or f(start_x) != k:
        print(0)
    else:
        end_x = get_end_x(start_x, k)
        if end_x == -1 or f(end_x) != k:
            print(0)
        else:
            print(end_x - start_x + 1)

def test_cases():
    test_inputs_k = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    expected_outputs = [5, 5, 5, 5, 5, 0, 5, 5, 5, 5, 5, 0, 5]

    num_correct = 0
    total_tests = len(test_inputs_k)

    for i in range(total_tests):
        k = test_inputs_k[i]
        expected_output = expected_outputs[i]

        def calculate_answer(k_val):
            def f_test(x):
                count = 0
                i = 5
                while x // i >= 1:
                    count += x // i
                    i *= 5
                return count

            def get_start_x_test(target_k):
                low = 0
                high = 20 * target_k + 5 if target_k > 0 else 5
                start_x = -1
                while low <= high:
                    mid = (low + high) // 2
                    if f_test(mid) >= target_k:
                        start_x = mid
                        high = mid - 1
                    else:
                        low = mid + 1
                return start_x

            def get_end_x_test(start_x_val, target_k):
                low = start_x_val
                high = start_x_val + 5
                end_x = -1
                while low <= high:
                    mid = (low + high) // 2
                    if f_test(mid) <= target_k:
                        end_x = mid
                        low = mid + 1
                    else:
                        high = mid - 1
                return end_x

            start_x_val = get_start_x_test(k_val)
            if start_x_val == -1 or f_test(start_x_val) != k_val:
                return 0
            else:
                end_x_val = get_end_x_test(start_x_val, k_val)
                if end_x_val == -1 or f_test(end_x_val) != k_val:
                    return 0
                else:
                    return end_x_val - start_x_val + 1

        actual_output = calculate_answer(k)
        if actual_output == expected_output:
            print('True')
            num_correct += 1
        else:
            print('False')

    print(f'{num_correct}/{total_tests}')

if __name__ == '__main__':
    test_cases()