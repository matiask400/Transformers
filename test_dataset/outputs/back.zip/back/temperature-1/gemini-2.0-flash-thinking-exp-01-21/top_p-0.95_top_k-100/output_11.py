def is_match(s: str, p: str) -> bool:
    s_len = len(s)
    p_len = len(p)
    dp = [[False] * (p_len + 1) for _ in range(s_len + 1)]
    dp[0][0] = True

    for j in range(1, p_len + 1):
        if p[j - 1] == '*':
            dp[0][j] = dp[0][j - 2]

    for i in range(1, s_len + 1):
        for j in range(1, p_len + 1):
            if p[j - 1] != '*':
                if p[j - 1] == '.' or p[j - 1] == s[i - 1]:
                    dp[i][j] = dp[i - 1][j - 1]
            else:
                if j >= 2:
                    char_before_star = p[j - 2]
                    dp[i][j] = dp[i][j - 2]  # Match zero occurrences
                    if char_before_star == '.' or char_before_star == s[i - 1]:
                        dp[i][j] = dp[i][j] or dp[i - 1][j]  # Match one or more occurrences
    return dp[s_len][p_len]

def run_tests():
    tests = [
        ("aa", "a", False),
        ("aa", "a*", True),
        ("ab", ".*", True),
        ("aab", "c*a*b", True),
        ("mississippi", "mis*is*p*.", False),
        ("abc", "abc", True),
        ("abbbc", "ab*c", True),
        ("ac", "ab*c", True),
        ("bbc", "ab*c", False),
        ("", "a*", True),
        ("", ".*", True),
        ("", ".", False),
        ("a", ".", True),
        ("ab", "a.", True),
        ("a", "a*", True),
        ("a", "ab*", True),
        ("bbb", "b*", True),
        ("bbba", "b*a", True),
        ("bbbab", "b*ab", True),
        ("b", "b.", True)
    ]
    correct_count = 0
    for i, (s, p, expected) in enumerate(tests):
        output = is_match(s, p)
        if output == expected:
            print(f'Test {i+1}: True')
            correct_count += 1
        else:
            print(f'Test {i+1}: False')
    print(f'{correct_count}/{len(tests)}')

if __name__ == '__main__':
    run_tests()