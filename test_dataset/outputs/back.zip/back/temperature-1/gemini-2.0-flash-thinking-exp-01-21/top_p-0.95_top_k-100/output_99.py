class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def str_to_tree(s):
    if not s:
        return None

    def parse_tree(index):
        if index >= len(s):
            return None, index

        is_negative = False
        if s[index] == '-':
            is_negative = True
            index += 1

        num_str = ""
        while index < len(s) and s[index].isdigit():
            num_str += s[index]
            index += 1

        if not num_str:
            return None, index

        val = int(num_str)
        if is_negative:
            val = -val
        root = TreeNode(val)

        if index < len(s) and s[index] == '(':
            index += 1 # Skip '('
            root.left, index = parse_tree(index)
            if index < len(s) and s[index] == ')':
                index += 1 # Skip ')'
            else:
                # This should not happen in valid input, but handle for robustness
                return None, index # Or raise an exception

        if index < len(s) and s[index] == '(':
            index += 1 # Skip '('
            root.right, index = parse_tree(index)
            if index < len(s) and s[index] == ')':
                index += 1 # Skip ')'
            else:
                # This should not happen in valid input, but handle for robustness
                return None, index # Or raise an exception

        return root, index

    root, _ = parse_tree(0)
    return root

def level_order_traversal(root):
    if not root:
        return []
    result = []
    queue = [root]
    while queue:
        node = queue.pop(0)
        result.append(node.val)
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
    return result

def solve():
    def test_function(input_str, expected_output):
        root = str_to_tree(input_str)
        actual_output = level_order_traversal(root)
        return actual_output == expected_output

    test_cases = [
        ("4(2(3)(1))(6(5))", [4, 2, 6, 3, 1, 5]),
        ("4(2(3)(1))(6(5)(7))", [4, 2, 6, 3, 1, 5, 7]),
        ("-4(2(3)(1))(6(5)(7))", [-4, 2, 6, 3, 1, 5, 7]),
        ("1", [1]),
        ("10", [10]),
        ("1()", [1]),
        ("1()()", [1]),
        ("1(2)", [1, 2]),
        ("1()(2)", [1, 2]),
        ("1(2)(3)", [1, 2, 3]),
        ("5(3(2)(4))(8(6)(9))", [5, 3, 8, 2, 4, 6, 9]),
        ("0", [0]),
        ("-0", [0]), # Handle -0 as 0
        ("-10(2)", [-10, 2])
    ]

    correct_count = 0
    for i, (input_str, expected_output) in enumerate(test_cases):
        result = test_function(input_str, expected_output)
        print(result)
        if result:
            correct_count += 1

    print(f"{correct_count}/{len(test_cases)}")

if __name__ == "__main__":
    solve()