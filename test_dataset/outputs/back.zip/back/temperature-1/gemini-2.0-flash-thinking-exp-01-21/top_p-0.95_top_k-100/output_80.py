def num_distinct_subsequences(s: str, t: str) -> int:
    n = len(s)
    m = len(t)
    dp = [[0] * (m + 1) for _ in range(n + 1)]

    for i in range(n + 1):
        dp[i][0] = 1

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if s[i - 1] == t[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j]
            else:
                dp[i][j] = dp[i - 1][j]

    return dp[n][m]

def run_tests():
    tests = [
        {"s": "rabbbit", "t": "rabbit", "expected": 3},
        {"s": "babgbag", "t": "bag", "expected": 5},
        {"s": "abcde", "t": "ace", "expected": 1},
        {"s": "abcde", "t": "aec", "expected": 0},
        {"s": "dddce", "t": "dc", "expected": 3},
        {"s": "leetcode", "t": "le", "expected": 4},
        {"s": "aaaaaaaaaa", "t": "aa", "expected": 55},
        {"s": "a", "t": "b", "expected": 0},
        {"s": "a", "t": "a", "expected": 1},
        {"s": "ab", "t": "a", "expected": 1},
        {"s": "ab", "t": "b", "expected": 1},
        {"s": "ab", "t": "ab", "expected": 1},
        {"s": "abc", "t": "ac", "expected": 1},
        {"s": "banana", "t": "ban", "expected": 3}
    ]

    correct_tests = 0
    for i, test in enumerate(tests):
        s = test["s"]
        t = test["t"]
        expected = test["expected"]
        output = num_distinct_subsequences(s, t)
        if output == expected:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"\n{correct_tests}/{len(tests)}")

if __name__ == '__main__':
    run_tests()