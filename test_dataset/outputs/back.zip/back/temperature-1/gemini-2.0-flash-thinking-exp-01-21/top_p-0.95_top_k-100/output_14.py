def pacific_atlantic_water_flow(heights):
    m = len(heights)
    n = len(heights[0])
    pacific_reachable = [[False for _ in range(n)] for _ in range(m)]
    atlantic_reachable = [[False for _ in range(n)] for _ in range(m)]

    def dfs(reachable_matrix, row, col):
        if row < 0 or row >= m or col < 0 or col >= n or reachable_matrix[row][col]:
            return
        reachable_matrix[row][col] = True
        directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        for dr, dc in directions:
            nr, nc = row + dr, col + dc
            if 0 <= nr < m and 0 <= nc < n and heights[nr][nc] >= heights[row][col]:
                dfs(reachable_matrix, nr, nc)

    for i in range(m):
        dfs(pacific_reachable, i, 0)
        dfs(atlantic_reachable, i, n - 1)
    for j in range(n):
        dfs(pacific_reachable, 0, j)
        dfs(atlantic_reachable, m - 1, j)

    result = []
    for i in range(m):
        for j in range(n):
            if pacific_reachable[i][j] and atlantic_reachable[i][j]:
                result.append([i, j])
    return result

def run_tests():
    test_cases = [
        {
            "heights": [[1,2,2,3,5],[3,2,3,4,4],[2,4,5,3,1],[6,7,1,4,5],[5,1,1,2,4]],
            "expected_output": [[0,4],[1,3],[1,4],[2,2],[3,0],[3,1],[4,0]]
        },
        {
            "heights": [[2,1],[1,2]],
            "expected_output": [[0,0],[0,1],[1,0],[1,1]]
        }
    ]

    num_correct = 0
    for i, test_case in enumerate(test_cases):
        heights = test_case["heights"]
        expected_output = test_case["expected_output"]
        actual_output = pacific_atlantic_water_flow(heights)
        if sorted(actual_output) == sorted(expected_output):
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{num_correct}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()