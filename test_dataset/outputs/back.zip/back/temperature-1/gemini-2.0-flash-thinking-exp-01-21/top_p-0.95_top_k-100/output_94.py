class Node:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def treeToDoublyList(root):
    if not root:
        return None

    head = None
    prev = None

    def inorder(node):
        nonlocal head, prev
        if not node:
            return

        inorder(node.left)

        if not prev:
            head = node
        else:
            prev.right = node
            node.left = prev
        prev = node

        inorder(node.right)

    inorder(root)

    if head:
        prev.right = head
        head.left = prev

    return head

def array_to_bst(arr):
    if not arr:
        return None
    root = Node(arr[0])
    nodes = [root]
    i = 1
    while i < len(arr):
        node = nodes.pop(0)
        if i < len(arr) and arr[i] is not None:
            node.left = Node(arr[i])
            nodes.append(node.left)
        i += 1
        if i < len(arr) and arr[i] is not None:
            node.right = Node(arr[i])
            nodes.append(node.right)
        i += 1
    return root

def doubly_linked_list_to_array(head):
    if not head:
        return []
    arr = []
    curr = head
    while True:
        arr.append(curr.val)
        curr = curr.right
        if curr == head:
            break
    return arr

def run_test(input_tree_array, expected_output_array):
    root = array_to_bst(input_tree_array)
    head = treeToDoublyList(root)
    output_array = doubly_linked_list_to_array(head)
    return output_array == expected_output_array

if __name__ == '__main__':
    test_cases = [
        ([4,2,5,1,3], [1,2,3,4,5]),
        ([2,1,3], [1,2,3]),
        ([], []),
        ([1], [1]),
        ([5, 2, 8, 1, 3, 7, 9], [1, 2, 3, 5, 7, 8, 9])
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for input_tree_array, expected_output_array in test_cases:
        result = run_test(input_tree_array, expected_output_array)
        print(result)
        if result:
            correct_tests += 1

    print(f"{correct_tests}/{total_tests}")