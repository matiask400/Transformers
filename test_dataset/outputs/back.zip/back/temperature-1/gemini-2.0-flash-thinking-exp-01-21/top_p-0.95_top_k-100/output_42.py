def solve():
    def possible_bipartition(N, dislikes):
        adj = [[] for _ in range(N + 1)]
        for u, v in dislikes:
            adj[u].append(v)
            adj[v].append(u)

        color = [0] * (N + 1)

        def is_bipartite_dfs(person, c):
            color[person] = c
            for neighbor in adj[person]:
                if color[neighbor] == 0:
                    if not is_bipartite_dfs(neighbor, 3 - c):
                        return False
                elif color[neighbor] == c:
                    return False
            return True

        for i in range(1, N + 1):
            if color[i] == 0:
                if not is_bipartite_dfs(i, 1):
                    return False
        return True

    test_cases = [
        {"N": 4, "dislikes": [[1, 2], [1, 3], [2, 4]], "expected": True},
        {"N": 3, "dislikes": [[1, 2], [1, 3], [2, 3]], "expected": False},
        {"N": 5, "dislikes": [[1, 2], [2, 3], [3, 4], [4, 5], [1, 5]], "expected": False},
        {"N": 1, "dislikes": [], "expected": True},
        {"N": 2, "dislikes": [[1, 2]], "expected": True},
        {"N": 2, "dislikes": [], "expected": True},
        {"N": 6, "dislikes": [[1,2],[1,3],[2,4],[2,5],[3,6],[4,6],[5,6]], "expected": False},
        {"N": 6, "dislikes": [[1,2],[1,3],[2,4],[2,5],[3,6],[4,5]], "expected": True},
        {"N": 10, "dislikes": [[1,2],[3,4],[5,6],[7,8],[9,10]], "expected": True},
        {"N": 10, "dislikes": [[1,2],[2,3],[3,1]], "expected": False}
    ]

    correct_count = 0
    for i, case in enumerate(test_cases):
        result = possible_bipartition(case["N"], case["dislikes"])
        if result == case["expected"]:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")

    print(f"{correct_count}/{len(test_cases)}")

solve()