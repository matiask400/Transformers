class WordFilter:
    def __init__(self, words):
        self.words = words

    def f(self, prefix, suffix):
        max_index = -1
        for i, word in enumerate(self.words):
            if word.startswith(prefix) and word.endswith(suffix):
                max_index = max(max_index, i)
        return max_index

def run_test_case(commands, inputs, expected_output):
    word_filter = None
    actual_output = []
    results = []
    for i in range(len(commands)):
        command = commands[i]
        input_args = inputs[i]
        if command == "WordFilter":
            word_filter = WordFilter(input_args[0])
            actual_output.append(None)
        elif command == "f":
            result = word_filter.f(input_args[0], input_args[1])
            actual_output.append(result)
            results.append(result == expected_output[i])

    num_correct = sum(results)
    num_total = len(results)

    for result in results:
        print(result)
    print(f"{num_correct}/{num_total}")

def main():
    # Example 1
    commands1 = ["WordFilter", "f"]
    inputs1 = [[["apple"]], ["a", "e"]]
    expected_output1 = [None, 0]
    run_test_case(commands1, inputs1, expected_output1)

    # Test case 2
    commands2 = ["WordFilter", "f"]
    inputs2 = [[["apple", "banana"]], ["b", "a"]]
    expected_output2 = [None, 1]
    run_test_case(commands2, inputs2, expected_output2)

    # Test case 3
    commands3 = ["WordFilter", "f"]
    inputs3 = [[["apple", "banana"]], ["ap", "na"]]
    expected_output3 = [None, 1]
    run_test_case(commands3, inputs3, expected_output3)

    # Test case 4
    commands4 = ["WordFilter", "f"]
    inputs4 = [[["apple", "banana"]], ["z", "x"]]
    expected_output4 = [None, -1]
    run_test_case(commands4, inputs4, expected_output4)

    # Test case 5: Multiple words with same prefix and suffix, return largest index
    commands5 = ["WordFilter", "f"]
    inputs5 = [[["apple", "apricot", "pineapple"]], ["ap", "e"]]
    expected_output5 = [None, 0]
    run_test_case(commands5, inputs5, expected_output5)

    # Test case 6: Multiple words with same prefix and suffix, return largest index
    commands6 = ["WordFilter", "f"]
    inputs6 = [[["apple", "apricot", "pineapple", "grapeapple"]], ["ap", "e"]]
    expected_output6 = [None, 3]
    run_test_case(commands6, inputs6, expected_output6)

    # Test case 7: Empty word list
    commands7 = ["WordFilter", "f"]
    inputs7 = [[[]], ["a", "e"]]
    expected_output7 = [None, -1]
    run_test_case(commands7, inputs7, expected_output7)

    # Test case 8: Empty prefix
    commands8 = ["WordFilter", "f"]
    inputs8 = [[["apple"]], ["", "e"]]
    expected_output8 = [None, 0]
    run_test_case(commands8, inputs8, expected_output8)

    # Test case 9: Empty suffix
    commands9 = ["WordFilter", "f"]
    inputs9 = [[["apple"]], ["a", ""]]
    expected_output9 = [None, 0]
    run_test_case(commands9, inputs9, expected_output9)

    # Test case 10: Empty prefix and suffix, should match all words if any suffix or prefix is ""
    commands10 = ["WordFilter", "f"]
    inputs10 = [[["apple", "banana"]], ["", ""]]
    expected_output10 = [None, 1]
    run_test_case(commands10, inputs10, expected_output10)

if __name__ == "__main__":
    main()