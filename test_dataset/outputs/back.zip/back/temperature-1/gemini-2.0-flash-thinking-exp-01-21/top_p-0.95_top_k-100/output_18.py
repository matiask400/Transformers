def shortest_subarray_to_remove(arr):
    n = len(arr)
    min_removed_length = n
    for i in range(n + 1):
        for j in range(i - 1, n):
            removed_length = max(0, j - i + 1)
            remaining_arr = arr[:i] + arr[j+1:]
            is_non_decreasing = True
            if len(remaining_arr) > 1:
                for k in range(len(remaining_arr) - 1):
                    if remaining_arr[k] > remaining_arr[k+1]:
                        is_non_decreasing = False
                        break
            if is_non_decreasing:
                min_removed_length = min(min_removed_length, removed_length)
    return min_removed_length

def run_tests():
    test_cases = [
        ([1,2,3,10,4,2,3,5], 3),
        ([5,4,3,2,1], 4),
        ([1,2,3], 0),
        ([1], 0),
        ([1,2,3,4,5], 0),
        ([5,4,3,2,1,0], 5),
        ([1,3,2,4,5], 1),
        ([1,2,3,4,1], 1),
        ([1,1,1,2,2,2,3,3,3], 0),
        ([3,2,1,2,3], 2),
        ([6,6,7,7,8,9,1,1,2,2,3,3,4,4,5,5], 6)
    ]
    num_tests = len(test_cases)
    correct_tests = 0
    for i, (arr, expected_output) in enumerate(test_cases):
        output = shortest_subarray_to_remove(arr)
        if output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False, Input: {arr}, Expected: {expected_output}, Output: {output}")
    print(f"\nCorrect tests: {correct_tests}/{num_tests}")

if __name__ == '__main__':
    run_tests()