def solve():
    def num_provinces(isConnected):
        n = len(isConnected)
        visited = [False] * n
        provinces_count = 0

        def dfs(city):
            visited[city] = True
            for neighbor in range(n):
                if isConnected[city][neighbor] == 1 and not visited[neighbor]:
                    dfs(neighbor)

        for city in range(n):
            if not visited[city]:
                provinces_count += 1
                dfs(city)
        return provinces_count

    test_cases = [
        {
            "input": [[1,1,0],[1,1,0],[0,0,1]],
            "expected": 2
        },
        {
            "input": [[1,0,0],[0,1,0],[0,0,1]],
            "expected": 3
        },
        {
            "input": [[1,0,0,1],[0,1,1,0],[0,1,1,1],[1,0,1,1]],
            "expected": 1
        }
    ]

    num_correct_tests = 0
    for i, test_case in enumerate(test_cases):
        input_isConnected = test_case["input"]
        expected_output = test_case["expected"]
        actual_output = num_provinces(input_isConnected)
        if actual_output == expected_output:
            print(True)
            num_correct_tests += 1
        else:
            print(False)

    print(f"{num_correct_tests}/{len(test_cases)}")

if __name__ == '__main__':
    solve()