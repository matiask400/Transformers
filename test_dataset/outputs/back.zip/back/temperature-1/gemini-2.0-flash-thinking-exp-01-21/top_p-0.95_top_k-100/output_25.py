def find_median_sorted_arrays(nums1, nums2):
    if len(nums1) > len(nums2):
        nums1, nums2 = nums2, nums1  # Ensure nums1 is shorter
    m, n = len(nums1), len(nums2)
    low, high = 0, m
    while low <= high:
        partitionX = (low + high) // 2
        partitionY = (m + n + 1) // 2 - partitionX

        maxLeftX = nums1[partitionX - 1] if partitionX > 0 else -float('inf')
        minRightX = nums1[partitionX] if partitionX < m else float('inf')

        maxLeftY = nums2[partitionY - 1] if partitionY > 0 else -float('inf')
        minRightY = nums2[partitionY] if partitionY < n else float('inf')

        if maxLeftX <= minRightY and maxLeftY <= minRightX:
            if (m + n) % 2 == 0:
                return (max(maxLeftX, maxLeftY) + min(minRightX, minRightY)) / 2.0
            else:
                return float(max(maxLeftX, maxLeftY))
        elif maxLeftX > minRightY:
            high = partitionX - 1
        else:
            low = partitionX + 1

def run_tests():
    test_cases = [
        (([1, 3], [2]), 2.00000),
        (([1, 2], [3, 4]), 2.50000),
        (([0, 0], [0, 0]), 0.00000),
        (([], [1]), 1.00000),
        (([2], []), 2.00000),
        (([1, 2, 5], [3, 4]), 3.00000),
        (([1, 2, 3, 4], [5, 6, 7, 8]), 4.50000),
        (([100, 200, 300], [1, 2, 3]), 51.50000),
        (([-2, -1], [3, 4]), 1.00000),
        (([-2, -1, 0], [3, 4, 5]), 1.50000)
    ]

    correct_count = 0
    for i, (inputs, expected_output) in enumerate(test_cases):
        nums1, nums2 = inputs
        actual_output = find_median_sorted_arrays(nums1, nums2)
        if abs(actual_output - expected_output) < 1e-5:
            print(True)
            correct_count += 1
        else:
            print(False)
        # print(f"Test {i+1}: Input: nums1={nums1}, nums2={nums2}, Expected: {expected_output}, Actual: {actual_output}")

    print(f"{correct_count}/{len(test_cases)}")

if __name__ == "__main__":
    run_tests()