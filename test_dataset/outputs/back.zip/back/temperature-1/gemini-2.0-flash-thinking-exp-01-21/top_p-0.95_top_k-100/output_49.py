from collections import Counter

def least_interval(tasks, n):
    if n == 0:
        return len(tasks)
    task_counts = Counter(tasks)
    max_freq = 0
    for task in task_counts:
        max_freq = max(max_freq, task_counts[task])
    num_max_freq_tasks = 0
    for task in task_counts:
        if task_counts[task] == max_freq:
            num_max_freq_tasks += 1
    return (max_freq - 1) * (n + 1) + num_max_freq_tasks

def run_tests():
    test_cases = [
        {
            "tasks": ["A","A","A","B","B","B"],
            "n": 2,
            "expected_output": 8
        },
        {
            "tasks": ["A","A","A","B","B","B"],
            "n": 0,
            "expected_output": 6
        },
        {
            "tasks": ["A","A","A","A","A","A","B","C","D","E","F","G"],
            "n": 2,
            "expected_output": 16
        },
        {
            "tasks": ["A","B"],
            "n": 2,
            "expected_output": 2
        },
        {
            "tasks": ["A","A"],
            "n": 2,
            "expected_output": 4
        },
        {
            "tasks": ["A","A","A"],
            "n": 2,
            "expected_output": 7
        },
        {
            "tasks": ["A","B","C","D","E","A","B","C","D","E"],
            "n": 2,
            "expected_output": 10
        }
    ]
    
    correct_count = 0
    total_count = len(test_cases)
    
    for i, test_case in enumerate(test_cases):
        tasks = test_case["tasks"]
        n = test_case["n"]
        expected_output = test_case["expected_output"]
        
        actual_output = least_interval(tasks, n)
        
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Input: tasks={tasks}, n={n}, Expected: {expected_output}, Actual: {actual_output})")
            
    print(f"\n{correct_count}/{total_count}")

if __name__ == '__main__':
    run_tests()