from collections import Counter

def solve():
    def is_possible_hand(hand, W):
        n = len(hand)
        if n % W != 0:
            return False
        count_map = Counter(hand)
        unique_nums = sorted(list(set(hand)))

        for start_num in unique_nums:
            while count_map[start_num] > 0:
                for i in range(W):
                    current_num = start_num + i
                    if count_map[current_num] == 0:
                        return False
                    count_map[current_num] -= 1
        return True

    def run_test(hand, W, expected_output):
        output = is_possible_hand(hand, W)
        if output == expected_output:
            print('True')
            return 1
        else:
            print('False')
            return 0

    test_cases = [
        (([1,2,3,6,2,3,4,7,8], 3), True),
        (([1,2,3,4,5], 4), False),
        (([1,2,3,4,5,6], 2), True),
        (([1,2,3,4,5,6], 3), True),
        (([1,2,3,4,5,6], 4), False),
        (([1,2,3,4,5,6], 5), False),
        (([1,2,3,4,5,6], 6), True),
        (([1,1,2,2,3,3], 3), True),
        (([1,1,1,2,2,2,3,3,3], 3), True),
        (([1,1,1,2,2,2,3,3], 3), False),
        (([1,1,2,2,3,3,4,4], 4), True),
        (([1,1,2,2,3,3,4,4,5], 4), False),
        (([1,2,3,7,8,9,10,11,12], 3), True),
        (([1,2,3,7,8,9,10,11,11], 3), False),
        (([1,2,3,7,8,9,10,11,12, 13, 14, 15], 3), True),
        (([1,2,3,7,8,9,10,11,12, 13, 14, 15, 16], 4), True),
        (([1,2,3,7,8,9,10,11,12, 13, 14, 15, 16, 17], 4), False),
    ]

    correct_tests = 0
    for case, expected in test_cases:
        hand, W = case
        correct_tests += run_test(hand, W, expected)

    total_tests = len(test_cases)
    print(f"{correct_tests}/{total_tests}")

solve()