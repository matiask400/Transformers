def solve_problem(customers_data, orders_data):
    """
    Finds customer names who have placed at least one order.

    Args:
        customers_data: A list of dictionaries representing the Customers table.
        orders_data: A list of dictionaries representing the Orders table.

    Returns:
        A list of customer names who have placed at least one order.
    """
    ordered_customer_ids = set()
    for order in orders_data:
        ordered_customer_ids.add(order['CustomerID'])

    result_names = []
    for customer in customers_data:
        if customer['CustomerID'] in ordered_customer_ids:
            result_names.append(customer['Name'])

    return result_names

def run_tests():
    test_cases = [
        {
            "customers_data": [
                {'CustomerID': 1, 'Name': 'Alice', 'City': 'New York'},
                {'CustomerID': 2, 'Name': 'Bob', 'City': 'Los Angeles'},
                {'CustomerID': 3, 'Name': 'Charlie', 'City': 'Chicago'}
            ],
            "orders_data": [
                {'OrderID': 101, 'CustomerID': 1, 'OrderDate': '2023-01-01'},
                {'OrderID': 102, 'CustomerID': 2, 'OrderDate': '2023-01-05'}
            ],
            "expected_output": ['Alice', 'Bob']
        },
        {
            "customers_data": [
                {'CustomerID': 1, 'Name': 'Alice', 'City': 'New York'},
                {'CustomerID': 2, 'Name': 'Bob', 'City': 'Los Angeles'}
            ],
            "orders_data": [],
            "expected_output": []
        },
        {
            "customers_data": [
                {'CustomerID': 1, 'Name': 'Alice', 'City': 'New York'}
            ],
            "orders_data": [
                {'OrderID': 101, 'CustomerID': 1, 'OrderDate': '2023-01-01'},
                {'OrderID': 102, 'CustomerID': 1, 'OrderDate': '2023-01-05'}
            ],
            "expected_output": ['Alice']
        },
        {
            "customers_data": [
                {'CustomerID': 1, 'Name': 'Alice', 'City': 'New York'},
                {'CustomerID': 2, 'Name': 'Bob', 'City': 'Los Angeles'},
                {'CustomerID': 3, 'Name': 'Charlie', 'City': 'Chicago'}
            ],
            "orders_data": [
                {'OrderID': 101, 'CustomerID': 3, 'OrderDate': '2023-01-01'},
                {'OrderID': 102, 'CustomerID': 1, 'OrderDate': '2023-01-05'},
                {'OrderID': 103, 'CustomerID': 2, 'OrderDate': '2023-01-10'}
            ],
            "expected_output": ['Alice', 'Bob', 'Charlie']
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        actual_output = solve_problem(test_case["customers_data"], test_case["orders_data"])
        if sorted(actual_output) == sorted(test_case["expected_output"]):
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Expected: {test_case['expected_output']}")
            print(f"  Actual:   {actual_output}")

    print(f"\nCorrect tests: {correct_tests}/{total_tests}")

if __name__ == "__main__":
    run_tests()