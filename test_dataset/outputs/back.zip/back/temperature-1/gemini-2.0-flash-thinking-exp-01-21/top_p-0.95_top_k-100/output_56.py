class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def isValidBST(root):
    def isValidBSTHelper(node, min_val, max_val):
        if not node:
            return True
        if min_val is not None and node.val <= min_val:
            return False
        if max_val is not None and node.val >= max_val:
            return False
        return isValidBSTHelper(node.left, min_val, node.val) and isValidBSTHelper(node.right, node.val, max_val)

    return isValidBSTHelper(root, None, None)

def build_tree(nodes):
    if not nodes:
        return None
    root = TreeNode(nodes[0])
    queue = [root]
    i = 1
    while queue and i < len(nodes):
        current_node = queue.pop(0)
        if i < len(nodes) and nodes[i] is not None:
            current_node.left = TreeNode(nodes[i])
            queue.append(current_node.left)
        i += 1
        if i < len(nodes) and nodes[i] is not None:
            current_node.right = TreeNode(nodes[i])
            queue.append(current_node.right)
        i += 1
    return root

def run_tests():
    tests = [
        ([2, 1, 3], True),
        ([5, 1, 4, None, None, 3, 6], False),
        ([1, None, 2, None, 3], True),
        ([3, None, 30, 10, None, None, 40], False),
        ([3, 9, 20, None, None, 15, 7], False),
        ([3, 9, 20, None, None, 15, 21], True),
        ([1], True),
        ([ ], True),
        ([2,2,2], False),
        ([0, -1], True),
        ([2,1,2], False)
    ]
    correct_count = 0
    for i, (input_tree, expected_output) in enumerate(tests):
        root = build_tree(input_tree)
        actual_output = isValidBST(root)
        if actual_output == expected_output:
            print(True)
            correct_count += 1
        else:
            print(False)
    print(f"{correct_count}/{len(tests)}")

if __name__ == '__main__':
    run_tests()