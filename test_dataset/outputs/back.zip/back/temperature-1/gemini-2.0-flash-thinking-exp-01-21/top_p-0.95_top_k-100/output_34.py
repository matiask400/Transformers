from fractions import Fraction

def solve():
    def calculate(val1, op, val2):
        val2 = Fraction(val2)
        if op == '+':
            return val1 + val2
        elif op == '-':
            return val1 - val2
        elif op == '*':
            return val1 * val2
        elif op == '/':
            if val2 == 0:
                return float('inf')
            return val1 / val2
        return None

    def find_min_operators(x, target):
        initial_value = Fraction(x)
        target_fraction = Fraction(target)
        if initial_value == target_fraction:
            return 0

        queue = [(initial_value, 0)]
        min_ops = {initial_value: 0}
        visited = {initial_value}

        while queue:
            current_value, current_ops = queue.pop(0)

            if current_value == target_fraction:
                return current_ops

            if current_ops >= 9: # Heuristic limit, to avoid very long search. Example 2 is 8.
                continue

            for op in ['+', '-', '*', '/']:
                next_value = calculate(current_value, op, x)

                if abs(next_value) > target_fraction * 2000: # Limit search range, heuristic.
                    continue

                if next_value not in visited:
                    visited.add(next_value)
                    min_ops[next_value] = current_ops + 1
                    queue.append((next_value, current_ops + 1))
                elif next_value in min_ops and current_ops + 1 < min_ops[next_value]:
                    min_ops[next_value] = current_ops + 1
                    queue.append((next_value, current_ops + 1))
        return -1 # Should not reach here based on problem description, but good to have.

    test_cases = [
        (3, 19, 5),
        (5, 501, 8),
        (100, 100000000, 3),
        (2, 2, 0),
        (2, 3, 1),
        (2, 4, 1),
        (2, 5, 2),
        (2, 6, 2),
        (2, 7, 3),
        (2, 8, 2),
        (2, 9, 3),
        (2, 10, 3),
        (2, 11, 4),
        (2, 12, 3),
        (6, 12, 1),
        (6, 7, 2),
        (6, 1, 1),
        (6, 36, 1),
        (6, 0, 1),
        (7, 49, 1),
        (7, 50, 2),
        (7, 51, 2),
        (7, 1, 1),
        (7, 0, 1),
        (7, 6, 2),
        (7, 8, 2),
        (10, 100, 1),
        (10, 101, 2),
        (10, 99, 2),
        (10, 1000, 2),
        (10, 999, 3),
        (10, 1001, 3),
    ]

    correct_count = 0
    for x, target, expected_output in test_cases:
        result = find_min_operators(x, target)
        if result == expected_output:
            print('True')
            correct_count += 1
        else:
            print('False')
            print(f"Input: x={x}, target={target}, Expected: {expected_output}, Got: {result}")

    print(f"{correct_count}/{len(test_cases)}")

solve()