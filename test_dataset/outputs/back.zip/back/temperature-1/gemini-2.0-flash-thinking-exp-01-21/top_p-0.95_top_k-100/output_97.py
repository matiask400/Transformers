def remove_vowels(s):
    vowels = ['a', 'e', 'i', 'o', 'u']
    new_string = ""
    for char in s:
        if char not in vowels:
            new_string += char
    return new_string

def test_remove_vowels():
    test_cases = [
        {"input": "leetcodeisacommunityforcoders", "expected": "ltcdscmmntyfrcdrs"},
        {"input": "aeiou", "expected": ""},
        {"input": "bcdfghjklmnpqrstvwxyz", "expected": "bcdfghjklmnpqrstvwxyz"},
        {"input": "", "expected": ""},
        {"input": "programming", "expected": "prgrammng"},
        {"input": "stringwithvowels", "expected": "strngwthvwls"}
    ]

    correct_count = 0
    total_count = len(test_cases)

    for test_case in test_cases:
        input_s = test_case["input"]
        expected_output = test_case["expected"]
        actual_output = remove_vowels(input_s)
        if actual_output == expected_output:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")

if __name__ == '__main__':
    test_remove_vowels()