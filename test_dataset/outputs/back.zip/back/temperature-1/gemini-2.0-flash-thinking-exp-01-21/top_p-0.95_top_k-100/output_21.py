def max_side_length(mat, threshold):
    rows = len(mat)
    cols = len(mat[0])

    prefix_sum = [[0] * cols for _ in range(rows)]

    for r in range(rows):
        for c in range(cols):
            prefix_sum[r][c] = mat[r][c]
            if r > 0:
                prefix_sum[r][c] += prefix_sum[r - 1][c]
            if c > 0:
                prefix_sum[r][c] += prefix_sum[r][c - 1]
            if r > 0 and c > 0:
                prefix_sum[r][c] -= prefix_sum[r - 1][c - 1]

    def get_square_sum(r, c, side):
        if r < 0 or c < 0 or r + side > rows or c + side > cols:
            return float('inf')
        row_end = r + side - 1
        col_end = c + side - 1
        square_sum = prefix_sum[row_end][col_end]
        if r > 0:
            square_sum -= prefix_sum[r - 1][col_end]
        if c > 0:
            square_sum -= prefix_sum[row_end][c - 1]
        if r > 0 and c > 0:
            square_sum += prefix_sum[r - 1][c - 1]
        return square_sum

    max_side = 0
    for side in range(1, min(rows, cols) + 1):
        found_square = False
        for r in range(rows - side + 1):
            for c in range(cols - side + 1):
                if get_square_sum(r, c, side) <= threshold:
                    found_square = True
                    break
            if found_square:
                break
        if found_square:
            max_side = side
        else:
            break
    return max_side

def run_tests():
    test_cases = [
        ([[1,1,3,2,4,3,2],[1,1,3,2,4,3,2],[1,1,3,2,4,3,2]], 4, 2),
        ([[2,2,2,2,2],[2,2,2,2,2],[2,2,2,2,2],[2,2,2,2,2],[2,2,2,2,2]], 1, 0),
        ([[1,1,1,1],[1,0,0,0],[1,0,0,0],[1,0,0,0]], 6, 3),
        ([[18,70],[61,1],[25,85],[14,40],[11,96],[97,96],[63,45]], 40184, 2),
        ([[1,1,1,1],[1,1,1,1],[1,1,1,1],[1,1,1,1]], 1, 0),
        ([[1,1,1,1],[1,1,1,1],[1,1,1,1],[1,1,1,1]], 4, 2),
        ([[1,1,1,1],[1,1,1,1],[1,1,1,1],[1,1,1,1]], 100, 4)
    ]
    correct_count = 0
    for i, (mat, threshold, expected) in enumerate(test_cases):
        result = max_side_length(mat, threshold)
        if result == expected:
            print(True)
            correct_count += 1
        else:
            print(False)
    print(f"{correct_count}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()