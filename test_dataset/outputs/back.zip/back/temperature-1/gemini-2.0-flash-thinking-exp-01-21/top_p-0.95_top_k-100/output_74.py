def solve():
    def is_concatenated_word(word, word_set):
        for i in range(1, len(word)):
            prefix = word[:i]
            suffix = word[i:]
            if prefix in word_set:
                if is_segmentable(suffix, word_set):
                    return True
        return False

    def is_segmentable(s, word_set):
        dp = [False] * (len(s) + 1)
        dp[0] = True
        for i in range(1, len(s) + 1):
            for j in range(i):
                if dp[j] and s[j:i] in word_set:
                    dp[i] = True
                    break
        return dp[len(s)]

    def get_concatenated_words(words):
        word_set = set(words)
        concatenated_words = []
        for word in words:
            if is_concatenated_word(word, word_set):
                concatenated_words.append(word)
        return concatenated_words

    def run_tests():
        test_cases = [
            {
                "input": ["cat","cats","catsdogcats","dog","dogcatsdog","hippopotamuses","rat","ratcatdogcat"],
                "expected_output": ["catsdogcats","dogcatsdog","ratcatdogcat"]
            },
            {
                "input": ["cat","dog","catdog"],
                "expected_output": ["catdog"]
            },
            {
                "input": ["a", "b", "ab", "abc"],
                "expected_output": ["ab"]
            },
            {
                "input": ["a", "aa", "aaa", "aaaa"],
                "expected_output": ["aa", "aaa", "aaaa"]
            },
            {
                "input": [""],
                "expected_output": []
            },
             {
                "input": ["cats","dog","catsdog"],
                "expected_output": ["catsdog"]
            }
        ]

        correct_tests = 0
        total_tests = len(test_cases)

        for i, test_case in enumerate(test_cases):
            input_words = test_case["input"]
            expected_output = test_case["expected_output"]
            actual_output = get_concatenated_words(input_words)
            if set(actual_output) == set(expected_output):
                print(f'Test {i+1}: True')
                correct_tests += 1
            else:
                print(f'Test {i+1}: False')
                print(f'  Input: {input_words}')
                print(f'  Expected: {expected_output}')
                print(f'  Actual: {actual_output}')

        print(f'{correct_tests}/{total_tests}')

    run_tests()

solve()