def num_distinct_islands(grid):
    """
    Counts the number of distinct islands in a 2D grid.

    Args:
        grid: A 2D array of 0's and 1's representing the grid.

    Returns:
        The number of distinct islands.
    """
    rows = len(grid)
    cols = len(grid[0])
    visited = [[False for _ in range(cols)] for _ in range(rows)]
    distinct_islands = set()

    def get_island_shape(r, c, current_island, start_r, start_c):
        if r < 0 or r >= rows or c < 0 or c >= cols or visited[r][c] or grid[r][c] == '0':
            return
        visited[r][c] = True
        current_island.append((r - start_r, c - start_c))  # Normalize island shape

        get_island_shape(r + 1, c, current_island, start_r, start_c)
        get_island_shape(r - 1, c, current_island, start_r, start_c)
        get_island_shape(r, c + 1, current_island, start_r, start_c)
        get_island_shape(r, c - 1, current_island, start_r, start_c)

    def normalize_island(island_shape):
        """Returns a normalized representation of the island shape (tuple of tuples)."""
        def to_tuple(shape):
            return tuple(shape)

        def rotate(shape):
            return sorted([(y, -x) for x, y in shape])

        def reflect(shape):
            return sorted([(-x, y) for x, y in shape])

        shapes = set()
        current_shape = sorted(island_shape)
        for _ in range(4):
            shapes.add(to_tuple(current_shape))
            shapes.add(to_tuple(reflect(current_shape))) # add reflection too
            current_shape = rotate(current_shape)

        return min(shapes)


    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == '1' and not visited[r][c]:
                current_island = []
                get_island_shape(r, c, current_island, r, c)
                normalized_shape = normalize_island(current_island)
                distinct_islands.add(normalized_shape)

    return len(distinct_islands)


def test_num_distinct_islands():
    tests = [
        {
            "grid": [
                "11000",
                "10000",
                "00001",
                "00011"
            ],
            "expected": 1
        },
        {
            "grid": [
                "11100",
                "10001",
                "01001",
                "01110"
            ],
            "expected": 2
        },
        {
            "grid": [
                "11",
                "1"
            ],
            "expected": 1
        },
        {
            "grid": [
                " 1",
                "11"
            ],
            "expected": 1
        },
        {
            "grid": [
                "110",
                "110"
            ],
            "expected": 1
        },
         {
            "grid": [
                "110",
                "011"
            ],
            "expected": 2
        },
        {
            "grid": [
                "1",
            ],
            "expected": 1
        },
        {
            "grid": [
                "0",
            ],
            "expected": 0
        },
        {
            "grid": [
                "101",
                "111",
                "101"
            ],
            "expected": 1
        },
         {
            "grid": [
                "10",
                "10"
            ],
            "expected": 1
        },
        {
            "grid": [
                "10",
                "01"
            ],
            "expected": 2
        }

    ]

    num_correct = 0
    for i, test in enumerate(tests):
        grid_list = [list(row) for row in test["grid"]] # Convert string grid to list of lists
        actual_output = num_distinct_islands(grid_list)
        expected_output = test["expected"]
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {test['grid']}")
            print(f"  Expected Output: {expected_output}")
            print(f"  Actual Output:   {actual_output}")

    print(f"\n{num_correct} correct out of {len(tests)}")

if __name__ == '__main__':
    test_num_distinct_islands()