def solve():
    def num_jewels_in_stones(jewels: str, stones: str) -> int:
        jewel_set = set(jewels)
        count = 0
        for stone in stones:
            if stone in jewel_set:
                count += 1
        return count

    test_cases = [
        {
            "jewels": "aA",
            "stones": "aAAbbbb",
            "expected": 3
        },
        {
            "jewels": "z",
            "stones": "ZZ",
            "expected": 0
        },
        {
            "jewels": "abc",
            "stones": "def",
            "expected": 0
        },
        {
            "jewels": "Ab",
            "stones": "AaBb",
            "expected": 2
        },
        {
            "jewels": "K",
            "stones": "KKKK",
            "expected": 4
        },
        {
            "jewels": "xyz",
            "stones": "xYz",
            "expected": 2
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        jewels = test_case["jewels"]
        stones = test_case["stones"]
        expected_output = test_case["expected"]
        actual_output = num_jewels_in_stones(jewels, stones)
        if actual_output == expected_output:
            print(True)
            correct_tests += 1
        else:
            print(False)

    print(f"{correct_tests}/{total_tests}")

solve()