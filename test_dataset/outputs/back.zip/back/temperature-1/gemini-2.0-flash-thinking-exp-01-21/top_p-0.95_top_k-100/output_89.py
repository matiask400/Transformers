class GridMaster:
    def __init__(self, grid):
        self.grid = grid
        self.robot_pos = None
        self.target_pos = None
        self.rows = len(grid)
        self.cols = len(grid[0]) if self.rows > 0 else 0
        for r in range(self.rows):
            for c in range(self.cols):
                if grid[r][c] == -1:
                    self.robot_pos = [r, c]
                elif grid[r][c] == 2:
                    self.target_pos = [r, c]
        self.current_pos = list(self.robot_pos)

    def canMove(self, direction):
        r, c = self.current_pos
        if direction == 'U':
            nr, nc = r - 1, c
        elif direction == 'D':
            nr, nc = r + 1, c
        elif direction == 'L':
            nr, nc = r, c - 1
        elif direction == 'R':
            nr, nc = r, c + 1
        else:
            return False

        if 0 <= nr < self.rows and 0 <= nc < self.cols and self.grid[nr][nc] != 0:
            return True
        return False

    def move(self, direction):
        if not self.canMove(direction):
            return
        r, c = self.current_pos
        if direction == 'U':
            self.current_pos = [r - 1, c]
        elif direction == 'D':
            self.current_pos = [r + 1, c]
        elif direction == 'L':
            self.current_pos = [r, c - 1]
        elif direction == 'R':
            self.current_pos = [r, c + 1]

    def isTarget(self):
        return self.current_pos == self.target_pos

def find_shortest_path(grid):
    master = GridMaster(grid)

    def solve():
        grid_map = {}
        visited = set()

        def explore(r, c):
            grid_map[(r, c)] = 1  # Mark as reachable
            visited.add((r,c))

            for direction, dr, dc, back_dir in [('U', -1, 0, 'D'), ('D', 1, 0, 'U'), ('L', 0, -1, 'R'), ('R', 0, 1, 'L')]:
                nr, nc = r + dr, c + dc
                if (nr, nc) not in visited and master.canMove(direction):
                    master.move(direction)
                    explore(nr, nc)
                    master.move(back_dir) # Backtrack

        explore(0, 0) # Start exploring from relative (0,0) which is robot start

        q = [(0, 0, 0)] # (r, c, dist)
        bfs_visited = set([(0,0)])

        while q:
            r, c, dist = q.pop(0)
            master.current_pos = [master.robot_pos[0] + r, master.robot_pos[1] + c] # set master's pos for isTarget check. Not actually moving in grid.

            if master.isTarget():
                return dist

            for direction, dr, dc in [('U', -1, 0), ('D', 1, 0), ('L', 0, -1), ('R', 0, 1)]:
                nr, nc = r + dr, c + dc
                if (nr, nc) in grid_map and (nr, nc) not in bfs_visited:
                    bfs_visited.add((nr, nc))
                    q.append((nr, nc, dist + 1))
        return -1

    return solve()


def test_cases():
    tests = [
        ([[1, 2], [-1, 0]], 2),
        ([[0, 0, -1], [1, 1, 1], [2, 0, 0]], 4),
        ([[-1, 0], [0, 2]], -1),
        ([[-1,1,1],[0,1,1],[0,1,2]], 4),
        ([[-1,1,1],[1,0,1],[1,1,2]], 4),
        ([[-1, 1, 1, 1, 1], [1, 1, 0, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 2]], 8),
        ([[-1, 1, 0, 1, 1], [1, 1, 0, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1, 2]], 10), # No path in first 8 directions, need to explore more
        ([[-1,0,0,0],[1,1,1,0],[0,0,1,2]], -1), # blocked path
        ([[-1,1,1,1],[1,0,0,1],[1,0,0,1],[1,1,1,2]], 7), # path around blocked area
        ([[-1,1],[1,2]], 1), # Simple case
        ([[1,1,1],[-1,1,1],[1,1,2]], 2), # Start middle, target bottom right
        ([[2,1,1],[1,1,1],[1,1,-1]], 2), # Target top left, start bottom right
        ([[-1,1,1,1,1],[1,1,1,1,1],[1,1,0,1,1],[1,1,1,1,1],[1,1,1,1,2]], 8), # Block in middle path

    ]

    correct_count = 0
    for i, (grid, expected_output) in enumerate(tests):
        output = find_shortest_path(grid)
        if output == expected_output:
            print(f'Test {i+1}: True')
            correct_count += 1
        else:
            print(f'Test {i+1}: False')
            print(f'  Input: {grid}')
            print(f'  Expected Output: {expected_output}')
            print(f'  Your Output: {output}')

    print(f"\n{correct_count} correct out of {len(tests)}")

if __name__ == '__main__':
    test_cases()