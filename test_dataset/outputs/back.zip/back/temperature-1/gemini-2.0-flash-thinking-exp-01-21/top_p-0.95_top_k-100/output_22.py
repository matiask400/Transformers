def unique_occurrences(arr):
    counts = {}
    for num in arr:
        counts[num] = counts.get(num, 0) + 1
    occurrences = set(counts.values())
    return len(occurrences) == len(counts)

def run_tests():
    test_cases = [
        ([1,2,2,1,1,3], True),
        ([1,2], False),
        ([-3,0,1,-3,1,1,1,-3,10,0], True),
        ([1,1,1,2,2,2,3,3], False),
        ([10, 10, 10], True),
        ([ ], True),
        ([7], True),
        ([1, 2, 3, 4, 5], True),
        ([1, 1, 2, 2, 3, 3], False),
        ([1, 2, 2, 3, 3, 3], False)
    ]
    correct_tests = 0
    total_tests = len(test_cases)

    for i, (arr, expected_output) in enumerate(test_cases):
        actual_output = unique_occurrences(arr)
        if actual_output == expected_output:
            print(f'Test {i+1}: True')
            correct_tests += 1
        else:
            print(f'Test {i+1}: False')

    print(f'{correct_tests}/{total_tests}')

if __name__ == '__main__':
    run_tests()