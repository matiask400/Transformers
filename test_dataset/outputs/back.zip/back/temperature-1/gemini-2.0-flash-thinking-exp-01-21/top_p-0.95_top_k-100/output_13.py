def advantage_count(A, B):
    sorted_A = sorted(A)
    indexed_B = sorted([(b, i) for i, b in enumerate(B)])
    n = len(A)
    output = [0] * n
    a_start_ptr = 0
    a_end_ptr = n - 1

    for b_val, b_index in indexed_B:
        found_advantage = False
        for i in range(a_start_ptr, n):
            if sorted_A[i] > b_val:
                output[b_index] = sorted_A[i]
                sorted_A[i] = -1 # Mark as used
                a_start_ptr = i + 1
                found_advantage = True
                break
        if not found_advantage:
            for i in range(a_start_ptr, n):
                if sorted_A[i] != -1:
                    output[b_index] = sorted_A[i]
                    sorted_A[i] = -1
                    a_start_ptr = i + 1
                    break
    return output

def run_tests():
    tests = [
        (([2,7,11,15], [1,10,4,11]), [2,11,7,15]),
        (([12,24,8,32], [13,25,32,11]), [24,32,8,12]),
        (([0,0,0,0], [1,2,3,4]), [0,0,0,0]),
        (([5,6,7,8], [1,2,3,4]), [5,6,7,8]),
        (([1,2,3,4], [5,6,7,8]), [1,2,3,4]),
        (([1,2,3,4], [1,2,3,4]), [2,3,4,1]),
        (([1,2,3,4], [4,3,2,1]), [2,3,4,1]),
        (([1,2,3,4], [1,1,1,1]), [2,3,4,1]),
        (([1,1,1,1], [1,2,3,4]), [1,1,1,1]),
        (([10, 20, 30, 40], [5, 15, 25, 35]), [10, 20, 30, 40]),
        (([10, 20, 30, 40], [15, 25, 35, 45]), [20, 30, 40, 10]),
    ]
    correct_count = 0
    for i, (input_args, expected_output) in enumerate(tests):
        A, B = input_args
        output = advantage_count(A, B)
        if output == expected_output:
            print(f'Test {i+1}: True')
            correct_count += 1
        else:
            print(f'Test {i+1}: False, Input: A={A}, B={B}, Output={output}, Expected={expected_output}')
    print(f'{correct_count}/{len(tests)}')

if __name__ == '__main__':
    run_tests()