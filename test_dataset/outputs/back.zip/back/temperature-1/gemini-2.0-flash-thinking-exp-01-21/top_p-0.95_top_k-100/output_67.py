def isPalindrome(x):
    """
    Given an integer x, return true if x is palindrome integer.

    An integer is a palindrome when it reads the same backward as forward.
    For example, 121 is palindrome while 123 is not.

    Args:
        x (int): An integer.

    Returns:
        bool: True if x is a palindrome, False otherwise.
    """
    if x < 0:
        return False
    original_x = x
    reversed_x = 0
    while x > 0:
        digit = x % 10
        reversed_x = reversed_x * 10 + digit
        x = x // 10
    return original_x == reversed_x

def run_tests():
    test_cases = [
        (121, True),
        (-121, False),
        (10, False),
        (-101, False),
        (0, True),
        (1, True),
        (1221, True),
        (12321, True),
        (123, False),
        (999, True),
        (1001, True),
        (-5, False),
        (-0, False), # negative zero is not generally considered a palindrome in this context, but based on problem description negative numbers are not palindromes
    ]
    correct_count = 0
    total_count = len(test_cases)

    for input_x, expected_output in test_cases:
        actual_output = isPalindrome(input_x)
        if actual_output == expected_output:
            print('True')
            correct_count += 1
        else:
            print('False')

    print(f"{correct_count}/{total_count}")

if __name__ == '__main__':
    run_tests()