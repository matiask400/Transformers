def solve_problem(prices):
    """
    Calculates the maximum profit from buying and selling stocks.

    Args:
        prices: A list of stock prices.

    Returns:
        The maximum profit achievable.
    """
    max_profit = 0
    for i in range(len(prices) - 1):
        if prices[i+1] > prices[i]:
            max_profit += prices[i+1] - prices[i]
    return max_profit

def run_tests():
    """
    Runs test cases and prints the results.
    """
    test_cases = [
        {"input": [7,1,5,3,6,4], "expected_output": 7},
        {"input": [1,2,3,4,5], "expected_output": 4},
        {"input": [7,6,4,3,1], "expected_output": 0},
        {"input": [2,1,2,0,1], "expected_output": 2},
        {"input": [1], "expected_output": 0},
        {"input": [], "expected_output": 0},
        {"input": [1, 2], "expected_output": 1},
        {"input": [2, 1], "expected_output": 0},
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        prices = test_case["input"]
        expected_output = test_case["expected_output"]
        actual_output = solve_problem(prices)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"{correct_tests}/{total_tests}")

if __name__ == '__main__':
    run_tests()