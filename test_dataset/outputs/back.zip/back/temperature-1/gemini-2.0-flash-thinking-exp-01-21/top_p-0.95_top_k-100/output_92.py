def to_hexspeak(num_str):
    n = int(num_str)
    hex_str = hex(n)[2:].upper()
    hexspeak_str = ""
    for char in hex_str:
        if char == '0':
            hexspeak_str += 'O'
        elif char == '1':
            hexspeak_str += 'I'
        else:
            hexspeak_str += char
    valid_hexspeak_chars = set("ABCDEFIO")
    for char in hexspeak_str:
        if char not in valid_hexspeak_chars:
            return "ERROR"
    return hexspeak_str

def run_tests():
    tests = [
        {"input": "257", "expected": "IOI"},
        {"input": "3", "expected": "ERROR"},
        {"input": "300", "expected": "ERROR"},
        {"input": "7420583551", "expected": "ERROR"},
        {"input": "0", "expected": "O"},
        {"input": "1", "expected": "I"},
        {"input": "2", "expected": "2"}, # Should be ERROR
        {"input": "10", "expected": "IO"},
        {"input": "11", "expected": "II"},
        {"input": "100", "expected": "ERROR"}, # 100 in decimal is 64 in hex, should be "40" -> "4O" -> ERROR
        {"input": "64", "expected": "40"}, # Expected is actually "ERROR"
        {"input": "65", "expected": "41"}, # Expected is actually "ERROR"
        {"input": "687", "expected": "2AF"},
        {"input": "282833757537161", "expected": "BABEBEEF"},
        {"input": "1234567890", "expected": "ERROR"},
        {"input": "4294967295", "expected": "FFFFFFFF"},
        {"input": "18446744073709551615", "expected": "FFFFFFFFFFFFFFFF"},
        {"input": "16", "expected": "10"}, # Expected ERROR
        {"input": "17", "expected": "11"}, # Expected ERROR
        {"input": "26", "expected": "1A"}, # Expected ERROR
        {"input": "27", "expected": "1B"}, # Expected ERROR
        {"input": "255", "expected": "FF"},
        {"input": "256", "expected": "100"}, # Expected ERROR
    ]

    correct_count = 0
    for i, test in enumerate(tests):
        input_num = test["input"]
        expected_output = test["expected"]
        actual_output = to_hexspeak(input_num)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{correct_count}/{len(tests)}")

    # Corrected tests based on further understanding of the problem.
    corrected_tests = [
        {"input": "257", "expected": "IOI"},
        {"input": "3", "expected": "ERROR"},
        {"input": "300", "expected": "ERROR"},
        {"input": "7420583551", "expected": "ERROR"},
        {"input": "0", "expected": "O"},
        {"input": "1", "expected": "I"},
        {"input": "2", "expected": "ERROR"},
        {"input": "10", "expected": "IO"},
        {"input": "11", "expected": "II"},
        {"input": "100", "expected": "ERROR"},
        {"input": "64", "expected": "ERROR"},
        {"input": "65", "expected": "ERROR"},
        {"input": "687", "expected": "2AF"}, # corrected expected
        {"input": "282833757537161", "expected": "BABEBEEF"},
        {"input": "1234567890", "expected": "ERROR"},
        {"input": "4294967295", "expected": "FFFFFFFF"},
        {"input": "18446744073709551615", "expected": "FFFFFFFFFFFFFFFF"},
        {"input": "16", "expected": "ERROR"},
        {"input": "17", "expected": "ERROR"},
        {"input": "26", "expected": "ERROR"},
        {"input": "27", "expected": "ERROR"},
        {"input": "255", "expected": "FF"},
        {"input": "256", "expected": "ERROR"},
    ]

    corrected_correct_count = 0
    for i, test in enumerate(corrected_tests):
        input_num = test["input"]
        expected_output = test["expected"]
        actual_output = to_hexspeak(input_num)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            corrected_correct_count += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{corrected_correct_count}/{len(corrected_tests)}")


if __name__ == '__main__':
    run_tests()