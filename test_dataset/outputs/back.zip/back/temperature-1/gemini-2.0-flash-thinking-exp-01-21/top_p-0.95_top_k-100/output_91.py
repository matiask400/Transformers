def solve():
    schema = {
        "Employees": {
            "columns": ["emp_id", "emp_name", "department", "salary"],
            "data": [
                {"emp_id": 1, "emp_name": "Alice", "department": "Sales", "salary": 50000},
                {"emp_id": 2, "emp_name": "Bob", "department": "Marketing", "salary": 60000},
                {"emp_id": 3, "emp_name": "Charlie", "department": "Sales", "salary": 55000},
                {"emp_id": 4, "emp_name": "David", "department": "Engineering", "salary": 70000},
            ]
        }
    }

    def execute_sql(schema, query):
        parts = query.split()
        select_cols_str = parts[1].split(',')
        from_table = parts[3]
        where_clause = None
        if "WHERE" in parts:
            where_clause_index = parts.index("WHERE")
            where_clause = parts[where_clause_index + 1:]

        table_data = schema[from_table]["data"]
        select_cols = [col.strip() for col in select_cols_str]

        results = []
        for row in table_data:
            if where_clause:
                condition_col = where_clause[0]
                condition_op = where_clause[1]
                condition_val = where_clause[2].strip("'")

                if condition_op == "=":
                    if row[condition_col] == condition_val:
                        results.append({col: row[col] for col in select_cols})
            else:
                results.append({col: row[col] for col in select_cols})

        if len(select_cols) == 1:
            return [res[select_cols[0]] for res in results]
        return results

    test_cases = [
        {
            "query": "SELECT emp_name FROM Employees WHERE department = 'Sales'",
            "expected_output": ['Alice', 'Charlie']
        },
        {
            "query": "SELECT salary FROM Employees WHERE emp_name = 'Bob'",
            "expected_output": [60000]
        },
        {
            "query": "SELECT emp_name, salary FROM Employees WHERE department = 'Marketing'",
            "expected_output": [{'emp_name': 'Bob', 'salary': 60000}]
        },
        {
            "query": "SELECT emp_id FROM Employees",
            "expected_output": [1, 2, 3, 4]
        },
        {
            "query": "SELECT department FROM Employees WHERE emp_name = 'NonExistent'",
            "expected_output": []
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        query = test_case["query"]
        expected_output = test_case["expected_output"]
        actual_output = execute_sql(schema, query)

        test_passed = (actual_output == expected_output)
        print(f"{test_passed}")
        if test_passed:
            correct_tests += 1

    print(f"{correct_tests}/{total_tests}")

solve()