import functools

def reorder_logs(logs):
    letter_logs = []
    digit_logs = []
    for log in logs:
        parts = log.split(' ', 1)
        identifier = parts[0]
        content = parts[1]
        if content[0].isdigit():
            digit_logs.append(log)
        else:
            letter_logs.append(log)

    def compare_logs(log1, log2):
        parts1 = log1.split(' ', 1)
        parts2 = log2.split(' ', 1)
        identifier1 = parts1[0]
        content1 = parts1[1]
        identifier2 = parts2[0]
        content2 = parts2[1]

        if content1 < content2:
            return -1
        elif content1 > content2:
            return 1
        else:
            if identifier1 < identifier2:
                return -1
            elif identifier1 > identifier2:
                return 1
            else:
                return 0

    letter_logs.sort(key=functools.cmp_to_key(compare_logs))

    return letter_logs + digit_logs

def test_reorder_logs():
    tests = [
        {
            "input": ["dig1 8 1 5 1","let1 art can","dig2 3 6","let2 own kit dig","let3 art zero"],
            "expected": ["let1 art can","let3 art zero","let2 own kit dig","dig1 8 1 5 1","dig2 3 6"]
        },
        {
            "input": ["a1 9 2 3 1","g1 act car","zo4 4 7","ab1 off key dog","a8 act zoo"],
            "expected": ["g1 act car","a8 act zoo","ab1 off key dog","a1 9 2 3 1","zo4 4 7"]
        },
        {
            "input": ["j mo", "5 qk", "bb", "r h"],
            "expected": ["bb", "j mo", "r h", "5 qk"]
        },
        {
            "input": ["mi2 jog mid pet", "wz3 34 54 39", "t2 mid pet", "o a my war"],
            "expected": ["mi2 jog mid pet", "o a my war", "t2 mid pet", "wz3 34 54 39"]
        }
    ]

    correct_tests = 0
    for i, test in enumerate(tests):
        actual_output = reorder_logs(test["input"])
        if actual_output == test["expected"]:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {test['input']}")
            print(f"  Expected: {test['expected']}")
            print(f"  Actual: {actual_output}")

    print(f"\n{correct_tests} correct over {len(tests)}")

if __name__ == '__main__':
    test_reorder_logs()