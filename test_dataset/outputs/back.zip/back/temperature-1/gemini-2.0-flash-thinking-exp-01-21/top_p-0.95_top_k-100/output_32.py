def count_subarrays_divisible_by_k(A, K):
    count = 0
    n = len(A)
    for i in range(n):
        for j in range(i, n):
            sub_array = A[i:j+1]
            sub_array_sum = sum(sub_array)
            if sub_array_sum % K == 0:
                count += 1
    return count

def run_tests():
    test_cases = [
        {"input": {"A": [4, 5, 0, -2, -3, 1], "K": 5}, "expected": 7},
        {"input": {"A": [5], "K": 5}, "expected": 1},
        {"input": {"A": [5, 5], "K": 5}, "expected": 3},
        {"input": {"A": [1, 2, 3, 4, 5], "K": 6}, "expected": 1},
        {"input": {"A": [0, 0, 0], "K": 2}, "expected": 6},
        {"input": {"A": [-1, 1, -1, 1], "K": 2}, "expected": 6},
        {"input": {"A": [-2, -3], "K": 5}, "expected": 1},
    ]

    correct_count = 0
    for i, test_case in enumerate(test_cases):
        input_data = test_case["input"]
        expected_output = test_case["expected"]
        actual_output = count_subarrays_divisible_by_k(input_data["A"], input_data["K"])
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{correct_count}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()