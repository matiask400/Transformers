import re

def mostFrequentWord(paragraph, banned):
    """
    Given a string paragraph and a string array of the banned words banned,
    return the most frequent word that is not banned.

    Args:
        paragraph (str): The input paragraph.
        banned (list[str]): A list of banned words.

    Returns:
        str: The most frequent word that is not banned.
    """
    paragraph = paragraph.lower()
    for punc in "!?',;.":
        paragraph = paragraph.replace(punc, " ")
    words = paragraph.split()
    word_counts = {}
    banned_words = set(banned)

    for word in words:
        if word not in banned_words:
            word_counts[word] = word_counts.get(word, 0) + 1

    max_count = 0
    most_frequent_word = ""
    for word, count in word_counts.items():
        if count > max_count:
            max_count = count
            most_frequent_word = word

    return most_frequent_word

def run_tests():
    test_cases = [
        {
            "paragraph": "Bob hit a ball, the hit BALL flew far after it was hit.",
            "banned": ["hit"],
            "expected_output": "ball"
        },
        {
            "paragraph": "a.",
            "banned": [],
            "expected_output": "a"
        },
        {
            "paragraph": "a, a, a, a, b,b,b,c, c",
            "banned": ["a"],
            "expected_output": "b"
        },
        {
            "paragraph": "a, a, a, a, b,b,b,c, c",
            "banned": ["a", "b"],
            "expected_output": "c"
        },
        {
            "paragraph": "a, a, a, a, b,b,b,c, c",
            "banned": ["d"],
            "expected_output": "a"
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        paragraph = test_case["paragraph"]
        banned = test_case["banned"]
        expected_output = test_case["expected_output"]
        actual_output = mostFrequentWord(paragraph, banned)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"\n{correct_tests}/{total_tests}")

if __name__ == '__main__':
    run_tests()