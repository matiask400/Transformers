def find_missing_number(nums):
    n = len(nums)
    expected_sum = n * (n + 1) // 2
    actual_sum = sum(nums)
    return expected_sum - actual_sum

def run_tests():
    test_cases = [
        {"nums": [3, 0, 1], "expected_output": 2},
        {"nums": [0, 1], "expected_output": 2},
        {"nums": [9, 6, 4, 2, 3, 5, 7, 0, 1], "expected_output": 8},
        {"nums": [0], "expected_output": 1}
    ]
    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        nums = test_case["nums"]
        expected_output = test_case["expected_output"]
        actual_output = find_missing_number(nums)
        if actual_output == expected_output:
            print(True)
            correct_tests += 1
        else:
            print(False)

    print(f"{correct_tests}/{total_tests}")

if __name__ == '__main__':
    run_tests()