def solve_lock(deadends, target):
    """
    Finds the minimum total number of turns required to open the lock.

    Args:
        deadends: A list of dead end codes.
        target: The target code to unlock the lock.

    Returns:
        The minimum number of turns required, or -1 if impossible.
    """
    deadends_set = set(deadends)
    if "0000" in deadends_set:
        return -1
    if "0000" == target:
        return 0

    queue = [("0000", 0)]
    visited = {"0000"}

    while queue:
        current_state, turns = queue.pop(0)

        if current_state == target:
            return turns

        for i in range(4):
            digit = int(current_state[i])
            next_digit = str((digit + 1) % 10)
            prev_digit = str((digit - 1 + 10) % 10)

            next_state_forward = list(current_state)
            next_state_forward[i] = next_digit
            next_state_forward = "".join(next_state_forward)

            next_state_backward = list(current_state)
            next_state_backward[i] = prev_digit
            next_state_backward = "".join(next_state_backward)

            if next_state_forward not in deadends_set and next_state_forward not in visited:
                visited.add(next_state_forward)
                queue.append((next_state_forward, turns + 1))

            if next_state_backward not in deadends_set and next_state_backward not in visited:
                visited.add(next_state_backward)
                queue.append((next_state_backward, turns + 1))

    return -1

def run_tests():
    tests = [
        {
            "deadends": ["0201","0101","0102","1212","2002"],
            "target": "0202",
            "expected": 6
        },
        {
            "deadends": ["8888"],
            "target": "0009",
            "expected": 1
        },
        {
            "deadends": ["8887","8889","8878","8898","8788","8988","7888","9888"],
            "target": "8888",
            "expected": -1
        },
        {
            "deadends": ["0000"],
            "target": "8888",
            "expected": -1
        },
        {
            "deadends": [],
            "target": "9999",
            "expected": 8
        },
        {
            "deadends": ["0001"],
            "target": "0002",
            "expected": 2
        },
        {
            "deadends": ["9999"],
            "target": "0000",
            "expected": 1
        },
        {
            "deadends": ["1111"],
            "target": "9999",
            "expected": 16
        }
    ]

    correct_tests = 0
    for i, test in enumerate(tests):
        result = solve_lock(test["deadends"], test["target"])
        if result == test["expected"]:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"{correct_tests}/{len(tests)}")

if __name__ == '__main__':
    run_tests()