def get_numeric_value(s):
    value = 0
    for char in s:
        value += ord(char) - ord('a') + 1
    return value

def solve():
    n = int(input())
    k = int(input())
    
    def find_smallest_string(length, target_value):
        result = ""
        current_value = target_value
        for i in range(length):
            for j in range(ord('a'), ord('z') + 1):
                char = chr(j)
                char_value = ord(char) - ord('a') + 1
                remaining_length = length - (i + 1)
                remaining_value_needed = current_value - char_value
                if remaining_length == 0:
                    if remaining_value_needed == 0:
                        result += char
                        current_value = remaining_value_needed
                        break
                else:
                    min_remaining_value = remaining_length * 1
                    max_remaining_value = remaining_length * 26
                    if min_remaining_value <= remaining_value_needed <= max_remaining_value:
                        result += char
                        current_value = remaining_value_needed
                        break
            else:
                # This should not happen given the problem constraints
                raise Exception("No character found")
        return result

    output_string = find_smallest_string(n, k)
    return output_string

def run_tests():
    test_cases = [
        ((3, 27), "aay"),
        ((5, 73), "aaszz"),
        ((1, 1), "a"),
        ((2, 2), "aa"),
        ((2, 26 + 1), "ay"),
        ((2, 52), "zz"),
        ((4, 4), "aaaa"),
        ((4, 104), "zzzz"),
        ((4, 50), "aaex"),
        ((5, 10), "aaaaa"),
        ((5, 130), "zzzzz"),
        ((6, 6), "aaaaaa"),
        ((6, 156), "zzzzzz"),
        ((6, 70), "aaaacz"),
        ((10, 260), "zzzzzzzzzz"),
        ((10, 10), "aaaaaaaaaa"),
        ((1, 26), "z"),
        ((10, 200), "aaaaaaapqz"),
        ((5, 70), "aassx"),
        ((5, 71), "aassy"),
        ((5, 72), "aassz"),
        ((5, 73), "aaszz"),
    ]
    
    correct_count = 0
    for i, ((n, k), expected_output) in enumerate(test_cases):
        actual_output = find_smallest_string(n, k)
        if actual_output == expected_output:
            print(f'Test {i+1}: True')
            correct_count += 1
        else:
            print(f'Test {i+1}: False, Input: n={n}, k={k}, Expected: {expected_output}, Actual: {actual_output}')
            
    print(f'{correct_count}/{len(test_cases)}')

def main():
    run_tests()

def find_smallest_string(length, target_value):
    result = ""
    current_value = target_value
    for i in range(length):
        for j in range(ord('a'), ord('z') + 1):
            char = chr(j)
            char_value = ord(char) - ord('a') + 1
            remaining_length = length - (i + 1)
            remaining_value_needed = current_value - char_value
            if remaining_length == 0:
                if remaining_value_needed == 0:
                    result += char
                    current_value = remaining_value_needed
                    break
            else:
                min_remaining_value = remaining_length * 1
                max_remaining_value = remaining_length * 26
                if min_remaining_value <= remaining_value_needed <= max_remaining_value:
                    result += char
                    current_value = remaining_value_needed
                    break
        else:
            # This should not happen given the problem constraints
            raise Exception("No character found")
    return result

if __name__ == "__main__":
    main()