def flip_game(currentState):
    """
    Finds all possible states of the string currentState after one valid move.

    Args:
        currentState: A string containing only '+' and '-'.

    Returns:
        A list of strings, where each string is a possible state after one valid move.
        If there is no valid move, return an empty list [].
    """
    possible_states = []
    for i in range(len(currentState) - 1):
        if currentState[i:i+2] == "++":
            new_state = list(currentState)
            new_state[i:i+2] = ['-', '-']
            possible_states.append("".join(new_state))
    return possible_states

def run_tests():
    test_cases = [
        {
            "currentState": "++++",
            "expected_output": ["--++", "+--+", "++--"]
        },
        {
            "currentState": "+",
            "expected_output": []
        },
        {
            "currentState": "--",
            "expected_output": []
        },
        {
            "currentState": "+-+",
            "expected_output": []
        },
        {
            "currentState": "++--++",
            "expected_output": ["-- --++", "+----++", "++-- --"]
        }
    ]

    correct_count = 0
    for i, test_case in enumerate(test_cases):
        actual_output = flip_game(test_case["currentState"])
        expected_output = test_case["expected_output"]

        actual_output.sort()
        expected_output.sort()

        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")

    print(f"{correct_count}/{len(test_cases)}")

if __name__ == '__main__':
    run_tests()