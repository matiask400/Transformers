def solve():
    def get_max_A(n):
        if n <= 0:
            return 0
        if n <= 3:
            return n
        dp = [0] * (n + 1)
        for i in range(1, n + 1):
            dp[i] = dp[i-1] + 1
            for j in range(1, i - 2):
                dp[i] = max(dp[i], dp[j] * (i - j - 1))
        return dp[n]

    test_cases = [
        (3, 3),
        (7, 9),
        (1, 1),
        (2, 2),
        (4, 4),
        (5, 5),
        (6, 6),
        (8, 12),
        (9, 16),
        (10, 20),
        (11, 27),
        (12, 36),
        (13, 48),
        (14, 64),
        (15, 81),
        (16, 108),
        (17, 144),
        (18, 192),
        (19, 256),
        (20, 320),
        (21, 427),
        (22, 569),
        (23, 759),
        (24, 1013),
        (25, 1351),
        (26, 1801),
        (27, 2401),
        (28, 3201),
        (29, 4268),
        (30, 5691),
        (31, 7589),
        (32, 10119),
        (33, 13492),
        (34, 17989),
        (35, 23986),
        (36, 31982),
        (37, 42643),
        (38, 56857),
        (39, 75809),
        (40, 101079),
        (41, 134772),
        (42, 179696),
        (43, 239595),
        (44, 319460),
        (45, 425947),
        (46, 567929),
        (47, 757239),
        (48, 1009652),
        (49, 1346203),
        (50, 1794938),
    ]

    correct_count = 0
    for n, expected_output in test_cases:
        actual_output = get_max_A(n)
        if actual_output == expected_output:
            print('True')
            correct_count += 1
        else:
            print('False')

    print(f"{correct_count}/{len(test_cases)}")

if __name__ == "__main__":
    solve()