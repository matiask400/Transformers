def solve_problem(points):
    def find_min_arrows_to_burst_balloons(points):
        if not points:
            return 0
        points.sort(key=lambda x: x[1])
        arrows = 0
        arrow_pos = float('-inf')
        for point in points:
            start, end = point
            if arrow_pos == float('-inf') or start > arrow_pos:
                arrows += 1
                arrow_pos = end
        return arrows

    test_cases = [
        ([[10,16],[2,8],[1,6],[7,12]], 2),
        ([[1,2],[3,4],[5,6],[7,8]], 4),
        ([[1,2],[2,3],[3,4],[4,5]], 2),
        ([], 0),
        ([[1,2]], 1),
        ([[1,2],[1,2]], 1),
        ([[1,2],[2,3],[1,3]], 1),
        ([[3,9],[7,12],[3,8],[6,8],[9,10],[2,9],[0,9],[3,9],[0,6],[2,8]], 2)
    ]

    num_correct = 0
    for i, (input_points, expected_output) in enumerate(test_cases):
        output = find_min_arrows_to_burst_balloons(input_points)
        if output == expected_output:
            print(True)
            num_correct += 1
        else:
            print(False)
            print(f"Test case {i+1} failed: Input={input_points}, Expected={expected_output}, Output={output}")

    print(f"{num_correct}/{len(test_cases)}")

solve_problem([[10,16],[2,8],[1,6],[7,12]])
solve_problem([[1,2],[3,4],[5,6],[7,8]])
solve_problem([[1,2],[2,3],[3,4],[4,5]])
solve_problem([])
solve_problem([[1,2]])
solve_problem([[1,2],[1,2]])
solve_problem([[1,2],[2,3],[1,3]])
solve_problem([[3,9],[7,12],[3,8],[6,8],[9,10],[2,9],[0,9],[3,9],[0,6],[2,8]])