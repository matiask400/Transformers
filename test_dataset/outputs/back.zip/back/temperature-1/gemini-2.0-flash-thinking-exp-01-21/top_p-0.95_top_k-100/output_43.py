def solve():
    def num_blue_moments(light):
        n = len(light)
        on_bulbs = [False] * (n + 1)
        max_on_bulb_index_so_far = 0
        blue_moment_count = 0
        on_bulb_count = 0
        for k in range(n):
            bulb_index = light[k]
            if not on_bulbs[bulb_index]:
                on_bulbs[bulb_index] = True
                on_bulb_count += 1
            max_on_bulb_index_so_far = max(max_on_bulb_index_so_far, bulb_index)
            if on_bulb_count == max_on_bulb_index_so_far:
                blue_moment_count += 1
        return blue_moment_count

    test_cases = [
        ([2, 1, 3, 5, 4], 3),
        ([3, 2, 4, 1, 5], 2),
        ([4, 1, 2, 3], 1),
        ([2, 1, 4, 3, 6, 5], 3),
        ([1, 2, 3, 4, 5, 6], 6)
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, (light, expected_output) in enumerate(test_cases):
        actual_output = num_blue_moments(light)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"{correct_tests}/{total_tests}")

if __name__ == '__main__':
    solve()