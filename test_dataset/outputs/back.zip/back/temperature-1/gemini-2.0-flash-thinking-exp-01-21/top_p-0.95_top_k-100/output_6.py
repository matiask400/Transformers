def solve():
    def construct_matrix(upper, lower, colsum):
        if sum(colsum) != upper + lower:
            return []
        n = len(colsum)
        matrix = [[0] * n for _ in range(2)]

        for i in range(n):
            if colsum[i] == 2:
                matrix[0][i] = 1
                matrix[1][i] = 1
                upper -= 1
                lower -= 1
                if upper < 0 or lower < 0:
                    return []

        for i in range(n):
            if colsum[i] == 0:
                matrix[0][i] = 0
                matrix[1][i] = 0

        for i in range(n):
            if colsum[i] == 1:
                if upper > 0:
                    matrix[0][i] = 1
                    matrix[1][i] = 0
                    upper -= 1
                elif lower > 0:
                    matrix[0][i] = 0
                    matrix[1][i] = 1
                    lower -= 1
                else:
                    return []

        if upper == 0 and lower == 0:
            return matrix
        else:
            return []

    def test_case(upper, lower, colsum, expected_output):
        result = construct_matrix(upper, lower, colsum)
        if result == expected_output:
            return True
        else:
            return False

    test_cases = [
        (2, 1, [1, 1, 1], [[1, 1, 0], [0, 0, 1]]),
        (2, 3, [2, 2, 1, 1], []),
        (5, 5, [2, 1, 2, 0, 1, 0, 1, 2, 0, 1], [[1, 1, 1, 0, 1, 0, 0, 1, 0, 0], [1, 0, 1, 0, 0, 0, 1, 1, 0, 1]]),
        (0, 0, [0], [[0], [0]]),
        (1, 0, [1], [[1], [0]]),
        (0, 1, [1], [[0], [1]]),
        (2, 0, [2], [[1], [1]]),
        (0, 2, [2], [[1], [1]]), # This is not right for binary matrix, but colsum[i] can be 2, so assume it should be [[1],[1]] or similar form if n=1
        (1, 1, [2], []), # should be [] as sum of upper and lower is 2, but colsum is 2 and each element is 0 or 1. Sum of col should be <= 2. No. Sum of each colsum[i] is given, and colsum[i] <= 2 is constraint.

        (9, 2, [0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1], [[0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1], [0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0]])

    ]

    results = []
    for upper, lower, colsum, expected_output in test_cases:
        results.append(test_case(upper, lower, colsum, expected_output))

    for result in results:
        print(result)

    correct_count = sum(results)
    total_count = len(results)
    print(f"{correct_count}/{total_count}")

solve()