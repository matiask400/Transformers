class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def solve():
    def get_height(root):
        if not root:
            return 0
        return 1 + max(get_height(root.left), get_height(root.right))

    def print_tree(root):
        height = get_height(root)
        if height == 0:
            return []
        width = 2**(height) - 1
        res = [[""] * width for _ in range(height)]

        def fill_array(node, r, c, h):
            if not node:
                return
            res[r][c] = str(node.val)
            if h > 1:
                distance = 2**(h-2) if h > 1 else 0
                fill_array(node.left, r + 1, c - distance, h - 1)
                fill_array(node.right, r + 1, c + distance, h - 1)

        fill_array(root, 0, (width - 1) // 2, height)
        return res

    def compare_output(output, expected_output):
        if len(output) != len(expected_output):
            return False
        for i in range(len(output)):
            if len(output[i]) != len(expected_output[i]):
                return False
            for j in range(len(output[i])):
                if output[i][j] != expected_output[i][j]:
                    return False
        return True

    test_cases = [
        (TreeNode(1, TreeNode(2)), [["", "1", ""], ["2", "", ""]]),
        (TreeNode(1, TreeNode(2, None, TreeNode(4)), TreeNode(3)), [["", "", "", "1", "", "", ""], ["", "2", "", "", "", "3", ""], ["", "", "4", "", "", "", ""]]),
        (TreeNode(1, TreeNode(2, TreeNode(3, TreeNode(4))), TreeNode(5)), [["",  "",  "", "",  "", "", "", "1", "",  "",  "",  "",  "", "", ""], ["",  "",  "", "2", "", "", "", "",  "",  "",  "",  "5", "", "", ""], ["",  "3", "", "",  "", "", "", "",  "",  "",  "",  "",  "", "", ""], ["4", "",  "", "",  "", "", "", "",  "",  "",  "",  "",  "", "", ""]]),
        (TreeNode(1), [["1"]]),
        (TreeNode(1, TreeNode(2), TreeNode(3, TreeNode(4), TreeNode(5))), [['', '', '', '', '', '', '', '1', '', '', '', '', '', '', ''], ['', '', '', '2', '', '', '', '', '', '', '', '3', '', '', ''], ['', '', '', '', '', '', '', '', '', '4', '', '', '', ''], ['', '', '', '', '', '', '', '', '', '', '', '', '', '5', '']]),
        (TreeNode(1, None, TreeNode(2, None, TreeNode(3))), [['', '', '', '1', '', '', ''], ['', '', '', '', '', '', '2'], ['', '', '', '', '', '', '3']]),
        (TreeNode(1, TreeNode(2, TreeNode(4), TreeNode(5)), TreeNode(3, TreeNode(6), TreeNode(7))), [['', '', '', '', '', '', '', '1', '', '', '', '', '', '', ''], ['', '', '', '2', '', '', '', '', '', '', '', '3', '', '', ''], ['', '', '4', '', '', '5', '', '', '', '6', '', '', '7', '', ''], ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '']])
    ]

    num_correct = 0
    for i, (root, expected_output) in enumerate(test_cases):
        output = print_tree(root)
        if compare_output(output, expected_output):
            print(f'Test {i+1}: True')
            num_correct += 1
        else:
            print(f'Test {i+1}: False')
    print(f'{num_correct}/{len(test_cases)}')

solve()