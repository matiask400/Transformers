import heapq

def getSkyline(buildings):
    """
    Calculates the skyline of a city given building locations and heights.

    Args:
        buildings: A list of lists, where each inner list represents a building
                   in the format [lefti, righti, heighti].

    Returns:
        A list of lists representing the skyline key points in the format
        [[x1,y1],[x2,y2],...].
    """
    events = []
    for l, r, h in buildings:
        events.append((l, -h))  # Start of building, negate height for max-heap
        events.append((r, h))   # End of building, positive height

    events.sort()  # Sort events by x-coordinate, then by height (start events first if x is same)

    skyline_points = []
    live_buildings = [(0, float('inf'))]  # Max heap to store live building heights, initialize with ground level
    max_height = 0

    for x, height in events:
        if height < 0:  # Start of building
            heapq.heappush(live_buildings, (height, float('inf'))) # Add height to live buildings
        else:  # End of building
            new_live_buildings = []
            for h, r in live_buildings:
                if r != x: #Lazy removal. Keep buildings not ending at current x
                    new_live_buildings.append((h,r))
            live_buildings = new_live_buildings
            live_buildings.append((0,x)) #Mark current x as the right of the building to be removed later
            heapq.heapify(live_buildings)


            temp_live_buildings = []
            while live_buildings and live_buildings[0][1] <= x: #Lazy removal actually remove buildings ended at or before current x.
                heapq.heappop(live_buildings)
            temp_live_buildings = live_buildings


        current_max_height = -live_buildings[0][0] # Get current max height from heap

        if current_max_height != max_height: # Height changed
            skyline_points.append([x, current_max_height])
            max_height = current_max_height

    # Ensure the last point is always [x_rightmost, 0] or similar if needed, although not strictly necessary given problem description
    if not skyline_points or skyline_points[-1][1] != 0:
        if skyline_points:
            last_x = skyline_points[-1][0]
        else:
            last_x = 0  # Handle empty input buildings, though constraints say at least one building
        max_right = 0
        for _, r, _ in buildings:
            max_right = max(max_right, r)
        if not skyline_points or skyline_points[-1][0] != max_right:
             skyline_points.append([max_right, 0])


    # Remove consecutive horizontal lines of equal height
    final_skyline = []
    if skyline_points:
        final_skyline.append(skyline_points[0])
        for i in range(1, len(skyline_points)):
            if skyline_points[i][1] != final_skyline[-1][1]:
                final_skyline.append(skyline_points[i])

    return final_skyline


def run_tests():
    test_cases = [
        {
            "buildings": [[2, 9, 10], [3, 7, 15], [5, 12, 12], [15, 20, 10], [19, 24, 8]],
            "expected_output": [[2, 10], [3, 15], [7, 12], [12, 0], [15, 10], [20, 8], [24, 0]]
        },
        {
            "buildings": [[0, 2, 3], [2, 5, 3]],
            "expected_output": [[0, 3], [5, 0]]
        },
        {
            "buildings": [],
            "expected_output": [] #Or [[0,0]] if we must have a starting and ending point on ground even with no buildings. Problem description implies empty list.
        },
        {
            "buildings": [[1, 2, 1], [1, 2, 2], [1, 2, 3]],
            "expected_output": [[1, 3], [2, 0]]
        },
        {
            "buildings": [[1, 5, 1], [2, 4, 2]],
            "expected_output": [[1, 1], [2, 2], [4, 1], [5, 0]]
        },
        {
            "buildings": [[0, 10, 10], [1, 5, 15], [6, 12, 12]],
            "expected_output": [[0, 10], [1, 15], [5, 12], [12, 0]]
        }

    ]

    correct_count = 0
    for i, test_case in enumerate(test_cases):
        buildings = test_case["buildings"]
        expected_output = test_case["expected_output"]
        actual_output = getSkyline(buildings)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {buildings}")
            print(f"  Expected: {expected_output}")
            print(f"  Actual: {actual_output}")

    total_tests = len(test_cases)
    print(f"\n{correct_count}/{total_tests}")

if __name__ == '__main__':
    run_tests()