def solve():
    def can_cross_river(stones):
        n = len(stones)
        if n <= 1:
            return True
        if stones[1] != 1:
            return False

        stone_positions = set(stones)
        memo = {}

        def can_reach_stone(current_stone_index, last_jump):
            if current_stone_index == n - 1:
                return True
            if (current_stone_index, last_jump) in memo:
                return memo[(current_stone_index, last_jump)]

            for next_jump in [last_jump - 1, last_jump, last_jump + 1]:
                if next_jump > 0:
                    next_stone_pos = stones[current_stone_index] + next_jump
                    if next_stone_pos in stone_positions:
                        next_stone_index = -1
                        for i in range(current_stone_index + 1, n):
                            if stones[i] == next_stone_pos:
                                next_stone_index = i
                                break
                        if next_stone_index != -1:
                            if can_reach_stone(next_stone_index, next_jump):
                                memo[(current_stone_index, last_jump)] = True
                                return True

            memo[(current_stone_index, last_jump)] = False
            return False

        return can_reach_stone(0, 1)

    test_cases = [
        ([0, 1, 3, 5, 6, 8, 12, 17], True),
        ([0, 1, 2, 3, 4, 8, 9, 11], False),
        ([0, 1], True),
        ([0, 2], False),
        ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], True),
        ([0, 1, 2, 5, 6, 7], False),
        ([0, 1, 2, 3, 5, 6], False),
        ([0, 1, 2, 3, 6], False),
        ([0, 1, 2, 4], False)
    ]

    correct_count = 0
    for i, (stones, expected_output) in enumerate(test_cases):
        result = can_cross_river(stones)
        if result == expected_output:
            print(True)
            correct_count += 1
        else:
            print(False)

    print(f"{correct_count}/{len(test_cases)}")

solve()