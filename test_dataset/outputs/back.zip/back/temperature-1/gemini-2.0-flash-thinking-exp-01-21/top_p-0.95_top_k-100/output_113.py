class SparseVector:
    def __init__(self, nums):
        self.sparse_vector = {}
        for i, num in enumerate(nums):
            if num != 0:
                self.sparse_vector[i] = num

    def dotProduct(self, vec):
        dot_product = 0
        for index, value in self.sparse_vector.items():
            if index in vec.sparse_vector:
                dot_product += value * vec.sparse_vector[index]
        return dot_product

def test_dotProduct():
    test_cases = [
        (([1, 0, 0, 2, 3], [0, 3, 0, 4, 0]), 8),
        (([0, 1, 0, 0, 0], [0, 0, 0, 0, 2]), 0),
        (([0, 1, 0, 0, 2, 0, 0], [1, 0, 0, 0, 3, 0, 4]), 6),
        (([1, 2, 3], [4, 5, 6]), 32),
        (([0, 0, 0], [0, 0, 0]), 0),
        (([1, 0, 0], [0, 0, 1]), 0),
        (([0, 1, 0], [1, 0, 0]), 0),
        (([0, 0, 1], [1, 0, 0]), 0),
        (([1], [1]), 1),
        (([0], [0]), 0),
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, (input_vectors, expected_output) in enumerate(test_cases):
        nums1, nums2 = input_vectors
        v1 = SparseVector(nums1)
        v2 = SparseVector(nums2)
        output = v1.dotProduct(v2)
        if output == expected_output:
            print(True)
            correct_tests += 1
        else:
            print(False)

    print(f"{correct_tests}/{total_tests}")

if __name__ == '__main__':
    test_dotProduct()