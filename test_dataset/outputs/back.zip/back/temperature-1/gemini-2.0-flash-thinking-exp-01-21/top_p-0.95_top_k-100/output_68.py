def numMagicSquaresInside(grid):
    rows = len(grid)
    cols = len(grid[0]) if rows > 0 else 0
    count = 0

    def is_magic_square(subgrid):
        if len(subgrid) != 3 or len(subgrid[0]) != 3:
            return False

        nums = set()
        for r in range(3):
            for c in range(3):
                num = subgrid[r][c]
                if not 1 <= num <= 9:
                    return False
                nums.add(num)
        if len(nums) != 9:
            return False

        magic_sum = sum(subgrid[0])
        for r in range(3):
            if sum(subgrid[r]) != magic_sum:
                return False
        for c in range(3):
            if sum(subgrid[r][c] for r in range(3)) != magic_sum:
                return False
        if sum(subgrid[i][i] for i in range(3)) != magic_sum:
            return False
        if sum(subgrid[i][2 - i] for i in range(3)) != magic_sum:
            return False
        return True

    for i in range(rows - 2):
        for j in range(cols - 2):
            subgrid = [row[j:j+3] for row in grid[i:i+3]]
            if is_magic_square(subgrid):
                count += 1
    return count

def test_numMagicSquaresInside():
    tests = [
        {"input": [[4,3,8,4],[9,5,1,9],[2,7,6,2]], "expected": 1},
        {"input": [[8]], "expected": 0},
        {"input": [[4,4],[3,3]], "expected": 0},
        {"input": [[4,7,8],[9,5,1],[2,3,6]], "expected": 0},
        {"input": [[1,8,6],[10,5,0],[4,2,9]], "expected": 0},
        {"input": [[2,7,6],[9,5,1],[4,3,8]], "expected": 1},
        {"input": [[4, 9, 2, 7, 5, 3, 6, 1, 8]], "expected": 0},
        {"input": [[3,2,9,2,7],[6,1,8,3,7],[7,5,3,2,6],[1,5,4,6,2],[9,2,9,9,7]], "expected": 0},
        {"input": [[7,0,5,5,8,4,0,7,9],[9,0,3,3,3,6,9,6,3],[3,2,5,4,7,5,9,7,8],[5,7,9,5,8,8,6,9,3],[8,9,5,1,7,4,5,6,8],[2,6,9,7,8,3,2,4,7],[2,6,4,7,4,9,2,1,0],[3,9,8,9,2,4,1,7,8],[1,1,4,2,8,3,9,5,4]], "expected": 0},
    ]
    num_passed = 0
    for i, test in enumerate(tests):
        actual_output = numMagicSquaresInside(test["input"])
        if actual_output == test["expected"]:
            print(f"Test {i+1}: True")
            num_passed += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{num_passed}/{len(tests)}")

test_numMagicSquaresInside()