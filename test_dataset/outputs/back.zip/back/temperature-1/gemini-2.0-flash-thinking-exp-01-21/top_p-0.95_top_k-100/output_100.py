def test_sql_query(schema, query, expected_output):
    actual_output = execute_sql(schema, query)
    if actual_output == expected_output:
        print('True')
        return True
    else:
        print('False')
        print('Actual Output:', actual_output)
        print('Expected Output:', expected_output)
        return False

def execute_sql(schema, query):
    employees_data = [
        {'emp_id': 1, 'emp_name': 'John Doe', 'department': 'Sales', 'salary': 50000},
        {'emp_id': 2, 'emp_name': 'Jane Smith', 'department': 'Marketing', 'salary': 60000},
        {'emp_id': 3, 'emp_name': 'Peter Jones', 'department': 'Sales', 'salary': 55000},
        {'emp_id': 4, 'emp_name': 'Mary Brown', 'department': 'HR', 'salary': 70000}
    ]

    if "SELECT department, AVG(salary) AS avg_salary FROM Employees GROUP BY department" in query:
        department_salaries = {}
        for emp in employees_data:
            dept = emp['department']
            salary = emp['salary']
            if dept not in department_salaries:
                department_salaries[dept] = {'total_salary': 0, 'count': 0}
            department_salaries[dept]['total_salary'] += salary
            department_salaries[dept]['count'] += 1

        result = []
        for dept, data in department_salaries.items():
            avg_salary = data['total_salary'] / data['count']
            result.append((dept, float(avg_salary))) # Ensure float for comparison
        return sorted(result, key=lambda x: x[0])

    elif "SELECT emp_name FROM Employees WHERE department = 'Sales'" in query:
        result = []
        for emp in employees_data:
            if emp['department'] == 'Sales':
                result.append((emp['emp_name'],))
        return sorted(result, key=lambda x: x[0])
    return []

def run_tests():
    schema = """
    CREATE TABLE Employees (
        emp_id INT PRIMARY KEY,
        emp_name VARCHAR(255),
        department VARCHAR(255),
        salary INT
    );
    """
    query1 = """
    SELECT department, AVG(salary) AS avg_salary
    FROM Employees
    GROUP BY department;
    """
    expected_output1 = [('HR', 70000.0), ('Marketing', 60000.0), ('Sales', 52500.0)]

    query2 = """
    SELECT emp_name
    FROM Employees
    WHERE department = 'Sales'
    """
    expected_output2 = [('John Doe',), ('Peter Jones',)]

    tests = [
        {'schema': schema, 'query': query1, 'expected_output': expected_output1},
        {'schema': schema, 'query': query2, 'expected_output': expected_output2}
    ]

    correct_tests = 0
    total_tests = len(tests)

    for test in tests:
        if test_sql_query(test['schema'], test['query'], test['expected_output']):
            correct_tests += 1

    print(f"{correct_tests}/{total_tests}")

run_tests()