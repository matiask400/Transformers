def solve():
    def calculate_average_salary(department_name, employees_data):
        department_employees = [emp for emp in employees_data if emp['department'] == department_name]
        if not department_employees:
            return 0.0
        total_salary = sum(emp['salary'] for emp in department_employees)
        return total_salary / len(department_employees)

    employees_data = [
        {'employee_id': 1, 'name': 'Alice', 'department': 'Sales', 'salary': 50000},
        {'employee_id': 2, 'name': 'Bob', 'department': 'Sales', 'salary': 60000},
        {'employee_id': 3, 'name': 'Charlie', 'department': 'Marketing', 'salary': 70000},
        {'employee_id': 4, 'name': 'David', 'department': 'Engineering', 'salary': 80000},
        {'employee_id': 5, 'name': 'Eve', 'department': 'Engineering', 'salary': 90000}
    ]

    test_cases = [
        {"input": "Sales", "expected_output": 55000.0},
        {"input": "Marketing", "expected_output": 70000.0},
        {"input": "Engineering", "expected_output": 85000.0},
        {"input": "HR", "expected_output": 0.0},
        {"input": "Sales", "expected_output": 55000}, # Test with integer expected output, should still pass due to float comparison
        {"input": "Sales", "expected_output": 55000.0001}, # Test close but not exact value, should fail
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        input_department = test_case["input"]
        expected_output = test_case["expected_output"]
        actual_output = calculate_average_salary(input_department, employees_data)
        if isinstance(expected_output, float):
            passed = abs(actual_output - expected_output) < 1e-6 # Comparing floats with tolerance
        else:
            passed = actual_output == expected_output

        if passed:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"{correct_tests}/{total_tests}")

solve()