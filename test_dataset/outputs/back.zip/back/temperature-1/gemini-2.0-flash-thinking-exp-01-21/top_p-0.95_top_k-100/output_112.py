def find_longest_consecutive_ones(matrix):
    if not matrix or not matrix[0]:
        return 0

    rows = len(matrix)
    cols = len(matrix[0])
    max_length = 0

    for r in range(rows):
        for c in range(cols):
            if matrix[r][c] == 1:
                # Check horizontal
                length = 0
                for k in range(c, cols):
                    if matrix[r][k] == 1:
                        length += 1
                    else:
                        break
                max_length = max(max_length, length)

                # Check vertical
                length = 0
                for k in range(r, rows):
                    if matrix[k][c] == 1:
                        length += 1
                    else:
                        break
                max_length = max(max_length, length)

                # Check diagonal
                length = 0
                for k in range(min(rows - r, cols - c)):
                    if matrix[r + k][c + k] == 1:
                        length += 1
                    else:
                        break
                max_length = max(max_length, length)

                # Check anti-diagonal
                length = 0
                for k in range(min(rows - r, c + 1)):
                    if matrix[r + k][c - k] == 1 and c - k >= 0:
                        length += 1
                    else:
                        break
                max_length = max(max_length, length)
    return max_length

def run_tests():
    test_cases = [
        ([[0,1,1,0],[0,1,1,0],[0,0,0,1]], 3),
        ([[1,0,0,0],[1,0,0,0],[1,0,0,0]], 3),
        ([[0,0,1,0],[0,0,1,0],[0,0,1,0]], 3),
        ([[0,0,0,1],[0,0,0,1],[0,0,0,1]], 3),
        ([[1,1,1,1],[0,0,0,0],[0,0,0,0]], 4),
        ([[0,0,0,0],[1,1,1,1],[0,0,0,0]], 4),
        ([[0,0,0,0],[0,0,0,0],[1,1,1,1]], 4),
        ([[1],[1],[1],[1]], 4),
        ([[1,1,1,1]], 4),
        ([[1]], 1),
        ([[0]], 0),
        ([[]], 0),
        ([], 0),
        ([[1,0,1,0],[1,1,1,0],[0,0,1,1]], 3),
        ([[0,1,0,1],[1,1,1,1],[0,1,0,1]], 4),
        ([[1,1,0,0],[0,1,1,0],[0,0,1,1]], 2),
        ([[1,0,0,1],[0,1,1,0],[0,1,1,0],[1,0,0,1]], 2)
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, (input_matrix, expected_output) in enumerate(test_cases):
        actual_output = find_longest_consecutive_ones(input_matrix)
        if actual_output == expected_output:
            print(True)
            correct_tests += 1
        else:
            print(False)

    print(f"{correct_tests}/{total_tests}")

if __name__ == '__main__':
    run_tests()