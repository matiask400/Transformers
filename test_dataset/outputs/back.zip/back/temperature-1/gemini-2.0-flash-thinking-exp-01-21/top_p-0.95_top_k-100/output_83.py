class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def list_to_tree(lst):
    if not lst:
        return None
    root = TreeNode(lst[0])
    queue = [root]
    i = 1
    while queue and i < len(lst):
        node = queue.pop(0)
        if lst[i] is not None:
            node.left = TreeNode(lst[i])
            queue.append(node.left)
        i += 1
        if i < len(lst) and lst[i] is not None:
            node.right = TreeNode(lst[i])
            queue.append(node.right)
        i += 1
    return root

def sum_root_to_leaf(root):
    total_sum = 0

    def dfs(node, current_binary_string):
        nonlocal total_sum
        if not node:
            return

        new_binary_string = current_binary_string + str(node.val)

        if not node.left and not node.right:
            if new_binary_string:
                total_sum += int(new_binary_string, 2)
            return

        dfs(node.left, new_binary_string)
        dfs(node.right, new_binary_string)

    dfs(root, "")
    return total_sum

def run_tests():
    test_cases = [
        ([1,0,1,0,1,0,1], 22),
        ([0], 0),
        ([1], 1),
        ([1,1], 3),
        ([1,0,0], 4),
        ([1,0, None, 1, 1], 6),
        ([1, None, 0, None, None, None, None], 2)
    ]
    num_correct = 0
    for i, (input_tree_list, expected_output) in enumerate(test_cases):
        tree_root = list_to_tree(input_tree_list)
        actual_output = sum_root_to_leaf(tree_root)
        if actual_output == expected_output:
            print(f'Test {i+1}: True')
            num_correct += 1
        else:
            print(f'Test {i+1}: False')
    print(f'{num_correct}/{len(test_cases)}')

if __name__ == '__main__':
    run_tests()