def solve():
    nodes = int(input())
    parent_str = input()
    parent = list(map(int, parent_str.strip('[]').split(','))) if parent_str.strip() else []
    value_str = input()
    value = list(map(int, value_str.strip('[]').split(','))) if value_str.strip() else []
    expected_output = int(input())

    children = [[] for _ in range(nodes)]
    for i in range(1, nodes):
        children[parent[i]].append(i)

    subtree_sum = [0] * nodes

    def calculate_subtree_sum(node):
        current_sum = value[node]
        for child in children[node]:
            current_sum += calculate_subtree_sum(child)
        subtree_sum[node] = current_sum
        return current_sum

    calculate_subtree_sum(0)

    removed = [False] * nodes

    def mark_removed(node):
        removed[node] = True
        for child in children[node]:
            mark_removed(child)

    for i in range(nodes):
        if subtree_sum[i] == 0:
            mark_removed(i)

    remaining_nodes_count = 0
    for i in range(nodes):
        if not removed[i]:
            remaining_nodes_count += 1

    output = remaining_nodes_count
    if output == expected_output:
        print('True')
    else:
        print('False')

def run_tests():
    test_cases = [
        (
            (7, [-1, 0, 0, 1, 2, 2, 2], [1, -2, 4, 0, -2, -1, -1]),
            2
        ),
        (
            (7, [-1, 0, 0, 1, 2, 2, 2], [1, -2, 4, 0, -2, -1, -2]),
            6
        ),
        (
            (5, [-1, 0, 1, 0, 0], [-672, 441, 18, 728, 378]),
            5
        ),
        (
            (5, [-1, 0, 0, 1, 1], [-686, -842, 616, -739, -746]),
            5
        ),
        (
            (1, [-1], [0]),
            0
        ),
        (
            (2, [-1, 0], [0, 0]),
            0
        ),
        (
            (2, [-1, 0], [1, -1]),
            2
        ),
         (
            (3, [-1, 0, 0], [1, -1, 0]),
            1
        ),
         (
            (4, [-1, 0, 0, 0], [1, -1, 0, 0]),
            1
        ),
        (
            (6, [-1, 0, 0, 1, 1, 4], [-2, 3, 2, -3, 1, -3]),
            6
        ),
        (
            (6, [-1, 0, 0, 1, 1, 4], [-2, 3, 2, -3, 1, -2]),
            5
        )
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for idx, test_case in enumerate(test_cases):
        nodes, parent, value = test_case[0]
        expected_output = test_case[1]

        children = [[] for _ in range(nodes)]
        for i in range(1, nodes):
            children[parent[i]].append(i)

        subtree_sum = [0] * nodes

        def calculate_subtree_sum(node):
            current_sum = value[node]
            for child in children[node]:
                current_sum += calculate_subtree_sum(child)
            subtree_sum[node] = current_sum
            return current_sum

        calculate_subtree_sum(0)

        removed = [False] * nodes

        def mark_removed(node):
            removed[node] = True
            for child in children[node]:
                mark_removed(child)

        for i in range(nodes):
            if subtree_sum[i] == 0:
                mark_removed(i)

        remaining_nodes_count = 0
        for i in range(nodes):
            if not removed[i]:
                remaining_nodes_count += 1

        output = remaining_nodes_count
        if output == expected_output:
            print('True')
            num_correct += 1
        else:
            print('False')

    print(f"{num_correct}/{total_tests}")

if __name__ == '__main__':
    run_tests()