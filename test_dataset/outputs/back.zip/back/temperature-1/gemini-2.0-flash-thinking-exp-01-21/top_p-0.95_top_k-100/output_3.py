def solve():
    def get_lexicographically_largest_merge(word1: str, word2: str) -> str:
        merge = ""
        i = 0
        j = 0
        while i < len(word1) and j < len(word2):
            if word1[i] > word2[j]:
                merge += word1[i]
                i += 1
            elif word2[j] > word1[i]:
                merge += word2[j]
                j += 1
            else: # word1[i] == word2[j]
                if word1[i+1:] > word2[j+1:]:
                    merge += word1[i]
                    i += 1
                else:
                    merge += word2[j]
                    j += 1
        merge += word1[i:]
        merge += word2[j:]
        return merge

    test_cases = [
        (("cabaa", "bcaaa"), "cbcabaaaaa"),
        (("abcabc", "abdcaba"), "abdcabcabcaba"),
        (("aba", "baa"), "baabaa"),
        (("", ""), ""),
        (("abc", ""), "abc"),
        (("", "def"), "def"),
        (("a", "b"), "ba"),
        (("b", "a"), "ba"),
        (("apple", "banana"), "bananaapple"),
        (("zebra", "apple"), "zebraapple"),
        (("cat", "car"), "carcat"),
        (("dog", "dove"), "doveog"),
        (("hello", "world"), "worldhello"),
        (("algorithm", "data"), "dataalgorithm"),
        (("programming", "is"), "isprogramming"),
        (("python", "java"), "javapython"),
        (("string", "manipulation"), "manipulationstring"),
        (("tree", "graph"), "graphtree"),
        (("union", "intersection"), "unionintersection"),
        (("vowel", "consonant"), "vowelconsonant"),
        (("xray", "yellow"), "yellowxray"),
        (("zoo", "yak"), "yakzoo"),
        (("applepie", "apricot"), "apricotapplepie"),
        (("baseball", "basketball"), "basketballbaseball"),
        (("chocolate", "coffee"), "coffeechocolate"),
        (("delicious", "food"), "fooddelicious"),
        (("elephant", "emu"), "emuelephant"),
        (("fantastic", "great"), "greatfantastic"),
        (("holiday", "inn"), "innholiday"),
        (("jazz", "blues"), "jazzblues"),
        (("king", "queen"), "queenking"),
        (("lemon", "lime"), "limonlemon"),
        (("mountain", "ocean"), "oceanmountain"),
        (("network", "internet"), "networkinternet"),
        (("orange", "peach"), "peachorange"),
        (("quickly", "slowly"), "slowlyquickly"),
        (("rabbit", "squirrel"), "squirrelrabbit"),
        (("sunshine", "rain"), "sunshinerain"),
        (("tiger", "lion"), "tigerlion"),
        (("umbrella", "weather"), "weatherumbrella"),
        (("vanilla", "walnut"), "walnutvanilla"),
        (("xylophone", "zither"), "zitherxylophone"),
        (("yellowish", "zealous"), "zealousyellowish"),
        (("zodiac", "year"), "yearzodiac"),
        (("amazing", "beautiful"), "beautifulamazing"),
        (("c", "ca"), "cac"),
        (("ca", "c"), "cac")
    ]

    correct_count = 0
    for i, (