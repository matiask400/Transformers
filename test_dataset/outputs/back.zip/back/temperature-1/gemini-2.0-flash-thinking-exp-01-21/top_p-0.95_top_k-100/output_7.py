def solve():
    def max_indices_visited_func(arr, d):
        n = len(arr)
        memo = {}

        def is_valid_jump(start_index, end_index, arr):
            if arr[start_index] <= arr[end_index]:
                return False
            start = min(start_index, end_index)
            end = max(start_index, end_index)
            for k in range(start + 1, end):
                if arr[start_index] <= arr[k]:
                    return False
            return True

        def dfs(index):
            if index in memo:
                return memo[index]

            max_count = 1
            # Forward jumps
            for x in range(1, d + 1):
                next_index = index + x
                if next_index < n and is_valid_jump(index, next_index, arr):
                    max_count = max(max_count, 1 + dfs(next_index))
            # Backward jumps
            for x in range(1, d + 1):
                next_index = index - x
                if next_index >= 0 and is_valid_jump(index, next_index, arr):
                    max_count = max(max_count, 1 + dfs(next_index))

            memo[index] = max_count
            return max_count

        max_visited = 0
        for start_index in range(n):
            memo = {} # Important to reset memo for each start index, actually not needed because memoization is done based on index. But it is fine to reset.
            max_visited = max(max_visited, dfs(start_index))
        return max_visited

    test_cases = [
        (([6,4,14,6,8,13,9,7,10,6,12], 2), 4),
        (([3,3,3,3,3], 3), 1),
        (([7,6,5,4,3,2,1], 1), 7),
        (([7,1,7,1,7,1], 2), 2),
        (([66], 1), 1),
    ]

    results = []
    for case, expected_output in test_cases:
        arr, d = case
        output = max_indices_visited_func(arr, d)
        results.append((output == expected_output))

    correct_count = sum(results)
    total_count = len(results)

    for result in results:
        print(result)

    print(f"{correct_count}/{total_count}")

solve()