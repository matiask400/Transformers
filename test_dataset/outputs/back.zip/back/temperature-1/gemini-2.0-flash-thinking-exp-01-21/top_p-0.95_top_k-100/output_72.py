def solve():
    def find_max_value(points, k):
        max_val = float('-inf')
        for i in range(len(points)):
            for j in range(i + 1, len(points)):
                xi, yi = points[i]
                xj, yj = points[j]
                if abs(xi - xj) <= k:
                    current_val = yi + yj + abs(xi - xj)
                    max_val = max(max_val, current_val)
        return max_val

    test_cases = [
        ([[1,3],[2,0],[5,10],[6,-10]], 1, 4),
        ([[0,0],[3,0],[9,2]], 3, 3),
        ([[1, 1], [2, 2], [3, 3]], 2, 5),
        ([[1, 1], [5, 2], [8, 3]], 7, 6),
        ([[1, 1], [2, 2]], 1, 4),
        ([[1, 1], [1 + 5, 2]], 5, 8),
        ([[1, 1], [1 + 0, 2]], 0, float('-inf')), # Should be updated later if needed
        ([[1, 1], [2, 2], [4, 3], [5, 4]], 3, 7),
        ([[1, 1], [5, 2], [6, 3], [9, 4]], 4, 6),
        ([[1, 1], [5, 2], [6, 3], [9, 4]], 1, float('-inf')), # Should be updated later if needed
    ]

    results = []
    for points, k, expected_output in test_cases:
        output = find_max_value(points, k)
        if output == float('-inf'):
            found_at_least_one = False
            for i in range(len(points)):
                for j in range(i + 1, len(points)):
                    xi, yi = points[i]
                    xj, yj = points[j]
                    if abs(xi - xj) <= k:
                        found_at_least_one = True
                        break
                if found_at_least_one:
                    break
            if not found_at_least_one:
                output = -1 # or some indicator if needed, but problem statement guarantees at least one pair

        if output == expected_output:
            print('True')
            results.append(True)
        else:
            print('False')
            results.append(False)

    print(f"{sum(results)}/{len(results)}")

solve()