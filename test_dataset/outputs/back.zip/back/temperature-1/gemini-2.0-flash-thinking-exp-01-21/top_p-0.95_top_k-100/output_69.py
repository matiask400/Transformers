import subprocess

def test_word_frequency_script(input_text, expected_output):
    """
    Tests the bash script for word frequency calculation.

    Args:
        input_text (str): The content of words.txt.
        expected_output (str): The expected output of the script.

    Returns:
        bool: True if the test passed, False otherwise.
    """
    try:
        with open("words.txt", "w") as f:
            f.write(input_text)

        script = """
        cat words.txt | tr -s ' ' '\\n' | sort | uniq -c | sort -nr | awk '{print $2, $1}'
        """

        process = subprocess.Popen(script, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        stdout, stderr = process.communicate()

        if stderr:
            print(f"Error executing script: {stderr}")
            return False

        actual_output = stdout.strip()
        return actual_output == expected_output.strip()

    except Exception as e:
        print(f"An error occurred: {e}")
        return False

def run_tests():
    """
    Runs test cases for the word frequency script and prints the results.
    """
    tests = [
        {
            "input": "the day is sunny the the\nthe sunny is is",
            "expected_output": "the 4\nis 3\nsunny 2\nday 1"
        },
        {
            "input": "hello world hello",
            "expected_output": "hello 2\nworld 1"
        },
        {
            "input": "  word1   word2 word1 ",
            "expected_output": "word1 2\nword2 1"
        },
        {
            "input": "word",
            "expected_output": "word 1"
        },
        {
            "input": "",
            "expected_output": ""
        }
    ]

    correct_tests = 0
    total_tests = len(tests)

    for i, test in enumerate(tests):
        result = test_word_frequency_script(test["input"], test["expected_output"])
        if result:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"\n{correct_tests} correct tests over {total_tests}")

if __name__ == "__main__":
    run_tests()