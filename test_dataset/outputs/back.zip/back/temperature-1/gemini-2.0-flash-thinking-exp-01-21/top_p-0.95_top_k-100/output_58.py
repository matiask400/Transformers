def solve():
    def get_min_start_value(nums):
        start_value = 1
        while True:
            current_sum = start_value
            is_possible = True
            for num in nums:
                current_sum += num
                if current_sum < 1:
                    is_possible = False
                    break
            if is_possible:
                return start_value
            start_value += 1

    def run_test(nums, expected_output):
        actual_output = get_min_start_value(nums)
        if actual_output == expected_output:
            print('True')
            return True
        else:
            print('False')
            return False

    test_cases = [
        {
            "nums": [-3, 2, -3, 4, 2],
            "expected_output": 5
        },
        {
            "nums": [1, 2],
            "expected_output": 1
        },
        {
            "nums": [1, -2, -3],
            "expected_output": 5
        },
        {
            "nums": [-5,-2,3,-8,9,-5,-7,2,4],
            "expected_output": 8
        },
        {
            "nums": [],
            "expected_output": 1
        },
        {
            "nums": [0],
            "expected_output": 1
        },
        {
            "nums": [-100],
            "expected_output": 101
        },
        {
            "nums": [100],
            "expected_output": 1
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for test_case in test_cases:
        nums = test_case["nums"]
        expected_output = test_case["expected_output"]
        if run_test(nums, expected_output):
            correct_tests += 1

    print(f"{correct_tests}/{total_tests}")

if __name__ == "__main__":
    solve()