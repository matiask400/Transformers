def remove_outermost_parentheses(s):
    primitive_strings = []
    balance = 0
    start_index = 0
    for i in range(len(s)):
        if s[i] == '(':
            balance += 1
        elif s[i] == ')':
            balance -= 1
        if balance == 0:
            primitive_strings.append(s[start_index:i+1])
            start_index = i + 1
    result = ""
    for primitive_str in primitive_strings:
        if len(primitive_str) >= 2:
            result += primitive_str[1:-1]
    return result

def test_remove_outermost_parentheses():
    test_cases = [
        {
            "input": "(()())(())",
            "expected_output": "()()()"
        },
        {
            "input": "(()())(())(()(()))",
            "expected_output": "()()()()(())"
        },
        {
            "input": "()()",
            "expected_output": ""
        },
        {
            "input": "()",
            "expected_output": ""
        },
        {
            "input": "(())",
            "expected_output": ""
        },
        {
            "input": "((()))",
            "expected_output": "()"
        },
        {
            "input": "",
            "expected_output": ""
        },
        {
            "input": "(()(()))",
            "expected_output": "()(())"
        }
    ]
    correct_tests = 0
    for i, test_case in enumerate(test_cases):
        input_s = test_case["input"]
        expected_output = test_case["expected_output"]
        actual_output = remove_outermost_parentheses(input_s)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{correct_tests}/{len(test_cases)}")

if __name__ == '__main__':
    test_remove_outermost_parentheses()