from collections import deque

def sliding_puzzle(board):
    target = ((1, 2, 3), (4, 5, 0))
    start_state = tuple(tuple(row) for row in board)

    if start_state == target:
        return 0

    queue = deque([(start_state, 0)])
    visited = {start_state}

    while queue:
        current_state, moves = queue.popleft()

        if current_state == target:
            return moves

        zero_pos = None
        for r in range(2):
            for c in range(3):
                if current_state[r][c] == 0:
                    zero_pos = (r, c)
                    break
            if zero_pos:
                break

        zero_r, zero_c = zero_pos
        possible_moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]  # right, left, down, up

        for dr, dc in possible_moves:
            next_r, next_c = zero_r + dr, zero_c + dc

            if 0 <= next_r < 2 and 0 <= next_c < 3:
                next_board_list = [list(row) for row in current_state]
                next_board_list[zero_r][zero_c], next_board_list[next_r][next_c] = next_board_list[next_r][next_c], next_board_list[zero_r][zero_c]
                next_state = tuple(tuple(row) for row in next_board_list)

                if next_state not in visited:
                    visited.add(next_state)
                    queue.append((next_state, moves + 1))

    return -1

def run_tests():
    test_cases = [
        ([[1, 2, 3], [4, 0, 5]], 1),
        ([[1, 2, 3], [5, 4, 0]], -1),
        ([[4, 1, 2], [5, 0, 3]], 5),
        ([[3, 2, 4], [1, 5, 0]], 14),
        ([[1, 0, 3], [4, 2, 5]], -1), # Additional test case based on parity check (not needed, BFS finds it)
        ([[0, 1, 2], [3, 4, 5]], 4) # Additional test case
    ]
    correct_count = 0
    for i, (board, expected_output) in enumerate(test_cases):
        output = sliding_puzzle(board)
        if output == expected_output:
            print(f'Test {i+1}: True')
            correct_count += 1
        else:
            print(f'Test {i+1}: False, Input: {board}, Expected: {expected_output}, Got: {output}')

    print(f"\n{correct_count} correct out of {len(test_cases)}")

if __name__ == '__main__':
    run_tests()