import sqlite3

def create_test_database():
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()

    cursor.execute('''
    CREATE TABLE Employees (
        id INTEGER PRIMARY KEY,
        name TEXT,
        department TEXT,
        salary INTEGER
    )
    ''')

    employees_data = [
        (1, 'Alice', 'Sales', 50000),
        (2, 'Bob', 'Sales', 60000),
        (3, 'Charlie', 'IT', 70000),
        (4, 'David', 'IT', 80000),
        (5, 'Eve', 'HR', 55000)
    ]
    cursor.executemany("INSERT INTO Employees (id, name, department, salary) VALUES (?, ?, ?, ?)", employees_data)
    conn.commit()
    return conn

def test_sql_query(conn, sql_query, expected_output):
    cursor = conn.cursor()
    cursor.execute(sql_query)
    result = cursor.fetchall()
    if result == expected_output:
        print('True')
        return True
    else:
        print('False')
        print(f"  Query: {sql_query}")
        print(f"  Expected: {expected_output}")
        print(f"  Actual: {result}")
        return False

def solve():
    conn = create_test_database()
    test_cases = [
        ("SELECT COUNT(*) FROM Employees WHERE department = 'Sales'", [(2,)]),
        ("SELECT AVG(salary) FROM Employees WHERE department = 'IT'", [(75000.0,)]),
        ("SELECT name FROM Employees WHERE salary > 60000", [('Charlie',), ('David',)]),
        ("SELECT department, COUNT(*) FROM Employees GROUP BY department ORDER BY department", [('HR', 1), ('IT', 2), ('Sales', 2)]),
        ("SELECT name FROM Employees ORDER BY salary DESC LIMIT 1", [('David',)]),
        ("SELECT * FROM Employees WHERE department = 'Marketing'", []), # Test case with no results
        ("SELECT department FROM Employees WHERE salary >= 60000 GROUP BY department HAVING COUNT(*) > 1", [('IT',), ('Sales',)]) # Test with GROUP BY and HAVING
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for sql_query, expected_output in test_cases:
        if test_sql_query(conn, sql_query, expected_output):
            correct_tests += 1

    print(f"{correct_tests}/{total_tests}")
    conn.close()

if __name__ == '__main__':
    solve()