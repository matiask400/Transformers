def solve_board(board):
    if not board or not board[0]:
        return board

    rows = len(board)
    cols = len(board[0])

    def dfs(r, c):
        if r < 0 or r >= rows or c < 0 or c >= cols or board[r][c] != 'O':
            return
        board[r][c] = 'T'  # Temporarily mark as 'T' to indicate not captured
        dfs(r + 1, c)
        dfs(r - 1, c)
        dfs(r, c + 1)
        dfs(r, c - 1)

    # 1. Iterate through the border and start DFS from 'O's
    for r in range(rows):
        for c in range(cols):
            if (r == 0 or r == rows - 1 or c == 0 or c == cols - 1) and board[r][c] == 'O':
                dfs(r, c)

    # 2. Iterate through the board and flip 'O's to 'X's and 'T's back to 'O's
    for r in range(rows):
        for c in range(cols):
            if board[r][c] == 'O':
                board[r][c] = 'X'
            elif board[r][c] == 'T':
                board[r][c] = 'O'
    return board

def solve():
    test_cases = [
        {
            "input": [["X","X","X","X"],["X","O","O","X"],["X","X","O","X"],["X","O","X","X"]],
            "expected": [["X","X","X","X"],["X","X","X","X"],["X","X","X","X"],["X","O","X","X"]]
        },
        {
            "input": [["X"]],
            "expected": [["X"]]
        },
        {
            "input": [["O","O","O"],["O","O","O"],["O","O","O"]],
            "expected": [["O","O","O"],["O","O","O"],["O","O","O"]]
        },
        {
            "input": [["X","O","X"],["O","X","O"],["X","O","X"]],
            "expected": [["X","O","X"],["O","X","O"],["X","O","X"]]
        },
        {
            "input": [["O","X","X","O","X"],["X","O","O","X","O"],["X","X","O","X","X"],["O","O","O","O","O"],["X","X","X","X","O"]],
            "expected": [["O","X","X","O","X"],["X","X","X","X","O"],["X","X","X","X","X"],["O","O","O","O","O"],["X","X","X","X","O"]]
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        input_board = [row[:] for row in test_case["input"]] # Deep copy to avoid modification of original input
        expected_output = test_case["expected"]
        output_board = solve_board(input_board)

        if output_board == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")

    print(f"\nCorrect tests: {correct_tests}/{total_tests}")

if __name__ == '__main__':
    solve()