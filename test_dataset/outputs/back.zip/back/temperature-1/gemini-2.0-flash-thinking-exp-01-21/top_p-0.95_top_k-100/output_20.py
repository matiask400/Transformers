def solve_sql_problem(customers_data, orders_data):
    """
    This function retrieves the names of customers who have placed at least one order.

    Args:
      customers_data: A list of dictionaries representing customer data.
                     Each dictionary should have keys: 'customer_id', 'customer_name', 'city'.
      orders_data: A list of dictionaries representing order data.
                   Each dictionary should have keys: 'order_id', 'customer_id', 'order_date', 'total_amount'.

    Returns:
      A list of customer names who have placed at least one order.
    """
    ordered_customer_ids = set()
    for order in orders_data:
        ordered_customer_ids.add(order['customer_id'])

    customer_names_with_orders = []
    for customer in customers_data:
        if customer['customer_id'] in ordered_customer_ids:
            customer_names_with_orders.append(customer['customer_name'])

    return customer_names_with_orders

def run_tests():
    """
    Runs test cases for the solve_sql_problem function.
    Prints 'True' for passed tests and 'False' for failed tests.
    Finally, prints the number of correct tests over the total.
    """
    test_cases = [
        {
            "name": "Test Case 1: Some customers have orders",
            "customers_data": [
                {'customer_id': 1, 'customer_name': 'Alice', 'city': 'New York'},
                {'customer_id': 2, 'customer_name': 'Bob', 'city': 'Los Angeles'},
                {'customer_id': 3, 'customer_name': 'Charlie', 'city': 'Chicago'},
                {'customer_id': 4, 'customer_name': 'David', 'city': 'Houston'},
                {'customer_id': 5, 'customer_name': 'Eve', 'city': 'Phoenix'}
            ],
            "orders_data": [
                {'order_id': 101, 'customer_id': 1, 'order_date': '2023-01-15', 'total_amount': 150.00},
                {'order_id': 102, 'customer_id': 2, 'order_date': '2023-02-20', 'total_amount': 200.00},
                {'order_id': 103, 'customer_id': 1, 'order_date': '2023-03-10', 'total_amount': 100.00},
                {'order_id': 104, 'customer_id': 3, 'order_date': '2023-04-05', 'total_amount': 250.00}
            ],
            "expected_output": ['Alice', 'Bob', 'Charlie']
        },
        {
            "name": "Test Case 2: No orders data",
            "customers_data": [
                {'customer_id': 1, 'customer_name': 'Alice', 'city': 'New York'},
                {'customer_id': 2, 'customer_name': 'Bob', 'city': 'Los Angeles'}
            ],
            "orders_data": [],
            "expected_output": []
        },
        {
            "name": "Test Case 3: All customers have orders",
            "customers_data": [
                {'customer_id': 1, 'customer_name': 'Alice', 'city': 'New York'},
                {'customer_id': 2, 'customer_name': 'Bob', 'city': 'Los Angeles'},
                {'customer_id': 3, 'customer_name': 'Charlie', 'city': 'Chicago'}
            ],
            "orders_data": [
                {'order_id': 101, 'customer_id': 1, 'order_date': '2023-01-15', 'total_amount': 150.00},
                {'order_id': 102, 'customer_id': 2, 'order_date': '2023-02-20', 'total_amount': 200.00},
                {'order_id': 103, 'customer_id': 3, 'order_date': '2023-03-10', 'total_amount': 100.00}
            ],
            "expected_output": ['Alice', 'Bob', 'Charlie']
        },
        {
            "name": "Test Case 4: No customers data",
            "customers_data": [],
            "orders_data": [
                {'order_id': 101, 'customer_id': 1, 'order_date': '2023-01-15', 'total_amount': 150.00}
            ],
            "expected_output": []
        },
         {
            "name": "Test Case 5: Empty data",
            "customers_data": [],
            "orders_data": [],
            "expected_output": []
        },
         {
            "name": "Test Case 6: Duplicate orders for the same customer",
            "customers_data": [
                {'customer_id': 1, 'customer_name': 'Alice', 'city': 'New York'}
            ],
            "orders_data": [
                {'order_id': 101, 'customer_id': 1, 'order_date': '2023-01-15', 'total_amount': 150.00},
                {'order_id': 102, 'customer_id': 1, 'order_date': '2023-02-20', 'total_amount': 200.00}
            ],
            "expected_output": ['Alice']
        },
        {
            "name": "Test Case 7: No matching customer_ids in customers data",
            "customers_data": [
                {'customer_id': 1, 'customer_name': 'Alice', 'city': 'New York'}
            ],
            "orders_data": [
                {'order_id': 101, 'customer_id': 2, 'order_date': '2023-01-15', 'total_amount': 150.00}
            ],
            "expected_output": []
        }
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for test_case in test_cases:
        print(f"\nRunning {test_case['name']}")
        actual_output = solve_sql_problem(test_case['customers_data'], test_case['orders_data'])
        if actual_output == test_case['expected_output']:
            print("True")
            correct_tests += 1
        else:
            print("False")
            print(f"  Expected: {test_case['expected_output']}")
            print(f"  Actual:   {actual_output}")

    print(f"\nCorrect tests: {correct_tests}/{total_tests}")

if __name__ == "__main__":
    run_tests()