class MyCalendarTwo:
    def __init__(self):
        self.bookings = []

    def book(self, start: int, end: int) -> bool:
        for i in range(len(self.bookings)):
            for j in range(i + 1, len(self.bookings)):
                s1, e1 = self.bookings[i]
                s2, e2 = self.bookings[j]
                intersection_start = max(start, s1, s2)
                intersection_end = min(end, e1, e2)
                if intersection_start < intersection_end:
                    return False
        self.bookings.append([start, end])
        return True

def run_tests():
    test_cases = [
        ([[], [10, 20], [50, 60], [10, 40], [5, 15], [5, 10], [25, 55]], [True, True, True, False, True, True]),
        ([[], [1, 2], [3, 4], [5, 6]], [True, True, True]),
        ([[], [1, 3], [2, 4], [5, 7], [6, 8]], [True, True, True, True]),
        ([[], [1, 4], [2, 5], [3, 6], [4, 7]], [True, True, True, False]),
        ([[], [0, 10], [5, 15], [10, 20], [0, 5]], [True, True, True, True]),
        ([[], [0, 10], [5, 15], [3, 7]], [True, True, False]),
    ]
    correct_tests = 0
    total_tests = 0
    for test_input, expected_output in test_cases:
        my_calendar = MyCalendarTwo()
        results = []
        inputs = test_input[1:]
        for i in range(len(inputs)):
            start, end = inputs[i]
            result = my_calendar.book(start, end)
            results.append(result)
            if result == expected_output[i]:
                print('True')
            else:
                print('False')
        if results == expected_output:
            correct_tests += 1
        total_tests += 1
    print(f"{correct_tests}/{total_tests}")

if __name__ == '__main__':
    run_tests()