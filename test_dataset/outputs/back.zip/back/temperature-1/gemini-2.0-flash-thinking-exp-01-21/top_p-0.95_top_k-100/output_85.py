def find_max_average(nums, k):
    """
    Finds the contiguous subarray of given length k that has the maximum average value.

    Args:
        nums: A list of integers.
        k: An integer, the length of the subarray.

    Returns:
        The maximum average value.
    """
    n = len(nums)
    if n < k:
        return 0  # Or handle this case as per problem spec if needed

    window_sum = sum(nums[:k])
    max_sum = window_sum

    for i in range(k, n):
        window_sum = window_sum - nums[i - k] + nums[i]
        max_sum = max(max_sum, window_sum)

    return max_sum / k

def run_tests():
    test_cases = [
        (([1, 12, -5, -6, 50, 3], 4), 12.75),
        (([5], 1), 5.0),
        (([-1, -2, -3, -4, -5], 3), -2.0),
        (([0, 0, 0, 0], 2), 0.0),
        (([1, 2, 3, 4, 5], 5), 3.0),
        (([1, 2, 3, 4, 5], 1), 5.0),
        (([5, 4, 3, 2, 1], 1), 5.0),
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, ((nums, k), expected_output) in enumerate(test_cases):
        actual_output = find_max_average(nums, k)
        if abs(actual_output - expected_output) < 1e-9:  # Using tolerance for float comparison
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: nums={nums}, k={k}")
            print(f"  Expected Output: {expected_output}")
            print(f"  Actual Output: {actual_output}")

    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    run_tests()