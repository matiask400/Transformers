def find_center(edges):
    """
    Finds the center of a star graph given its edges.

    Args:
        edges: A list of lists representing the edges of the star graph.

    Returns:
        The center node of the star graph.
    """
    e1 = edges[0]
    e2 = edges[1]
    u1, v1 = e1[0], e1[1]
    u2, v2 = e2[0], e2[1]

    if u1 == u2 or u1 == v2:
        return u1
    elif v1 == u2 or v1 == v2:
        return v1
    else:
        # This should not happen in a valid star graph according to problem description
        return -1

def test_find_center():
    test_cases = [
        ([[1,2],[2,3],[4,2]], 2),
        ([[1,2],[5,1],[1,3],[1,4]], 1),
        ([[7,1],[1,8],[1,9],[1,10],[1,11],[1,12]], 1),
        ([[2,1],[3,1],[4,1]], 1),
        ([[3,4],[3,5],[3,6],[3,7],[3,8],[3,9],[3,10],[3,11],[3,12],[3,13]], 3),
    ]
    correct_count = 0
    for i, (edges, expected_output) in enumerate(test_cases):
        output = find_center(edges)
        if output == expected_output:
            print(f'Test {i+1}: True')
            correct_count += 1
        else:
            print(f'Test {i+1}: False')
    print(f'{correct_count}/{len(test_cases)}')

if __name__ == '__main__':
    test_find_center()