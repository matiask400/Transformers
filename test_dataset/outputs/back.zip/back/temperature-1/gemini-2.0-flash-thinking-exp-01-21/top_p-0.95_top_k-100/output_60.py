def solve():
    def matrix_rank(matrix):
        m = len(matrix)
        n = len(matrix[0])
        answer = [[0] * n for _ in range(m)]
        unique_values = sorted(list(set(matrix[r][c] for r in range(m) for c in range(n))))

        for val in unique_values:
            positions = []
            for r in range(m):
                for c in range(n):
                    if matrix[r][c] == val:
                        positions.append((r, c))

            for r, c in positions:
                rank = 1
                for r_prime in range(m):
                    if r_prime != r and matrix[r_prime][c] < matrix[r][c]:
                        rank = max(rank, answer[r_prime][c] + 1)
                for c_prime in range(n):
                    if c_prime != c and matrix[r][c_prime] < matrix[r][c]:
                        rank = max(rank, answer[r][c_prime] + 1)
                answer[r][c] = rank
        return answer

    def test_cases():
        test_data = [
            ([[1,2],[3,4]], [[1,2],[2,3]]),
            ([[7,7],[7,7]], [[1,1],[1,1]]),
            ([[20,-21,14],[-19,4,19],[22,-47,24],[-19,4,19]], [[4,2,3],[1,3,4],[5,1,6],[1,3,4]]),
            ([[7,3,6],[1,4,5],[9,8,2]], [[5,1,4],[1,2,3],[6,3,1]]),
            ([[1]], [[1]]),
            ([[1, 1, 1]], [[1, 1, 1]]),
            ([[1],[1],[1]], [[1],[1],[1]]),
            ([[1, 2, 3], [4, 5, 6], [7, 8, 9]], [[1, 2, 3], [2, 3, 4], [3, 4, 5]]),
            ([[9, 8, 7], [6, 5, 4], [3, 2, 1]], [[5, 4, 3], [4, 3, 2], [3, 2, 1]]),
            ([[10, 20], [30, 10]], [[1, 2], [2, 1]]),
        ]
        correct_tests = 0
        total_tests = len(test_data)

        for input_matrix, expected_output in test_data:
            actual_output = matrix_rank(input_matrix)
            if actual_output == expected_output:
                print("True")
                correct_tests += 1
            else:
                print("False")
        print(f"{correct_tests}/{total_tests}")

    test_cases()

solve()