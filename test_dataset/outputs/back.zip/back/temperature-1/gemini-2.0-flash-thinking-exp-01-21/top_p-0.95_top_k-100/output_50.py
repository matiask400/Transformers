def solve():
    def candy(ratings):
        n = len(ratings)
        if n == 0:
            return 0
        candies = [1] * n

        for i in range(1, n):
            if ratings[i] > ratings[i-1]:
                candies[i] = candies[i-1] + 1

        for i in range(n-2, -1, -1):
            if ratings[i] > ratings[i+1]:
                candies[i] = max(candies[i], candies[i+1] + 1)

        return sum(candies)

    test_cases = [
        ([1, 0, 2], 5),
        ([1, 2, 2], 4),
        ([1, 3, 2, 2, 1], 7),
        ([0], 1),
        ([1, 1, 1], 3),
        ([1, 2, 3, 4, 5], 15),
        ([5, 4, 3, 2, 1], 15),
        ([2, 1, 0, 1, 2], 9),
    ]

    num_correct = 0
    for i, (ratings, expected_output) in enumerate(test_cases):
        output = candy(ratings)
        if output == expected_output:
            print(f'Test {i+1}: True')
            num_correct += 1
        else:
            print(f'Test {i+1}: False')
    print(f'{num_correct}/{len(test_cases)}')

if __name__ == '__main__':
    solve()