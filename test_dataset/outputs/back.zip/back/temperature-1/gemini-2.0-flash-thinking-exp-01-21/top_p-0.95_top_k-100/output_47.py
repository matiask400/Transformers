def solve():
    def get_compressed_len(text):
        if not text:
            return 0
        compressed_text = ""
        i = 0
        while i < len(text):
            char = text[i]
            count = 0
            while i < len(text) and text[i] == char:
                count += 1
                i += 1
            compressed_text += char
            if count > 1:
                compressed_text += str(count)
        return len(compressed_text)

    def calculate_min_compressed_len(s, k):
        memo = {}

        def dp(start_index, k_remaining):
            if start_index == len(s):
                return 0
            if (start_index, k_remaining) in memo:
                return memo[(start_index, k_remaining)]

            res = float('inf')
            if k_remaining > 0:
                res = min(res, dp(start_index + 1, k_remaining - 1)) # delete s[start_index]

            for end_index in range(start_index + 1, len(s) + 1):
                sub_s = s[start_index:end_index]
                counts = {}
                for char in sub_s:
                    counts[char] = counts.get(char, 0) + 1

                if not counts:
                    continue

                max_count = 0
                best_char = ''
                for char, count in counts.items():
                    if count > max_count:
                        max_count = count
                        best_char = char

                deletions_needed = len(sub_s) - max_count
                if deletions_needed <= k_remaining:
                    current_run_len = 1 if max_count == 1 else (1 + len(str(max_count)))
                    remaining_len = dp(end_index, k_remaining - deletions_needed)
                    res = min(res, current_run_len + remaining_len)

            memo[(start_index, k_remaining)] = res
            return res

        return dp(0, k)

    test_cases = [
        {"input": {"s": "aaabcccd", "k": 2}, "expected": 4},
        {"input": {"s": "aabbaa", "k": 2}, "expected": 2},
        {"input": {"s": "aaaaaaaaaaa", "k": 0}, "expected": 3},
        {"input": {"s": "abcde", "k": 3}, "expected": 2},
        {"input": {"s": "aabbcc", "k": 0}, "expected": 6},
        {"input": {"s": "aabbcc", "k": 1}, "expected": 5},
        {"input": {"s": "aabbcc", "k": 2}, "expected": 4},
        {"input": {"s": "aabbcc", "k": 3}, "expected": 3},
        {"input": {"s": "aabbcc", "k": 4}, "expected": 2},
        {"input": {"s": "aabbcc", "k": 5}, "expected": 1},
        {"input": {"s": "aabbcc", "k": 6}, "expected": 0},
        {"input": {"s": "abaacaba", "k": 2}, "expected": 5},
        {"input": {"s": "aabbccddee", "k": 4}, "expected": 4}
    ]

    num_correct = 0
    for i, case in enumerate(test_cases):
        s = case["input"]["s"]
        k = case["input"]["k"]
        expected_output = case["expected"]
        actual_output = calculate_min_compressed_len(s, k)
        if actual_output == expected_output:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")
        #print(f"Test case {i+1}: Input: s='{s}', k={k}, Expected: {expected_output}, Actual: {actual_output}")

    print(f"{num_correct}/{len(test_cases)}")

solve()