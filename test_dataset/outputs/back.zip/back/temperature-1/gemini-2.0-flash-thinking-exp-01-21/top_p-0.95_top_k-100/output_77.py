from typing import List

class Solution:
    def addOperators(self, num: str, target: int) -> List[str]:
        self.results = []
        n = len(num)

        def explore(index, current_value, last_operand, expression):
            if index == n:
                if current_value == target:
                    self.results.append(expression)
                return

            for i in range(index, n):
                number_str = num[index:i+1]
                if len(number_str) > 1 and number_str[0] == '0':
                    break
                number_val = int(number_str)

                if index == 0:
                    explore(i + 1, number_val, number_val, number_str)
                else:
                    explore(i + 1, current_value + number_val, number_val, expression + "+" + number_str)
                    explore(i + 1, current_value - number_val, -number_val, expression + "-" + number_str)
                    explore(i + 1, current_value - last_operand + last_operand * number_val, last_operand * number_val, expression + "*" + number_str)

        explore(0, 0, 0, "")
        return self.results

def test_addOperators():
    test_cases = [
        {"num": "123", "target": 6, "expected": ["1*2*3","1+2+3"]},
        {"num": "232", "target": 8, "expected": ["2*3+2","2+3*2"]},
        {"num": "105", "target": 5, "expected": ["1*0+5","10-5"]},
        {"num": "00", "target": 0, "expected": ["0*0","0+0","0-0"]},
        {"num": "3456237490", "target": 9191, "expected": []},
        {"num": "1", "target": 1, "expected": ["1"]},
        {"num": "1", "target": 2, "expected": []},
        {"num": "10", "target": 10, "expected": ["10"]},
        {"num": "10", "target": 1, "expected": []},
        {"num": "10", "target": 0, "expected": ["1*0"]},
        {"num": "50", "target": 0, "expected": ["5*0"]},
        {"num": "105", "target": 0, "expected": ["1*0*5", "1*0-5", "1*0+5", "1+0-5", "1-0-5"]},
    ]
    correct_tests = 0
    for i, case in enumerate(test_cases):
        num = case["num"]
        target = case["target"]
        expected = sorted(case["expected"])
        output = sorted(Solution().addOperators(num, target))
        if output == expected:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False, Input: num='{num}', target={target}, Expected: {expected}, Output: {output}")
    print(f"Correct tests: {correct_tests}/{len(test_cases)}")

if __name__ == '__main__':
    test_addOperators()