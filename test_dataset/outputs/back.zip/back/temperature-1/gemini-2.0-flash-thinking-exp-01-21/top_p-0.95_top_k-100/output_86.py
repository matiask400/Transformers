def subarray_sum_equals_k(nums, k):
    """
    Given an array of integers nums and an integer k, return the total number of continuous subarrays whose sum equals to k.
    """
    prefix_sums = {0: 1}
    current_sum = 0
    count = 0
    for num in nums:
        current_sum += num
        target = current_sum - k
        if target in prefix_sums:
            count += prefix_sums[target]
        prefix_sums[current_sum] = prefix_sums.get(current_sum, 0) + 1
    return count

def run_tests():
    test_cases = [
        ([1, 1, 1], 2, 2),
        ([1, 2, 3], 3, 2),
        ([1], 0, 0),
        ([1, 1, 1], 3, 1),
        ([1, 2, 1, 2, 1], 3, 4),
        ([-1, -1, 1], 0, 1),
        ([0, 0, 0], 0, 6),
        ([-1, -1, -1], -2, 2)
    ]
    correct_count = 0
    for nums, k, expected_output in test_cases:
        actual_output = subarray_sum_equals_k(nums, k)
        if actual_output == expected_output:
            print('True')
            correct_count += 1
        else:
            print('False')
    total_tests = len(test_cases)
    print(f"{correct_count}/{total_tests}")

if __name__ == '__main__':
    run_tests()