def sort_array_by_parity(A):
    even_nums = []
    odd_nums = []
    for num in A:
        if num % 2 == 0:
            even_nums.append(num)
        else:
            odd_nums.append(num)
    return even_nums + odd_nums

def test_sort_array_by_parity():
    test_cases = [
        ([3, 1, 2, 4], [2, 4, 3, 1]),
        ([0], [0]),
        ([1], [1]),
        ([2, 4, 6], [2, 4, 6]),
        ([1, 3, 5], [1, 3, 5]),
        ([], []),
        ([1, 2, 3, 4, 5, 6], [2, 4, 6, 1, 3, 5]),
        ([4, 3, 2, 1], [4, 2, 3, 1]),
        ([5000, 0, 1, 4999], [5000, 0, 1, 4999]),
        ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [0, 2, 4, 6, 8, 1, 3, 5, 7, 9])
    ]
    correct_tests = 0
    total_tests = len(test_cases)

    for input_array, expected_output in test_cases:
        output_array = sort_array_by_parity(input_array)

        input_even = sorted([x for x in input_array if x % 2 == 0])
        input_odd = sorted([x for x in input_array if x % 2 != 0])
        output_even = sorted([x for x in output_array if x % 2 == 0])
        output_odd = sorted([x for x in output_array if x % 2 != 0])

        if output_even == input_even and output_odd == input_odd and len(output_array) == len(input_array):
            if len(output_even) > 0 and len(output_odd) > 0:
                even_part_end_index = -1
                for i in range(len(output_array)):
                    if output_array[i] % 2 != 0:
                        even_part_end_index = i - 1
                        break
                else:
                    even_part_end_index = len(output_array) - 1

                if even_part_end_index == -1 and len(input_odd) > 0 and len(input_even) == 0:
                     print('True')
                     correct_tests += 1
                     continue

                if even_part_end_index == len(output_array) -1 and len(input_even) > 0 and len(input_odd) == 0:
                     print('True')
                     correct_tests += 1
                     continue

                if even_part_end_index >= 0:
                    is_even_part_valid = all(x % 2 == 0 for x in output_array[:even_part_end_index+1])
                    is_odd_part_valid = all(x % 2 != 0 for x in output_array[even_part_end_index+1:])

                    if is_even_part_valid and is_odd_part_valid:
                        print('True')
                        correct_tests += 1
                    else:
                        print('False')

                elif len(input_even) == 0 and len(input_odd) > 0:
                     is_odd_part_valid = all(x % 2 != 0 for x in output_array)
                     if is_odd_part_valid:
                         print('True')
                         correct_tests += 1
                     else:
                         print('False')
                elif len(input_odd) == 0 and len(input_even) > 0:
                    is_even_part_valid = all(x % 2 == 0 for x in output_array)
                    if is_even_part_valid:
                         print('True')
                         correct_tests += 1
                    else:
                         print('False')
                elif len(input_even) == 0 and len(input_odd) == 0:
                    print('True')
                    correct_tests += 1
                else:
                    print('False')

            elif len(output_even) > 0 and len(output_odd) == 0:
                 is_even_part_valid = all(x % 2 == 0 for x in output_array)
                 if is_even_part_valid:
                     print('True')
                     correct_tests += 1
                 else:
                     print('False')
            elif len(output_even) == 0 and len(output_odd) > 0:
                 is_odd_part_valid = all(x % 2 != 0 for x in output_array)
                 if is_odd_part_valid:
                     print('True')
                     correct_tests += 1
                 else:
                     print('False')
            elif len(output_even) == 0 and len(output_odd) == 0:
                 print('True')
                 correct_tests += 1
            else:
                 print('False')


        else:
            print('False')

    print(f"{correct_tests}/{total_tests}")

test_sort_array_by_parity()