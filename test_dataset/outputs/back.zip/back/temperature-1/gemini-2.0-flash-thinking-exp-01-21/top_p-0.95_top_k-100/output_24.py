def solve():
    def fall_bricks(current_grid):
        m = len(current_grid)
        n = len(current_grid[0])
        stable = [[False for _ in range(n)] for _ in range(m)]

        def mark_stability(r, c):
            if r < 0 or r >= m or c < 0 or c >= n or stable[r][c] or current_grid[r][c] == 0:
                return
            stable[r][c] = True
            for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                nr, nc = r + dr, c + dc
                mark_stability(nr, nc)

        for j in range(n):
            if current_grid[0][j] == 1:
                mark_stability(0, j)

        fallen_count = 0
        fallen_bricks_pos = []
        for r in range(m):
            for c in range(n):
                if current_grid[r][c] == 1 and not stable[r][c]:
                    fallen_count += 1
                    fallen_bricks_pos.append((r, c))

        for r, c in fallen_bricks_pos:
            current_grid[r][c] = 0
        return fallen_count, current_grid

    grid1 = [[1,0,0,0],[1,1,1,0]]
    hits1 = [[1,0]]
    expected1 = [2]
    result1 = []
    current_grid1 = [row[:] for row in grid1]
    for hit in hits1:
        r, c = hit
        if current_grid1[r][c] == 1:
            current_grid1[r][c] = 0
            fallen_count, current_grid1 = fall_bricks(current_grid1)
            result1.append(fallen_count)
        else:
            result1.append(0)

    test1_passed = result1 == expected1
    print(test1_passed)

    grid2 = [[1,0,0,0],[1,1,0,0]]
    hits2 = [[1,1],[1,0]]
    expected2 = [0, 0]
    result2 = []
    current_grid2 = [row[:] for row in grid2]
    for hit in hits2:
        r, c = hit
        if current_grid2[r][c] == 1:
            current_grid2[r][c] = 0
            fallen_count, current_grid2 = fall_bricks(current_grid2)
            result2.append(fallen_count)
        else:
            result2.append(0)
    test2_passed = result2 == expected2
    print(test2_passed)

    grid3 = [[1,1,1],[1,1,1],[1,1,1]]
    hits3 = [[1,1],[2,1]]
    expected3 = [0, 0]
    result3 = []
    current_grid3 = [row[:] for row in grid3]
    for hit in hits3:
        r, c = hit
        if current_grid3[r][c] == 1:
            current_grid3[r][c] = 0
            fallen_count, current_grid3 = fall_bricks(current_grid3)
            result3.append(fallen_count)
        else:
            result3.append(0)
    test3_passed = result3 == expected3
    print(test3_passed)

    grid4 = [[1,1,1],[1,0,1],[1,1,1]]
    hits4 = [[1,1]]
    expected4 = [0]
    result4 = []
    current_grid4 = [row[:] for row in grid4]
    for hit in hits4:
        r, c = hit
        if current_grid4[r][c] == 1:
            current_grid4[r][c] = 0
            fallen_count, current_grid4 = fall_bricks(current_grid4)
            result4.append(fallen_count)
        else:
            result4.append(0)
    test4_passed = result4 == expected4
    print(test4_passed)

    grid5 = [[1,0,1],[1,1,1],[1,0,1]]
    hits5 = [[0,1],[1,1]]
    expected5 = [0, 1]
    result5 = []
    current_grid5 = [row[:] for row in grid5]
    for hit in hits5:
        r, c = hit
        if current_grid5[r][c] == 1:
            current_grid5[r][c] = 0
            fallen_count, current_grid5 = fall_bricks(current_grid5)
            result5.append(fallen_count)
        else:
            result5.append(0)
    test5_passed = result5 == expected5
    print(test5_passed)

    grid6 = [[0,1,1,1,1],[1,1,1,1,1],[0,1,1,1,1]]
    hits6 = [[1,2],[0,1],[2,0],[0,3],[1,1]]
    expected6 = [0, 0, 1, 1, 0]
    result6 = []
    current_grid6 = [row[:] for row in grid6]
    for hit in hits6:
        r, c = hit
        if current_grid6[r][c] == 1:
            current_grid6[r][c] = 0
            fallen_count, current_grid6 = fall_bricks(current_grid6)
            result6.append(fallen_count)
        else:
            result6.append(0)
    test6_passed = result6 == expected6
    print(test6_passed)

    grid7 = [[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1],[1]]
    hits7 = [[28,0],[29,0],[30,0],[31,0],[32,0],[33,0],[34,0],[35,0],[36,0],[37,0],[38,0],[39,0],[40,0],[41,0],[42,0],[43,0],[44,0],[45,0],[46,0],[47,0],[48,0],[49,0],[27,0],[26,0],[25,0],[24,0],[23,0],[22,0],[21,0],[20,0],[19,0],[18,0],[17,0],[16,0],[15,0],[14,0],[13,0],[12,0],[11,0],[10,0],[9,0],[8,0],[7,0],[6,0],[5,0],[4,0],[3,0],[2,0],[1,0],[0,0]]
    expected7 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    result7 = []
    current_grid7 = [row[:] for row in grid7]
    for hit in hits7:
        r, c = hit
        if current_grid7[r][c] == 1:
            current_grid7[r][c] = 0
            fallen_count, current_grid7 = fall_bricks(current_grid7)
            result7.append(fallen_count)
        else:
            result7.append(0)
    test7_passed = result7 == expected7
    print(test7_passed)


    correct_tests = sum([test1_passed, test2_passed, test3_passed, test4_passed, test5_passed, test6_passed, test7_passed])
    total_tests = 7
    print(f"{correct_tests}/{total_tests}")

solve()