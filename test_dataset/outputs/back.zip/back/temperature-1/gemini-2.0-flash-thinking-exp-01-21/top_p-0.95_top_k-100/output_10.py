def count_substrings_with_abc(s):
    count = 0
    n = len(s)
    for i in range(n):
        for j in range(i, n):
            substring = s[i:j+1]
            if 'a' in substring and 'b' in substring and 'c' in substring:
                count += 1
    return count

def run_tests():
    test_cases = [
        {"input": "abcabc", "expected_output": 10},
        {"input": "aaacb", "expected_output": 3},
        {"input": "abc", "expected_output": 1},
        {"input": "abca", "expected_output": 3},
        {"input": "abcb", "expected_output": 2},
        {"input": "abcc", "expected_output": 2},
        {"input": "abbc", "expected_output": 2},
        {"input": "aabc", "expected_output": 4},
        {"input": "aabbc", "expected_output": 7},
        {"input": "aaabbc", "expected_output": 10},
        {"input": "aaaabbc", "expected_output": 13},
        {"input": "abcbbca", "expected_output": 9},
        {"input": "cababab", "expected_output": 6},
        {"input": "cacacac", "expected_output": 0},
        {"input": "abababa", "expected_output": 0},
        {"input": "bcbcbcb", "expected_output": 0},
        {"input": "ccccccc", "expected_output": 0},
        {"input": "aaaaaaa", "expected_output": 0},
        {"input": "bbbbbbb", "expected_output": 0},
        {"input": "abcabcabc", "expected_output": 19},
        {"input": "cbaabcabc", "expected_output": 20},
        {"input": "abacabcab", "expected_output": 21},
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        input_s = test_case["input"]
        expected_output = test_case["expected_output"]
        actual_output = count_substrings_with_abc(input_s)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {input_s}")
            print(f"  Expected Output: {expected_output}")
            print(f"  Actual Output: {actual_output}")

    print(f"\n{correct_tests}/{total_tests}")

if __name__ == '__main__':
    run_tests()