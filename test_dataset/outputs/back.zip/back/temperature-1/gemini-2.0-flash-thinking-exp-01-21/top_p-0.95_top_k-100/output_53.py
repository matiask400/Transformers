class RangeModule:
    def __init__(self):
        self.ranges = []

    def addRange(self, left: int, right: int) -> None:
        new_ranges = []
        current_range = (left, right)
        for start, end in self.ranges:
            if end < current_range[0]:
                new_ranges.append((start, end))
            elif start > current_range[1]:
                new_ranges.append((start, end))
            else:
                current_range = (min(current_range[0], start), max(current_range[1], end))
        new_ranges.append(current_range)
        new_ranges.sort()
        merged_ranges = []
        if not new_ranges:
            self.ranges = []
            return

        merged_ranges.append(new_ranges[0])
        for i in range(1, len(new_ranges)):
            last_merged_start, last_merged_end = merged_ranges[-1]
            current_start, current_end = new_ranges[i]
            if current_start <= last_merged_end:
                merged_ranges[-1] = (last_merged_start, max(last_merged_end, current_end))
            else:
                merged_ranges.append((current_start, current_end))
        self.ranges = merged_ranges

    def queryRange(self, left: int, right: int) -> bool:
        for start, end in self.ranges:
            if start <= left and end >= right:
                return True
        return False

    def removeRange(self, left: int, right: int) -> None:
        new_ranges = []
        for start, end in self.ranges:
            if end <= left or start >= right:
                new_ranges.append((start, end))
            elif start < left and end > right:
                new_ranges.append((start, left))
                new_ranges.append((right, end))
            elif start < left <= end <= right:
                new_ranges.append((start, left))
            elif left <= start <= right < end:
                new_ranges.append((right, end))
        self.ranges = new_ranges

def test_range_module():
    rm = RangeModule()
    rm.addRange(10, 20)
    rm.removeRange(14, 16)
    test_cases = [
        ((10, 14), True),
        ((13, 15), False),
        ((16, 17), True),
        ((10, 20), False),
        ((12, 13), True),
        ((17, 19), True),
        ((14, 15), False),
        ((9, 10), False),
        ((20, 21), False)
    ]

    results = []
    for (l, r), expected in test_cases:
        result = rm.queryRange(l, r)
        results.append(result == expected)
        print(result == expected, f"queryRange({l}, {r}) == {expected}")

    print(f"{sum(results)}/{len(results)}")

    rm = RangeModule()
    rm.addRange(6, 8)
    rm.removeRange(7, 8)
    rm.removeRange(8, 9)
    rm.addRange(8, 9)
    rm.removeRange(1, 3)
    rm.addRange(2, 4)
    rm.removeRange(3, 5)
    rm.addRange(4, 6)
    test_cases2 = [
        ((1, 2), False),
        ((2, 3), True),
        ((3, 4), False),
        ((4, 5), True),
        ((5, 6), True),
        ((6, 7), False),
        ((7, 8), False),
        ((8, 9), True),
        ((9, 10), False),
        ((4, 6), True)
    ]
    results2 = []
    for (l, r), expected in test_cases2:
        result = rm.queryRange(l, r)
        results2.append(result == expected)
        print(result == expected, f"queryRange({l}, {r}) == {expected}")
    print(f"{sum(results2)}/{len(results2)}")


    rm = RangeModule()
    rm.addRange(1, 10)
    rm.removeRange(2, 5)
    rm.removeRange(6, 8)
    test_cases3 = [
        ((1, 2), True),
        ((2, 3), False),
        ((5, 6), True),
        ((6, 7), False),
        ((8, 9), False),
        ((8, 10), True),
        ((1, 10), False),
        ((1, 11), False)
    ]
    results3 = []
    for (l, r), expected in test_cases3:
        result = rm.queryRange(l, r)
        results3.append(result == expected)
        print(result == expected, f"queryRange({l}, {r}) == {expected}")
    print(f"{sum(results3)}/{len(results3)}")

    rm = RangeModule()
    rm.addRange(1, 5)
    rm.addRange(10, 12)
    rm.removeRange(2, 11)
    test_cases4 = [
        ((1, 2), True),
        ((2, 3), False),
        ((9, 10), False),
        ((11, 12), True),
        ((1, 5), False),
        ((10, 12), False),
        ((1, 12), False),
        ((0, 1), False),
        ((12, 13), False)
    ]
    results4 = []
    for (l, r), expected in test_cases4:
        result = rm.queryRange(l, r)
        results4.append(result == expected)
        print(result == expected, f"queryRange({l}, {r}) == {expected}")
    print(f"{sum(results4)}/{len(results4)}")

test_range_module()