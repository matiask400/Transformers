def solve():
    """
    This function compares the output of SQL queries (represented as Python lists of tuples)
    with expected outputs and runs tests.
    It prints 'True' for each test passed and 'False' for each test failed,
    and finally prints the number of correct tests over the total.
    """

    def run_test(query_result, expected_result, test_number):
        """
        Compares the query result with the expected result and prints the test outcome.
        """
        if query_result == expected_result:
            print(f"Test {test_number}: True")
            return True
        else:
            print(f"Test {test_number}: False")
            print(f"  Expected: {expected_result}")
            print(f"  Got: {query_result}")
            return False

    # Define test cases: (query result, expected result)
    test_cases = [
        # Example 1: Simple query with one row
        (
            [("Alice",)],  # Query Result
            [("Alice",)],  # Expected Result
        ),
        # Example 2: Query with multiple rows
        (
            [("Alice",), ("Bob",), ("Charlie",)],  # Query Result
            [("Alice",), ("Bob",), ("Charlie",)],  # Expected Result
        ),
        # Example 3: Query with different data types
        (
            [(1, "Alice"), (2, "Bob")],  # Query Result
            [(1, "Alice"), (2, "Bob")],  # Expected Result
        ),
        # Example 4: Empty result set
        (
            [],  # Query Result
            [],  # Expected Result
        ),
        # Example 5: Test with different order (should fail)
        (
            [("Bob",), ("Alice",)],  # Query Result
            [("Alice",), ("Bob",)],  # Expected Result
        ),

        # Example 6: Test with different values (should fail)
        (
            [("Alice",), ("Charlie",)],  # Query Result
            [("Alice",), ("Bob",)],  # Expected Result
        ),
    ]

    # Run the tests
    correct_tests = 0
    total_tests = len(test_cases)

    for i, (query_result, expected_result) in enumerate(test_cases):
        if run_test(query_result, expected_result, i + 1):
            correct_tests += 1

    # Print the final result
    print(f"Correct tests: {correct_tests}/{total_tests}")

if __name__ == "__main__":
    solve()