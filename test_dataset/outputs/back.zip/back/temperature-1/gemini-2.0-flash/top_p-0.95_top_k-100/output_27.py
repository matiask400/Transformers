def erase_overlap_intervals(intervals):
    """
    Given a collection of intervals, find the minimum number of intervals you need to remove to make the rest of the intervals non-overlapping.

    :param intervals: A list of intervals, where each interval is a list of two integers [start, end].
    :return: The minimum number of intervals to remove.
    """
    if not intervals:
        return 0

    intervals.sort(key=lambda x: x[1])  # Sort by end time

    count = 0
    end = intervals[0][1]
    for i in range(1, len(intervals)):
        if intervals[i][0] < end:
            count += 1
        else:
            end = intervals[i][1]

    return count


def test_erase_overlap_intervals():
    test_cases = [
        ([[1, 2], [2, 3], [3, 4], [1, 3]], 1),
        ([[1, 2], [1, 2], [1, 2]], 2),
        ([[1, 2], [2, 3]], 0),
        ([[1, 100], [11, 22], [1, 11], [2, 12]], 2),
        ([], 0),
        ([[1,2]], 0)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (intervals, expected) in enumerate(test_cases):
        result = erase_overlap_intervals(intervals)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Expected: {expected}, Got: {result})")

    print(f"\nCorrect: {correct_count}/{total_count}")


if __name__ == '__main__':
    test_erase_overlap_intervals()