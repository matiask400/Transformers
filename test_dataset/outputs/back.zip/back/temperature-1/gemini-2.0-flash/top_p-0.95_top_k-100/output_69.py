import subprocess

def test_word_frequency(words_txt_content, expected_output):
    """
    Tests the word frequency script using a given input and expected output.

    Args:
        words_txt_content: The content of the words.txt file.
        expected_output: The expected output of the script.

    Returns:
        None. Prints the test results and the summary.
    """

    # Create a temporary file with the given content
    with open("words.txt", "w") as f:
        f.write(words_txt_content)

    # Run the one-line bash script
    try:
        result = subprocess.run(
            "tr -s ' ' '\\n' < words.txt | sort | uniq -c | sort -nr | awk '{print $2, $1}'",
            shell=True,
            capture_output=True,
            text=True,
            check=True
        )
        actual_output = result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"Error running the script: {e}")
        return

    # Compare the actual output with the expected output
    if actual_output == expected_output:
        print("True")
        return True
    else:
        print("False")
        print(f"Expected: {expected_output}")
        print(f"Actual:   {actual_output}")
        return False


def main():
    """
    Main function to run the tests.
    """
    tests = [
        {
            "input": "the day is sunny the the\nthe sunny is is",
            "expected": "the 4\nis 3\nsunny 2\nday 1"
        },
        {
            "input": "apple banana apple orange banana apple",
            "expected": "apple 3\nbanana 2\norange 1"
        },
        {
            "input": "one two three four five six seven eight nine ten\none two three four five six seven eight nine ten",
            "expected": "ten 2\nnine 2\none 2\ntwo 2\nthree 2\nfour 2\nfive 2\nsix 2\nseven 2\neight 2"
        },
        {
            "input": "word",
            "expected": "word 1"
        },
        {
            "input": "  word1   word2    word1 ",
            "expected": "word1 2\nword2 1"
        }
    ]

    correct_count = 0
    total_count = len(tests)

    for test in tests:
        if test_word_frequency(test["input"], test["expected"]):
            correct_count += 1

    print(f"\n{correct_count}/{total_count}")


if __name__ == "__main__":
    main()