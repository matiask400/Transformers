class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def print_tree(root):
    def get_height(node):
        if not node:
            return 0
        return 1 + max(get_height(node.left), get_height(node.right))

    def build_result(node, result, row, left, right):
        if not node:
            return
        mid = (left + right) // 2
        result[row][mid] = str(node.val)
        build_result(node.left, result, row + 1, left, mid - 1)
        build_result(node.right, result, row + 1, mid + 1, right)

    height = get_height(root)
    width = 2 ** height - 1
    result = [[""] * width for _ in range(height)]
    build_result(root, result, 0, 0, width - 1)
    return result

def solve():
    def test_case(root, expected):
        actual = print_tree(root)
        if actual == expected:
            print("True")
        else:
            print("False")
        return actual == expected

    tests = []

    # Test case 1
    root1 = TreeNode(1, TreeNode(2))
    expected1 = [["", "1", ""], ["2", "", ""]]
    tests.append((root1, expected1))

    # Test case 2
    root2 = TreeNode(1, TreeNode(2, None, TreeNode(4)), TreeNode(3))
    expected2 = [["", "", "", "1", "", "", ""], ["", "2", "", "", "", "3", ""], ["", "", "4", "", "", "", ""]]
    tests.append((root2, expected2))

    # Test case 3
    root3 = TreeNode(1, TreeNode(2, TreeNode(3, TreeNode(4))), TreeNode(5))
    expected3 = [["",  "",  "", "",  "", "", "", "1", "",  "",  "",  "",  "", "", ""],
                 ["",  "",  "", "2", "", "", "", "",  "",  "",  "",  "5", "", "", ""],
                 ["",  "3", "", "",  "", "", "", "",  "",  "",  "",  "",  "", "", ""],
                 ["4", "",  "", "",  "", "", "", "",  "",  "",  "",  "",  "", "", ""]]
    tests.append((root3, expected3))

    # Test case 4
    root4 = TreeNode(1)
    expected4 = [["1"]]
    tests.append((root4, expected4))

    # Test case 5: Empty tree
    tests.append((None, []))
    
    correct_count = 0
    for root, expected in tests:
        if test_case(root, expected):
            correct_count += 1

    print(f"{correct_count}/{len(tests)}")

solve()