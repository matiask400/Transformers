def evaluate_rpn(tokens):
    """
    Evaluates an arithmetic expression in Reverse Polish Notation.

    Args:
        tokens: A list of strings representing the RPN expression.

    Returns:
        The value of the expression.
    """
    stack = []
    for token in tokens:
        if token == "+":
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.append(operand1 + operand2)
        elif token == "-":
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.append(operand1 - operand2)
        elif token == "*":
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.append(operand1 * operand2)
        elif token == "/":
            operand2 = stack.pop()
            operand1 = stack.pop()
            stack.append(int(operand1 / operand2))  # Truncate toward zero
        else:
            stack.append(int(token))
    return stack[0]


def test_evaluate_rpn():
    """Tests the evaluate_rpn function."""
    test_cases = [
        (["2", "1", "+", "3", "*"], 9),
        (["4", "13", "5", "/", "+"], 6),
        (["10", "6", "9", "3", "+", "-11", "*", "/", "*", "17", "+", "5", "+"], 22),
        (["2", "1", "+"], 3),
        (["5", "2", "/"], 2),
        (["-1", "1", "+"], 0),
        (["13", "-5", "/"], -2),
        (["3", "-4", "+"], -1)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (tokens, expected_output) in enumerate(test_cases):
        actual_output = evaluate_rpn(tokens)
        if actual_output == expected_output:
            print(f"Test {i + 1}: True")
            correct_count += 1
        else:
            print(f"Test {i + 1}: False (Input: {tokens}, Expected: {expected_output}, Actual: {actual_output})")

    print(f"\nCorrect: {correct_count} / {total_count}")

if __name__ == "__main__":
    test_evaluate_rpn()