def getLengthOfRunLengthEncoding(count):
    if count == 1:
        return 1
    if count < 10:
        return 2
    if count < 100:
        return 3
    return 4

def solve():
    def min_length(s, k):
        n = len(s)
        dp = {}

        def dfs(i, k):
            if (i, k) in dp:
                return dp[(i, k)]
            
            if i == n:
                return 0
            
            ans = float('inf')
            
            # Delete s[i]
            if k > 0:
                ans = min(ans, dfs(i + 1, k - 1))
            
            # Keep s[i]
            count = 0
            deleted = 0
            for j in range(i, n):
                if s[j] == s[i]:
                    count += 1
                else:
                    deleted += 1
                
                if deleted <= k:
                    remaining_k = k - deleted
                    len_run = 1 if count == 1 else getLengthOfRunLengthEncoding(count)
                    ans = min(ans, len_run + dfs(j + 1, remaining_k))
            
            dp[(i, k)] = ans
            return ans

        return dfs(0, k)

    tests = [
        {"input": {"s": "aaabcccd", "k": 2}, "expected": 4},
        {"input": {"s": "aabbaa", "k": 2}, "expected": 2},
        {"input": {"s": "aaaaaaaaaaa", "k": 0}, "expected": 3},
        {"input": {"s": "abc", "k": 1}, "expected": 2},
        {"input": {"s": "abbbbccc", "k": 1}, "expected": 4},
        {"input": {"s": "abcabcabc", "k": 3}, "expected": 0},
        {"input": {"s": "abcabcabc", "k": 0}, "expected": 9},
        {"input": {"s": "abcdefghijk", "k": 5}, "expected": 6},
        {"input": {"s": "aaaaaaaaab", "k": 1}, "expected": 2},
        {"input": {"s": "ababababab", "k": 0}, "expected": 10},
        {"input": {"s": "ababababab", "k": 5}, "expected": 0},
        {"input": {"s": "aaaaaaaaaabbbbbbbbbc", "k": 3}, "expected": 4},
        {"input": {"s": "aaaaaaaaaabbbbbbbbbc", "k": 0}, "expected": 5},
        {"input": {"s": "aaaaaaaaaabbbbbbbbbc", "k": 1}, "expected": 5},
        {"input": {"s": "aaaaaaaaaabbbbbbbbbc", "k": 2}, "expected": 4},
        {"input": {"s": "ababba", "k": 1}, "expected": 4},
        {"input": {"s": "ababba", "k": 2}, "expected": 2},
        {"input": {"s": "ababba", "k": 3}, "expected": 2},
        {"input": {"s": "ababba", "k": 0}, "expected": 6},
        {"input": {"s": "aaaaaaaaaaaa", "k": 1}, "expected": 3},
        {"input": {"s": "abcde", "k": 0}, "expected": 5},
        {"input": {"s": "aaaaa", "k": 0}, "expected": 2}
    ]

    correct_count = 0
    for i, test in enumerate(tests):
        s = test["input"]["s"]
        k = test["input"]["k"]
        expected = test["expected"]
        result = min_length(s, k)
        if result == expected:
            print(True)
            correct_count += 1
        else:
            print(False)
            print(f"Test {i+1} failed: Input s={s}, k={k}, Expected {expected}, Got {result}")

    print(f"{correct_count}/{len(tests)}")

solve()