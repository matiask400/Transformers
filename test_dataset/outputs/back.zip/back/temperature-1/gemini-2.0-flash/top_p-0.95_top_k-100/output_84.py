def solve():
    def find_num_provinces(isConnected):
        n = len(isConnected)
        visited = [False] * n
        count = 0

        def dfs(city):
            visited[city] = True
            for neighbor in range(n):
                if isConnected[city][neighbor] == 1 and not visited[neighbor]:
                    dfs(neighbor)

        for city in range(n):
            if not visited[city]:
                dfs(city)
                count += 1

        return count

    test_cases = [
        ([[1, 1, 0], [1, 1, 0], [0, 0, 1]], 2),
        ([[1, 0, 0], [0, 1, 0], [0, 0, 1]], 3),
        ([[1, 1, 1], [1, 1, 1], [1, 1, 1]], 1),
        ([[1, 0, 0, 1], [0, 1, 1, 0], [0, 1, 1, 1], [1, 0, 1, 1]], 1)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for isConnected, expected in test_cases:
        result = find_num_provinces(isConnected)
        if result == expected:
            print('True')
            correct_count += 1
        else:
            print('False')

    print(f"{correct_count}/{total_count}")


solve()