def add_operators(num, target):
    def helper(index, current_expression, current_value, previous_operand):
        if index == len(num):
            if current_value == target:
                result.append(current_expression)
            return

        for i in range(index, len(num)):
            if i > index and num[index] == '0':
                break

            current_string = num[index:i + 1]
            current_number = int(current_string)

            if index == 0:
                helper(i + 1, current_string, current_number, current_number)
            else:
                helper(i + 1, current_expression + "+" + current_string, current_value + current_number, current_number)
                helper(i + 1, current_expression + "-" + current_string, current_value - current_number, -current_number)
                helper(i + 1, current_expression + "*" + current_string, current_value - previous_operand + previous_operand * current_number, previous_operand * current_number)

    result = []
    helper(0, "", 0, 0)
    return result


def test_add_operators():
    tests = [
        {"input": {"num": "123", "target": 6}, "expected": ["1*2*3", "1+2+3"]},
        {"input": {"num": "232", "target": 8}, "expected": ["2*3+2", "2+3*2"]},
        {"input": {"num": "105", "target": 5}, "expected": ["1*0+5", "10-5"]},
        {"input": {"num": "00", "target": 0}, "expected": ["0*0", "0+0", "0-0"]},
        {"input": {"num": "3456237490", "target": 9191}, "expected": []},
        {"input": {"num": "1", "target": 1}, "expected": ["1"]},
        {"input": {"num": "10", "target": 10}, "expected": ["10"]},
        {"input": {"num": "10", "target": 1}, "expected": []},
        {"input": {"num": "100", "target": 10}, "expected": ["10-0", "10*0"]},
        {"input": {"num": "100", "target": 1}, "expected": []}

    ]

    correct_count = 0
    total_tests = len(tests)

    for i, test in enumerate(tests):
        num = test["input"]["num"]
        target = test["input"]["target"]
        expected = test["expected"]

        actual = add_operators(num, target)
        actual.sort()
        expected.sort()

        if actual == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: num={num}, target={target}")
            print(f"  Expected: {expected}")
            print(f"  Actual: {actual}")

    print(f"\nCorrect: {correct_count}/{total_tests}")

test_add_operators()