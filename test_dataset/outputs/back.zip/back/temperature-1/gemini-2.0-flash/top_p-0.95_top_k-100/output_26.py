def balancedStringSplit(s):
    balance = 0
    count = 0
    for char in s:
        if char == 'R':
            balance += 1
        else:
            balance -= 1
        if balance == 0:
            count += 1
    return count

def test_balancedStringSplit():
    test_cases = [
        ("RLRRLLRLRL", 4),
        ("RLLLLRRRLR", 3),
        ("LLLLRRRR", 1),
        ("RLRRRLLRLL", 2)
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, (input_str, expected_output) in enumerate(test_cases):
        actual_output = balancedStringSplit(input_str)
        if actual_output == expected_output:
            print("True")
            num_correct += 1
        else:
            print("False")

    print(f"{num_correct}/{total_tests}")

test_balancedStringSplit()