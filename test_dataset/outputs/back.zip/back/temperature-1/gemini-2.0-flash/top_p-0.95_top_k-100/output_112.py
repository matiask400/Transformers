def longest_line(matrix):
    if not matrix or not matrix[0]:
        return 0
    rows, cols = len(matrix), len(matrix[0])
    max_len = 0
    for i in range(rows):
        for j in range(cols):
            if matrix[i][j] == 1:
                # Horizontal
                length = 1
                k = j + 1
                while k < cols and matrix[i][k] == 1:
                    length += 1
                    k += 1
                max_len = max(max_len, length)
                # Vertical
                length = 1
                k = i + 1
                while k < rows and matrix[k][j] == 1:
                    length += 1
                    k += 1
                max_len = max(max_len, length)
                # Diagonal
                length = 1
                k, l = i + 1, j + 1
                while k < rows and l < cols and matrix[k][l] == 1:
                    length += 1
                    k += 1
                    l += 1
                max_len = max(max_len, length)
                # Anti-diagonal
                length = 1
                k, l = i + 1, j - 1
                while k < rows and l >= 0 and matrix[k][l] == 1:
                    length += 1
                    k += 1
                    l -= 1
                max_len = max(max_len, length)
    return max_len

def test_longest_line():
    test_cases = [
        ([[0,1,1,0], [0,1,1,0], [0,0,0,1]], 3),
        ([[1,1,1,1], [0,1,1,0], [0,0,0,1]], 4),
        ([[0,1,0], [0,1,0], [0,1,0]], 3),
        ([[0,0,0], [0,0,0], [0,0,0]], 0),
        ([[1,0,0], [0,1,0], [0,0,1]], 1),
        ([[1,1,1], [1,1,1], [1,1,1]], 3),
        ([], 0),
        ([[]], 0),
        ([[1]], 1),
        ([[0]], 0),
        ([[1, 0, 1, 0, 1, 0, 1, 0, 1, 0], [1, 1, 0, 0, 0, 0, 0, 0, 1, 0], [1, 0, 1, 0, 1, 0, 1, 0, 1, 0], [1, 0, 0, 0, 0, 0, 0, 0, 1, 0], [1, 0, 1, 0, 1, 0, 1, 0, 1, 0]], 10)
    ]
    
    correct_count = 0
    total_count = len(test_cases)

    for i, (input_matrix, expected_output) in enumerate(test_cases):
        actual_output = longest_line(input_matrix)
        if actual_output == expected_output:
            print(True)
            correct_count += 1
        else:
            print(False)
    print(f"{correct_count}/{total_count}")

test_longest_line()