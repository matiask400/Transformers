def shortest_encoding(words):
    """
    Calculates the length of the shortest reference string possible of any valid encoding of words.

    Args:
        words: A list of strings.

    Returns:
        The length of the shortest reference string.
    """
    good = set(words)
    for word in words:
        for k in range(1, len(word)):
            good.discard(word[k:])

    return sum(len(word) + 1 for word in good)


def test_shortest_encoding():
    test_cases = [
        {
            "input": ["time", "me", "bell"],
            "expected": 10
        },
        {
            "input": ["t"],
            "expected": 2
        },
        {
            "input": ["time", "time", "time", "time"],
            "expected": 5
        },
        {
            "input": ["time", "me", "bell", "time"],
            "expected": 10
        },
        {
            "input": ["time", "me", "me", "time"],
            "expected": 5
        },
        {
            "input": ["time", "atime", "btime"],
            "expected": 15
        }
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, test_case in enumerate(test_cases):
        input_words = test_case["input"]
        expected_output = test_case["expected"]
        actual_output = shortest_encoding(input_words)

        if actual_output == expected_output:
            print(f"True")
            correct_count += 1
        else:
            print(f"False")

    print(f"{correct_count}/{total_count}")

test_shortest_encoding()