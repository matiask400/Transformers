def isBoomerang(points):
    """
    Determines if three points form a boomerang.

    Args:
        points: A list of three points, where each point is a list of two integers [x, y].

    Returns:
        True if the points form a boomerang, False otherwise.
    """

    if len(points) != 3:
        return False

    p1, p2, p3 = points

    # Check if all points are distinct
    if p1 == p2 or p1 == p3 or p2 == p3:
        return False

    # Check if the points are in a straight line (collinear)
    # Calculate the slope between p1 and p2, and p1 and p3
    # If the slopes are equal, the points are collinear

    # Handle the case where x1 == x2 or x1 == x3 to avoid division by zero
    if p1[0] == p2[0]:
        if p1[0] == p3[0]:
            return False  # All x values are the same, and since points are distinct, collinear

        # Check if p1, p3 have the same slope
        return True
    elif p1[0] == p3[0]:
        return True

    slope12 = (p2[1] - p1[1]) / (p2[0] - p1[0])
    slope13 = (p3[1] - p1[1]) / (p3[0] - p1[0])

    return slope12 != slope13


def test_isBoomerang():
    test_cases = [
        ([[1, 1], [2, 3], [3, 2]], True),
        ([[1, 1], [2, 2], [3, 3]], False),
        ([[0, 0], [1, 1], [2, 2]], False),
        ([[0, 0], [1, 1], [0, 2]], True),
        ([[1, 0], [0, 0], [0, 1]], True),
        ([[1, 0], [0, 0], [1, 0]], False),
        ([[1, 1], [1, 2], [1, 3]], False) # vertical line
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (points, expected) in enumerate(test_cases):
        result = isBoomerang(points)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {points}")
            print(f"  Expected: {expected}")
            print(f"  Got: {result}")

    print(f"\n{correct_count}/{total_count}")


if __name__ == "__main__":
    test_isBoomerang()