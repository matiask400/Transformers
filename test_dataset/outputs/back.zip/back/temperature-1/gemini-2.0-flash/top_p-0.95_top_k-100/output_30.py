def remove_outer_parentheses(S):
    """
    Given a valid parentheses string S, consider its primitive decomposition: S = P_1 + P_2 + ... + P_k,
    where P_i are primitive valid parentheses strings.
    Return S after removing the outermost parentheses of every primitive string in the primitive decomposition of S.

    Example 1:
    Input: "(()())(())"
    Output: "()()()"
    Explanation:
    The input string is "(()())(())", with primitive decomposition "(()())" + "(())".
    After removing outer parentheses of each part, this is "()()" + "()" = "()()()".

    Example 2:
    Input: "(()())(())(()(()))"
    Output: "()()()()(())"
    Explanation:
    The input string is "(()())(())(()(()))", with primitive decomposition "(()())" + "(())" + "(()(()))".
    After removing outer parentheses of each part, this is "()()" + "()" + "()(())" = "()()()()(())".

    Example 3:
    Input: "()()"
    Output: ""
    Explanation:
    The input string is "()()", with primitive decomposition "()" + "()".
    After removing outer parentheses of each part, this is "" + "" = "".

    Note:
    S.length <= 10000
    S[i] is "(" or ")"
    S is a valid parentheses string
    """
    result = ""
    balance = 0
    start = 0
    for i in range(len(S)):
        if S[i] == '(':
            balance += 1
        else:
            balance -= 1
        if balance == 0:
            result += S[start + 1:i]
            start = i + 1
    return result

def test_remove_outer_parentheses():
    tests = [
        {
            "input": "(()())(())",
            "expected": "()()()"
        },
        {
            "input": "(()())(())(()(()))",
            "expected": "()()()()(())"
        },
        {
            "input": "()()",
            "expected": ""
        },
        {
            "input": "(()(()))",
            "expected": "()(())"
        }
    ]

    correct_count = 0
    total_count = len(tests)

    for test in tests:
        input_str = test["input"]
        expected_output = test["expected"]
        actual_output = remove_outer_parentheses(input_str)

        if actual_output == expected_output:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_remove_outer_parentheses()