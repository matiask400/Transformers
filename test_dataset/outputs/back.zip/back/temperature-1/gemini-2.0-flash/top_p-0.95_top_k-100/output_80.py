def num_distinct_subsequences(s, t):
    """
    Given two strings s and t, return the number of distinct subsequences of s which equals t.
    """
    n = len(s)
    m = len(t)

    # dp[i][j] represents the number of distinct subsequences of s[:i] which equals t[:j]
    dp = [[0] * (m + 1) for _ in range(n + 1)]

    # Base case: empty string t is a subsequence of any string s
    for i in range(n + 1):
        dp[i][0] = 1

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            if s[i - 1] == t[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j]
            else:
                dp[i][j] = dp[i - 1][j]

    return dp[n][m]

def test_num_distinct_subsequences():
    test_cases = [
        (("rabbbit", "rabbit"), 3),
        (("babgbag", "bag"), 5),
        (("abcde", "abc"), 1),
        (("abcde", "ace"), 1),
        (("abcde", "aec"), 0),
        (("ddd", "dd"), 3),
        (("aaaaaaaaaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaa"), 102345),
        (("daacbdddacddcca", "acca"), 46),
        (("aabb", "ab"), 4)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for (s, t), expected in test_cases:
        result = num_distinct_subsequences(s, t)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")

if __name__ == '__main__':
    test_num_distinct_subsequences()