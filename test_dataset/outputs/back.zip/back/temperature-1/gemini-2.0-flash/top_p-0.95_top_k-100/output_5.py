def largeGroupPositions(s):
    """
    Finds the intervals of every large group in a string.

    Args:
        s: The input string of lowercase letters.

    Returns:
        A list of intervals representing the large groups, sorted by start index.
    """
    result = []
    start = 0
    for i in range(len(s)):
        if i == len(s) - 1 or s[i] != s[i + 1]:
            if i - start + 1 >= 3:
                result.append([start, i])
            start = i + 1
    return result

def test_largeGroupPositions():
    """
    Tests the largeGroupPositions function with several test cases.
    """
    test_cases = [
        ("abbxxxxzzy", [[3, 6]]),
        ("abc", []),
        ("abcdddeeeeaabbbcd", [[3, 5], [6, 9], [12, 14]]),
        ("aba", []),
        ("aaa", [[0, 2]]),
        ("aaaa", [[0, 3]]),
        ("babaaaabbb", [[4, 6], [7, 9]]),
        ("aabbbccdddeee", [[2, 4], [5, 7], [8, 10]])
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, (s, expected) in enumerate(test_cases):
        actual = largeGroupPositions(s)
        if actual == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Input: {s}, Expected: {expected}, Actual: {actual})")

    print(f"\nCorrect: {correct_count}/{total_tests}")

if __name__ == "__main__":
    test_largeGroupPositions()