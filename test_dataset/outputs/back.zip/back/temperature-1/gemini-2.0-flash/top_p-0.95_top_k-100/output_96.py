def findCelebrity(n, knows_func):
    """
    Finds the celebrity in a party of n people.

    Args:
        n: The number of people in the party.
        knows_func: A function that takes two integers (a, b) and returns True if a knows b, and False otherwise.

    Returns:
        The label of the celebrity if there is one, otherwise -1.
    """

    candidate = 0
    for i in range(1, n):
        if knows_func(candidate, i):
            candidate = i

    for i in range(n):
        if i != candidate and (knows_func(candidate, i) or not knows_func(i, candidate)):
            return -1

    return candidate


def test_findCelebrity():
    """
    Tests the findCelebrity function.
    """

    test_cases = [
        (3, [[1, 1, 0], [0, 1, 0], [1, 1, 1]], 1),
        (3, [[1, 0, 1], [1, 1, 0], [0, 1, 1]], -1),
        (2, [[1, 0], [1, 1]], 0),
        (2, [[1, 1], [0, 1]], 1),
        (2, [[1, 0], [0, 1]], -1),
        (4, [[1, 1, 1, 0], [0, 1, 0, 0], [1, 1, 1, 0], [1, 1, 1, 1]], 1),
        (4, [[1, 1, 1, 1], [0, 1, 0, 0], [1, 1, 1, 1], [1, 1, 1, 1]], -1),
        (4, [[1, 1, 1, 1], [0, 1, 0, 0], [0, 1, 1, 0], [0, 1, 1, 1]], -1),


    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (n, graph, expected) in enumerate(test_cases):
        def knows(a, b):
            return graph[a][b] == 1

        result = findCelebrity(n, knows)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Expected: {expected}, Got: {result})")

    print(f"\nCorrect: {correct_count}/{total_count}")


if __name__ == "__main__":
    test_findCelebrity()