class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def str2tree(s):
    if not s:
        return None

    def parse_tree(s, index):
        if index >= len(s):
            return None, index

        sign = 1
        if s[index] == '-':
            sign = -1
            index += 1

        num = 0
        while index < len(s) and s[index].isdigit():
            num = num * 10 + int(s[index])
            index += 1

        root = TreeNode(sign * num)

        if index < len(s) and s[index] == '(':
            index += 1
            root.left, index = parse_tree(s, index)
            if index < len(s) and s[index] == ')':
                index += 1

        if index < len(s) and s[index] == '(':
            index += 1
            root.right, index = parse_tree(s, index)
            if index < len(s) and s[index] == ')':
                index += 1

        return root, index

    root, _ = parse_tree(s, 0)
    return root

def inorder_traversal(root):
    if not root:
        return []
    return inorder_traversal(root.left) + [root.val] + inorder_traversal(root.right)

def level_order_traversal(root):
    if not root:
        return []

    result = []
    queue = [root]
    while queue:
        node = queue.pop(0)
        result.append(node.val)
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
    return result
    
def test_str2tree():
    test_cases = [
        ("4(2(3)(1))(6(5))", [4,2,6,3,1,5]),
        ("4(2(3)(1))(6(5)(7))", [4,2,6,3,1,5,7]),
        ("-4(2(3)(1))(6(5)(7))", [-4,2,6,3,1,5,7]),
        ("1(2()(4))", [1,2,4]),
        ("1", [1]),
        ("", []),
        ("0", [0]),
        ("-1(2(3)(4))", [-1, 2, 3, 4]),
        ("10(4(2)(1))(6)", [10,4,6,2,1]),
        ("5(2(4))(3(6(7)(8))(5(9)(10)))", [5,2,3,4,6,5,7,8,9,10]),
        ("-12(5(2)(6(13)(14)))(11(15)(16))", [-12, 5, 11, 2, 6, 15, 16, 13, 14])
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (s, expected) in enumerate(test_cases):
        root = str2tree(s)
        actual = level_order_traversal(root)
        if actual == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {s}")
            print(f"  Expected: {expected}")
            print(f"  Actual: {actual}")

    print(f"{correct_count}/{total_count}")

test_str2tree()