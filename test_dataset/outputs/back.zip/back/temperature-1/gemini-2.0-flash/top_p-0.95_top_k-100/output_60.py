def matrix_rank_transform(matrix):
    """
    Given an m x n matrix, return a new matrix answer where answer[row][col] is the rank of matrix[row][col].
    The rank is an integer that represents how large an element is compared to other elements. It is calculated using the following rules:
    The rank is an integer starting from 1.
    If two elements p and q are in the same row or column, then:
    If p < q then rank(p) < rank(q)
    If p == q then rank(p) == rank(q)
    If p > q then rank(p) > rank(q)
    The rank should be as small as possible.
    It is guaranteed that answer is unique under the given rules.

    Args:
      matrix: A list of lists of integers.

    Returns:
      A list of lists of integers representing the rank of each element in the input matrix.
    """

    m = len(matrix)
    n = len(matrix[0])
    ranks = [0] * (m + n)
    indices = sorted([(matrix[i][j], i, j) for i in range(m) for j in range(n)])
    
    adj = {}
    
    for val, i, j in indices:
        
        row = i
        col = m + j
        
        if val not in adj:
            adj[val] = []
            
        adj[val].append((i,j))
            
    
    
    result = [[0] * n for _ in range(m)]

    for val in sorted(adj.keys()):
        
        nodes = adj[val]

        group_ranks = [0] * (m+n)

        for node_row, node_col in nodes:
            group_ranks[node_row] = max(group_ranks[node_row], ranks[node_row])
            group_ranks[m+node_col] = max(group_ranks[m+node_col], ranks[m+node_col])
        
        new_rank = max(group_ranks) + 1
            
        for node_row, node_col in nodes:
            result[node_row][node_col] = new_rank

            ranks[node_row] = new_rank
            ranks[m+node_col] = new_rank
                
    return result


def test_matrix_rank_transform():
    """Tests the matrix_rank_transform function."""
    test_cases = [
        (
            [[1, 2], [3, 4]],
            [[1, 2], [2, 3]]
        ),
        (
            [[7, 7], [7, 7]],
            [[1, 1], [1, 1]]
        ),
        (
            [[20, -21, 14], [-19, 4, 19], [22, -47, 24], [-19, 4, 19]],
            [[4, 2, 3], [1, 3, 4], [5, 1, 6], [1, 3, 4]]
        ),
        (
            [[7, 3, 6], [1, 4, 5], [9, 8, 2]],
            [[5, 1, 4], [1, 2, 3], [6, 3, 1]]
        )
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for input_matrix, expected_output in test_cases:
        actual_output = matrix_rank_transform(input_matrix)
        if actual_output == expected_output:
            print("True")
            num_correct += 1
        else:
            print("False")
            print(f"Input: {input_matrix}")
            print(f"Expected: {expected_output}")
            print(f"Actual: {actual_output}")

    print(f"{num_correct}/{total_tests}")

if __name__ == "__main__":
    test_matrix_rank_transform()