class SparseVector:
    def __init__(self, nums):
        self.nums = nums
        self.sparse_dict = {}
        for i, num in enumerate(nums):
            if num != 0:
                self.sparse_dict[i] = num

    def dotProduct(self, vec):
        result = 0
        if isinstance(vec, SparseVector):
            for i, num in self.sparse_dict.items():
                if i in vec.sparse_dict:
                    result += num * vec.sparse_dict[i]
        else:
            for i, num in self.sparse_dict.items():
                result += num * vec.nums[i]
        return result

def test_sparse_vector():
    test_cases = [
        ([1,0,0,2,3], [0,3,0,4,0], 8),
        ([0,1,0,0,0], [0,0,0,0,2], 0),
        ([0,1,0,0,2,0,0], [1,0,0,0,3,0,4], 6),
        ([1,2,3], [4,5,6], 32),
        ([0,0,0], [0,0,0], 0),
        ([1], [1], 1),
        ([100,0,0], [0,100,0], 0),
        ([1,0,0,0,0], [0,0,0,0,1], 0)
    ]
    
    num_correct = 0
    total_tests = len(test_cases)
    
    for nums1, nums2, expected in test_cases:
        v1 = SparseVector(nums1)
        v2 = SparseVector(nums2)
        actual = v1.dotProduct(v2)
        
        if actual == expected:
            print("True")
            num_correct += 1
        else:
            print("False")
            print(f"  Input: nums1={nums1}, nums2={nums2}")
            print(f"  Expected: {expected}, Actual: {actual}")

    print(f"{num_correct}/{total_tests}")

if __name__ == "__main__":
    test_sparse_vector()