def num_distinct_islands2(grid):
    if not grid or not grid[0]:
        return 0

    rows, cols = len(grid), len(grid[0])
    islands = set()

    def dfs(i, j, path):
        if i < 0 or i >= rows or j < 0 or j >= cols or grid[i][j] == 0:
            return
        
        grid[i][j] = 0  # Mark as visited
        path.append((i, j))
        
        dfs(i + 1, j, path)
        dfs(i - 1, j, path)
        dfs(i, j + 1, path)
        dfs(i, j - 1, path)
    
    def normalize(island):
        min_row = min(r for r, c in island)
        min_col = min(c for r, c in island)
        return tuple(sorted((r - min_row, c - min_col) for r, c in island))

    def rotate(island):
        return tuple(sorted((c, -r) for r, c in island))

    def reflect_horizontal(island):
        return tuple(sorted((r, -c) for r, c in island))
    
    def reflect_vertical(island):
         return tuple(sorted((-r, c) for r, c in island))

    def get_transforms(island):
        normalized_island = normalize(island)
        transforms = set()
        transforms.add(normalized_island)
        
        rotated = normalized_island
        for _ in range(3):
            rotated = normalize(rotate(rotated))
            transforms.add(rotated)
            
        reflected_h = normalize(reflect_horizontal(normalized_island))
        transforms.add(reflected_h)
        
        reflected_h_rotated = reflected_h
        for _ in range(3):
            reflected_h_rotated = normalize(rotate(reflected_h_rotated))
            transforms.add(reflected_h_rotated)
            
        reflected_v = normalize(reflect_vertical(normalized_island))
        transforms.add(reflected_v)

        reflected_v_rotated = reflected_v
        for _ in range(3):
            reflected_v_rotated = normalize(rotate(reflected_v_rotated))
            transforms.add(reflected_v_rotated)
        
        return transforms
    

    for i in range(rows):
        for j in range(cols):
            if grid[i][j] == 1:
                island_path = []
                dfs(i, j, island_path)
                transforms = get_transforms(tuple(island_path))
                islands.add(tuple(transforms))

    return len(islands)

def test_num_distinct_islands2():
    test_cases = [
        ([[1,1,0,0,0],[1,0,0,0,0],[0,0,0,0,1],[0,0,0,1,1]], 1),
        ([[1,1,1,0,0],[1,0,0,0,1],[0,1,0,0,1],[0,1,1,1,0]], 2),
        ([[1,1,0],[0,1,1],[0,0,0],[1,1,1],[0,1,0]], 2),
        ([[1,1,1],[1,0,1],[1,1,1]], 1),
        ([[1,1,0,0,0],[1,1,0,0,0],[0,0,0,1,1],[0,0,0,1,1]], 1),
        ([[1,0],[1,0]], 1),
        ([[1,1,0,1],[1,0,0,0],[0,0,1,1],[0,0,0,1]], 3),
        ([[1,1,0],[0,0,1],[0,0,1],[1,1,0]], 1),
        ([[1,1,1],[0,1,0],[1,1,1],[1,1,1],[0,1,0]],1)
    ]
    
    correct_count = 0
    total_tests = len(test_cases)
    
    for i, (grid, expected) in enumerate(test_cases):
        result = num_distinct_islands2(grid)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Expected: {expected}, Got: {result})")

    print(f"\n{correct_count}/{total_tests} correct")

if __name__ == "__main__":
    test_num_distinct_islands2()