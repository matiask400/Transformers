def missingNumber(nums):
    """
    Finds the missing number in the given array.

    Args:
      nums: A list of integers.

    Returns:
      The missing number in the range [0, n].
    """
    n = len(nums)
    expected_sum = n * (n + 1) // 2
    actual_sum = sum(nums)
    return expected_sum - actual_sum

def test_missingNumber():
    test_cases = [
        ([3, 0, 1], 2),
        ([0, 1], 2),
        ([9, 6, 4, 2, 3, 5, 7, 0, 1], 8),
        ([0], 1),
        ([1,2,3],0),
        ([0,2,3],1),
        ([0,1,3],2),
        ([0,1,2],3)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for nums, expected in test_cases:
        result = missingNumber(nums)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")

if __name__ == '__main__':
    test_missingNumber()