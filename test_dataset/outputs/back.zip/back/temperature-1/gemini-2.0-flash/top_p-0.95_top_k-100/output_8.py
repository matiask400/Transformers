def move_zeroes(nums):
    """
    Moves all 0's to the end of an array while maintaining the relative order
    of the non-zero elements.
    """
    n = len(nums)
    insert_pos = 0
    for i in range(n):
        if nums[i] != 0:
            nums[insert_pos] = nums[i]
            insert_pos += 1
    while insert_pos < n:
        nums[insert_pos] = 0
        insert_pos += 1
    return nums

def test_move_zeroes():
    """
    Tests the move_zeroes function with several test cases.
    """
    test_cases = [
        ([0, 1, 0, 3, 12], [1, 3, 12, 0, 0]),
        ([0], [0]),
        ([1, 2, 3, 4, 5], [1, 2, 3, 4, 5]),
        ([0, 0, 0, 0, 0], [0, 0, 0, 0, 0]),
        ([1, 0, 0, 0, 0], [1, 0, 0, 0, 0]),
        ([0, 0, 0, 0, 1], [1, 0, 0, 0, 0]),
        ([0, 0, 1, 0, 2], [1, 2, 0, 0, 0]),
        ([1, 0, 2, 0, 3], [1, 2, 3, 0, 0])

    ]
    
    correct_tests = 0
    total_tests = len(test_cases)
    
    for input_nums, expected_output in test_cases:
        nums_copy = input_nums[:]  # Create a copy to avoid modifying original test case
        move_zeroes(nums_copy)  # Modify nums_copy in-place
        if nums_copy == expected_output:
            print("True")
            correct_tests += 1
        else:
            print("False")
            print(f"Input: {input_nums}")
            print(f"Expected: {expected_output}")
            print(f"Got: {nums_copy}")
            
    print(f"{correct_tests}/{total_tests}")

if __name__ == "__main__":
    test_move_zeroes()