def magicalString(n):
    """
    Calculates the number of '1's in the first n elements of the magical string S.

    Args:
        n: An integer representing the number of elements to consider in S.

    Returns:
        The number of '1's in the first n elements of S.
    """
    if n == 0:
        return 0
    if n <= 3:
        count = 0
        for i in range(min(n, len("122"))):
            if "122"[i] == '1':
                count += 1
        return count
        

    s = [1, 2, 2]
    i = 2
    j = 3
    while j < n:
        if s[i] == 1:
            s.append(3 - s[-1])
            j += 1
        else:
            s.append(3 - s[-1])
            if j < n:
                s.append(3 - s[-1])
            j += 2
        i += 1

    count = 0
    for k in range(n):
        if s[k] == 1:
            count += 1
    return count


def test_magicalString():
    """
    Tests the magicalString function with several test cases.
    """
    tests = [
        (6, 3),
        (1, 1),
        (2, 1),
        (3, 1),
        (4, 2),
        (5, 2),
        (7, 4),
        (8, 4),
        (9, 4),
        (10, 5),
        (11, 5),
        (12, 6),
        (13, 6)
    ]
    
    num_correct = 0
    total_tests = len(tests)

    for i, (input_n, expected_output) in enumerate(tests):
        actual_output = magicalString(input_n)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {input_n}")
            print(f"  Expected Output: {expected_output}")
            print(f"  Actual Output: {actual_output}")

    print(f"\n{num_correct}/{total_tests} correct")


if __name__ == "__main__":
    test_magicalString()