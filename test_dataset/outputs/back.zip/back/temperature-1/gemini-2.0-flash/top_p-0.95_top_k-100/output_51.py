def solve():
    def trailingZeroes(n):
        count = 0
        i = 5
        while (n // i >= 1):
            count += n // i
            i *= 5
        return count

    def preimageSizeFaster(K):
        def count_x(k):
            low = 0
            high = 5 * (k + 1)

            while low <= high:
                mid = (low + high) // 2
                zeros = trailingZeroes(mid)
                if zeros < k:
                    low = mid + 1
                elif zeros > k:
                    high = mid - 1
                else:
                    high = mid - 1
            return low

        return count_x(K) - count_x(K - 1)

    def test_cases():
        test_data = [
            {"K": 0, "expected": 5},
            {"K": 1, "expected": 0},
            {"K": 2, "expected": 0},
            {"K": 3, "expected": 0},
            {"K": 4, "expected": 0},
            {"K": 5, "expected": 5},
            {"K": 6, "expected": 0},
            {"K": 7, "expected": 0},
            {"K": 8, "expected": 0},
            {"K": 9, "expected": 0},
            {"K": 10, "expected": 5},
            {"K": 1000000000, "expected": 0}
        ]
        
        correct_count = 0
        total_count = len(test_data)
        
        for test in test_data:
            K = test["K"]
            expected = test["expected"]
            
            result = preimageSizeFaster(K)
            
            if result == expected:
                print("True")
                correct_count += 1
            else:
                print("False")
                print(f"Input: K = {K}")
                print(f"Expected: {expected}, Got: {result}")
                
        print(f"{correct_count}/{total_count}")
    
    test_cases()

solve()