def nextGreaterElement(nums1, nums2):
    """
    Finds the next greater number for nums1's elements in nums2.

    Args:
        nums1 (list[int]): The first array (subset of nums2).
        nums2 (list[int]): The second array.

    Returns:
        list[int]: A list containing the next greater element for each element in nums1.
                   If no such element exists, -1 is returned.
    """
    result = []
    for num1 in nums1:
        found = False
        index = nums2.index(num1)
        for i in range(index + 1, len(nums2)):
            if nums2[i] > num1:
                result.append(nums2[i])
                found = True
                break
        if not found:
            result.append(-1)
    return result

def test_nextGreaterElement():
    """
    Tests the nextGreaterElement function.
    """
    test_cases = [
        (([4, 1, 2], [1, 3, 4, 2]), [-1, 3, -1]),
        (([2, 4], [1, 2, 3, 4]), [3, -1]),
        (([1, 3, 5, 2, 4], [6, 5, 4, 3, 2, 1, 7]), [7, 7, 7, 7, 7]),
        (([1, 3, 5, 2, 4], [5, 4, 3, 2, 1]), [-1, -1, -1, -1, -1]),
        (([1,2,3,4,5], [5,4,3,2,1]), [-1,-1,-1,-1,-1])

    ]
    correct_count = 0
    total_count = len(test_cases)

    for i, (input_arrays, expected_output) in enumerate(test_cases):
        nums1, nums2 = input_arrays
        actual_output = nextGreaterElement(nums1, nums2)
        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: nums1={nums1}, nums2={nums2}")
            print(f"  Expected Output: {expected_output}")
            print(f"  Actual Output:   {actual_output}")
    
    print(f"\nCorrect Tests: {correct_count}/{total_count}")

if __name__ == "__main__":
    test_nextGreaterElement()