def xorGame(nums):
    """
    Alice and Bob take turns erasing exactly one number from the chalkboard, with Alice starting first.
    If erasing a number causes the bitwise XOR of all the elements of the chalkboard to become 0, then that player loses.
    (Also, we'll say the bitwise XOR of one element is that element itself, and the bitwise XOR of no elements is 0.)
    Also, if any player starts their turn with the bitwise XOR of all the elements of the chalkboard equal to 0, then that player wins.
    Return True if and only if Alice wins the game, assuming both players play optimally.
    """
    xor_sum = 0
    for num in nums:
        xor_sum ^= num

    if xor_sum == 0:
        return True
    
    if len(nums) % 2 == 0:
        return True
    else:
        return False

def test_xorGame():
    tests = [
        ([1, 1, 2], False),
        ([0], True),
        ([1, 2, 3], True),
        ([1, 2], False),
        ([0, 1, 2, 3], True),
        ([0, 1, 2], False),
        ([5, 2, 4, 5, 1, 0, 1, 6, 0, 4], False),
        ([285,910,952,889,997,232,983,871,20,222,273,640,25,163,747,212,139,119,184,615,670,68,907,726,313,365,132,953,832,321,73,518,108,897,833,108,316,239,674,15,519,408,858,356,331,257,116,701,593,230,842,275,865,597,283,667,650,822,216,941,759,11,238,415,808,476,455,173,778,539,667,407,231,105,341,458,322,525,908,628,526,713,620,355,21,52,603,873,839,741,382,15,777,103,650,229,840,659,724,533,643,840], True)

    ]
    
    correct_count = 0
    for i, (nums, expected) in enumerate(tests):
        result = xorGame(nums)
        if result == expected:
            print(True)
            correct_count += 1
        else:
            print(False)
    print(f"{correct_count}/{len(tests)}")

test_xorGame()