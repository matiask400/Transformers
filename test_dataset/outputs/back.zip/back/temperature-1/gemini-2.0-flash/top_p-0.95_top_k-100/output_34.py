def least_operators(x, target):
    """
    Finds the least number of operators needed to reach the target value.

    Args:
        x: The single positive integer to use in the expression.
        target: The target value to reach.

    Returns:
        The least number of operators used.
    """

    def solve(current, count):
        """
        Recursive helper function to explore possible expressions.

        Args:
            current: The current value of the expression.
            count: The number of operators used so far.

        Returns:
            The minimum number of operators needed to reach the target,
            or float('inf') if it's not possible.
        """
        if abs(current - target) < 1e-6:  # Use a small tolerance for floating-point comparison
            return count

        if count > 10:
            return float('inf')

        add = solve(current + x, count + 1)
        subtract = solve(current - x, count + 1)
        multiply = solve(current * x, count + 1)
        divide = solve(current / x, count + 1)

        return min(add, subtract, multiply, divide)

    if x == target:
        return 0

    result = solve(x, 0)
    return result if result != float('inf') else -1

def test_least_operators():
    """
    Tests the least_operators function with several test cases.
    """

    test_cases = [
        {"x": 3, "target": 19, "expected": 5},
        {"x": 5, "target": 501, "expected": 8},
        {"x": 100, "target": 100000000, "expected": 3},
        {"x": 2, "target": 5, "expected": 2},
        {"x": 7, "target": 49, "expected": 1},
        {"x": 2, "target": 2, "expected": 0},
        {"x": 3, "target": 9, "expected": 1},
        {"x": 4, "target": 1, "expected": 1},
        {"x": 6, "target": 36, "expected": 1},
        {"x": 10, "target": 1000, "expected": 2}
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        x = test_case["x"]
        target = test_case["target"]
        expected = test_case["expected"]
        actual = least_operators(x, target)

        if actual == expected:
            print(f"Test case {i+1}: True")
            num_correct += 1
        else:
            print(f"Test case {i+1}: False (Expected: {expected}, Actual: {actual})")

    print(f"\nCorrect: {num_correct} / {total_tests}")

if __name__ == "__main__":
    test_least_operators()