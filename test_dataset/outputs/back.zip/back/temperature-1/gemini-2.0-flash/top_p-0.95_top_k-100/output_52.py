class WordFilter:

    def __init__(self, words):
        self.words = words
        self.word_dict = {}
        for i, word in enumerate(words):
            self.word_dict[word] = i

    def f(self, prefix, suffix):
        result = -1
        for word, index in self.word_dict.items():
            if word.startswith(prefix) and word.endswith(suffix):
                result = max(result, index)
        return result


def test_word_filter():
    test_cases = [
        {
            "words": ["apple"],
            "operations": [("f", "a", "e")],
            "expected": [0],
        },
        {
            "words": ["apple", "banana", "app"],
            "operations": [("f", "a", "e"), ("f", "ban", "a"), ("f", "ap", "p")],
            "expected": [0, 1, 2],
        },
        {
            "words": ["apple", "banana", "app"],
            "operations": [("f", "x", "e"), ("f", "ban", "b"), ("f", "ap", "x")],
            "expected": [-1, -1, -1],
        },
        {
            "words": ["apple", "application"],
            "operations": [("f", "app", "e"), ("f", "app", "ion"), ("f", "a", "n")],
            "expected": [0, 1, 1],
        },
    ]

    num_tests = len(test_cases)
    num_correct = 0

    for i, test_case in enumerate(test_cases):
        words = test_case["words"]
        operations = test_case["operations"]
        expected = test_case["expected"]

        word_filter = WordFilter(words)
        results = []

        for operation in operations:
            op_type, prefix, suffix = operation
            if op_type == "f":
                results.append(word_filter.f(prefix, suffix))

        if results == expected:
            print("True")
            num_correct += 1
        else:
            print("False")
            print(f"Test case {i + 1} failed:")
            print(f"  Input words: {words}")
            print(f"  Operations: {operations}")
            print(f"  Expected: {expected}")
            print(f"  Got: {results}")

    print(f"{num_correct}/{num_tests}")

if __name__ == "__main__":
    test_word_filter()