def solve():
    def subarray_sum(nums, n, left, right):
        subarray_sums = []
        for i in range(n):
            current_sum = 0
            for j in range(i, n):
                current_sum += nums[j]
                subarray_sums.append(current_sum)
        subarray_sums.sort()
        total_sum = 0
        for i in range(left - 1, right):
            total_sum = (total_sum + subarray_sums[i]) % (10**9 + 7)
        return total_sum

    # Test cases
    test_cases = [
        ([1, 2, 3, 4], 4, 1, 5, 13),
        ([1, 2, 3, 4], 4, 3, 4, 6),
        ([1, 2, 3, 4], 4, 1, 10, 50),
        ([4,5,6], 3, 1, 5, 29),
        ([4,5,6], 3, 3, 7, 36)
    ]

    num_correct = 0
    for i, (nums, n, left, right, expected) in enumerate(test_cases):
        actual = subarray_sum(nums, n, left, right)
        if actual == expected:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")
            print(f"Test case {i+1}: Expected {expected}, but got {actual}")

    print(f"{num_correct}/{len(test_cases)}")

solve()