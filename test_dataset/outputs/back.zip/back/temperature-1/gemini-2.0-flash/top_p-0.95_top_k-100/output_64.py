def max_profit(prices):
    """
    Calculates the maximum profit that can be achieved by buying and selling stocks.

    Args:
        prices: A list of integers representing the stock prices on different days.

    Returns:
        The maximum profit that can be achieved.
    """
    max_profit = 0
    for i in range(1, len(prices)):
        if prices[i] > prices[i - 1]:
            max_profit += prices[i] - prices[i - 1]
    return max_profit

def test_max_profit():
    """
    Tests the max_profit function with several test cases.
    """
    test_cases = [
        ([7, 1, 5, 3, 6, 4], 7),
        ([1, 2, 3, 4, 5], 4),
        ([7, 6, 4, 3, 1], 0),
        ([2, 1, 2, 0, 1], 2),
        ([5, 2, 3, 2, 6, 6, 2, 9, 1, 0, 7, 4, 2], 14),
        ([1], 0),
        ([], 0),
    ]
    
    num_correct = 0
    total_tests = len(test_cases)

    for i, (prices, expected_profit) in enumerate(test_cases):
        actual_profit = max_profit(prices)
        if actual_profit == expected_profit:
            print("True")
            num_correct += 1
        else:
            print("False")
            print(f"Test Case {i+1}:")
            print(f"Input: {prices}")
            print(f"Expected Output: {expected_profit}")
            print(f"Actual Output: {actual_profit}")

    print(f"{num_correct}/{total_tests}")
    
if __name__ == "__main__":
    test_max_profit()