def pacific_atlantic(heights):
    """
    Finds grid coordinates where water can flow to both the Pacific and Atlantic oceans.

    Args:
        heights: An m x n integer matrix representing the height of each unit cell.

    Returns:
        A list of grid coordinates where water can flow to both the Pacific and Atlantic oceans.
    """

    if not heights:
        return []

    m, n = len(heights), len(heights[0])

    def can_reach(ocean):
        reachable = set()

        def dfs(i, j):
            if (i, j) in reachable:
                return
            reachable.add((i, j))

            directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
            for dx, dy in directions:
                x, y = i + dx, j + dy
                if 0 <= x < m and 0 <= y < n and heights[x][y] >= heights[i][j]:
                    dfs(x, y)

        if ocean == "pacific":
            for i in range(m):
                dfs(i, 0)
            for j in range(n):
                dfs(0, j)
        else:  # ocean == "atlantic"
            for i in range(m):
                dfs(i, n - 1)
            for j in range(n):
                dfs(m - 1, j)

        return reachable

    pacific_reachable = can_reach("pacific")
    atlantic_reachable = can_reach("atlantic")

    return list(pacific_reachable.intersection(atlantic_reachable))


def test_pacific_atlantic():
    test_cases = [
        {
            "heights": [[1, 2, 2, 3, 5], [3, 2, 3, 4, 4], [2, 4, 5, 3, 1], [6, 7, 1, 4, 5], [5, 1, 1, 2, 4]],
            "expected": [[0, 4], [1, 3], [1, 4], [2, 2], [3, 0], [3, 1], [4, 0]]
        },
        {
            "heights": [[2, 1], [1, 2]],
            "expected": [[0, 0], [0, 1], [1, 0], [1, 1]]
        },
        {
            "heights": [[1]],
            "expected": [[0, 0]]
        },
        {
            "heights": [[1, 2], [3, 4]],
            "expected": [[0, 1], [1, 0], [1, 1]]
        },
        {
            "heights": [[1, 2, 3], [8, 9, 4], [7, 6, 5]],
            "expected": [[0, 2], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]]
        }
    ]

    num_correct = 0
    for i, test_case in enumerate(test_cases):
        heights = test_case["heights"]
        expected = sorted(test_case["expected"])
        actual = sorted(pacific_atlantic(heights))

        if actual == expected:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")
            print(f"Test case {i + 1} failed:")
            print(f"  Input: {heights}")
            print(f"  Expected: {expected}")
            print(f"  Actual: {actual}")

    print(f"{num_correct}/{len(test_cases)}")


if __name__ == '__main__':
    test_pacific_atlantic()