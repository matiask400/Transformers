def count_distinct_subsequences(S):
    n = len(S)
    MOD = 10**9 + 7
    dp = [0] * (n + 1)
    dp[0] = 1
    last = {}
    for i in range(1, n + 1):
        dp[i] = (2 * dp[i - 1]) % MOD
        if S[i - 1] in last:
            dp[i] = (dp[i] - dp[last[S[i - 1]] - 1]) % MOD
        last[S[i - 1]] = i
    return (dp[n] - 1) % MOD

def test_count_distinct_subsequences():
    test_cases = [
        ("abc", 7),
        ("aba", 6),
        ("aaa", 3),
        ("abcd", 15),
        ("aaaaa", 5),
        ("abab", 10),
        ("", 0) 
    ]
    
    num_correct = 0
    total_tests = len(test_cases)
    
    for input_str, expected_output in test_cases:
        actual_output = count_distinct_subsequences(input_str)
        if actual_output == expected_output:
            print("True")
            num_correct += 1
        else:
            print("False")
    
    print(f"{num_correct}/{total_tests}")
    
test_count_distinct_subsequences()