def shortest_subarray_to_remove(arr):
    """
    Given an integer array `arr`, remove a subarray (can be empty) from `arr`
    such that the remaining elements in `arr` are non-decreasing.
    A subarray is a contiguous subsequence of the array.
    Return the length of the shortest subarray to remove.

    Example 1:
    Input: arr = [1,2,3,10,4,2,3,5]
    Output: 3
    Explanation: The shortest subarray we can remove is [10,4,2] of length 3.
    The remaining elements after that will be [1,2,3,3,5] which are sorted.
    Another correct solution is to remove the subarray [3,10,4].

    Example 2:
    Input: arr = [5,4,3,2,1]
    Output: 4
    Explanation: Since the array is strictly decreasing, we can only keep a
    single element. Therefore we need to remove a subarray of length 4, either
    [5,4,3,2] or [4,3,2,1].

    Example 3:
    Input: arr = [1,2,3]
    Output: 0
    Explanation: The array is already non-decreasing. We do not need to remove
    any elements.

    Example 4:
    Input: arr = [1]
    Output: 0

    Constraints:
    `1 <= arr.length <= 10^5`
    `0 <= arr[i] <= 10^9`
    """
    n = len(arr)
    if n <= 1:
        return 0

    l, r = 0, n - 1
    while l < n - 1 and arr[l] <= arr[l + 1]:
        l += 1
    if l == n - 1:
        return 0

    while r > 0 and arr[r] >= arr[r - 1]:
        r -= 1

    ans = min(n - l - 1, r)
    i, j = 0, r
    while i <= l and j < n:
        if arr[i] <= arr[j]:
            ans = min(ans, j - i - 1)
            i += 1
        else:
            j += 1
    return ans

def test_shortest_subarray_to_remove():
    test_cases = [
        ([1, 2, 3, 10, 4, 2, 3, 5], 3),
        ([5, 4, 3, 2, 1], 4),
        ([1, 2, 3], 0),
        ([1], 0),
        ([2,2,2,1,2,2,2], 1),
        ([1, 3, 5, 2, 4, 6], 2),
        ([3,2,1], 2),
        ([6,3,5,7,9,10,11], 2),
        ([2,1],1)
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for arr, expected in test_cases:
        result = shortest_subarray_to_remove(arr)
        if result == expected:
            print("True")
            num_correct += 1
        else:
            print("False")
            print(f"Input: {arr}")
            print(f"Expected: {expected}, Got: {result}")

    print(f"{num_correct}/{total_tests}")

if __name__ == "__main__":
    test_shortest_subarray_to_remove()