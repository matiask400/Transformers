def num_jewels_in_stones(jewels, stones):
    """
    You're given strings jewels representing the types of stones that are jewels,
    and stones representing the stones you have. Each character in stones is a
    type of stone you have. You want to know how many of the stones you have
    are also jewels.

    Letters are case sensitive, so "a" is considered a different type of
    stone from "A".

    Example 1:
    Input: jewels = "aA", stones = "aAAbbbb"
    Output: 3

    Example 2:
    Input: jewels = "z", stones = "ZZ"
    Output: 0

    Constraints:
    1 <= jewels.length, stones.length <= 50
    jewels and stones consist of only English letters.
    All the characters of jewels are unique.
    """
    jewels_set = set(jewels)
    count = 0
    for stone in stones:
        if stone in jewels_set:
            count += 1
    return count

def test_num_jewels_in_stones():
    test_cases = [
        {"jewels": "aA", "stones": "aAAbbbb", "expected": 3},
        {"jewels": "z", "stones": "ZZ", "expected": 0},
        {"jewels": "abc", "stones": "def", "expected": 0},
        {"jewels": "AB", "stones": "ABC", "expected": 2},
        {"jewels": "Aa", "stones": "Aa", "expected": 2},
        {"jewels": "", "stones": "stones", "expected": 0},
        {"jewels": "jewels", "stones": "", "expected": 0},
        {"jewels": "a", "stones": "a", "expected": 1},
        {"jewels": "A", "stones": "a", "expected": 0},
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        jewels = test_case["jewels"]
        stones = test_case["stones"]
        expected = test_case["expected"]
        actual = num_jewels_in_stones(jewels, stones)
        if actual == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: jewels='{jewels}', stones='{stones}'")
            print(f"  Expected: {expected}, Actual: {actual}")

    print(f"\nCorrect: {correct_count} / {total_tests}")

if __name__ == "__main__":
    test_num_jewels_in_stones()