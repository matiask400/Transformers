class TreeNode:
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

def distanceK(root, target, K):
    """
    Finds all nodes that are a distance K from the target node in a binary tree.

    Args:
        root (TreeNode): The root node of the binary tree.
        target (TreeNode): The target node in the binary tree.
        K (int): The distance from the target node.

    Returns:
        list[int]: A list of the values of all nodes that have a distance K from the target node.
    """

    adj = {}

    def build_graph(node, parent):
        if node:
            if node.val not in adj:
                adj[node.val] = []
            if parent is not None:
                adj[node.val].append(parent.val)
                if parent.val not in adj:
                    adj[parent.val] = []
                adj[parent.val].append(node.val)
            build_graph(node.left, node)
            build_graph(node.right, node)

    build_graph(root, None)

    q = [(target.val, 0)]
    visited = {target.val}
    result = []

    while q:
        node, dist = q.pop(0)
        if dist == K:
            result.append(node)
        else:
            if node in adj:
                for neighbor in adj[node]:
                    if neighbor not in visited:
                        visited.add(neighbor)
                        q.append((neighbor, dist + 1))

    return result

def test_distanceK():
    """
    Tests the distanceK function with various test cases.
    """

    def build_tree(nodes):
        if not nodes:
            return None
        
        root = TreeNode(nodes[0])
        q = [root]
        i = 1
        
        while q and i < len(nodes):
            node = q.pop(0)
            
            if i < len(nodes) and nodes[i] is not None:
                node.left = TreeNode(nodes[i])
                q.append(node.left)
            i += 1
            
            if i < len(nodes) and nodes[i] is not None:
                node.right = TreeNode(nodes[i])
                q.append(node.right)
            i += 1
            
        return root
    
    def find_node(root, target_val):
        if not root:
            return None
        
        if root.val == target_val:
            return root
        
        left_result = find_node(root.left, target_val)
        if left_result:
            return left_result
        
        return find_node(root.right, target_val)

    test_cases = [
        {
            "root": [3, 5, 1, 6, 2, 0, 8, None, None, 7, 4],
            "target": 5,
            "K": 2,
            "expected": [7, 4, 1],
        },
        {
            "root": [0, 2, 1, None, None, 3],
            "target": 3,
            "K": 3,
            "expected": [0],
        },
        {
            "root": [1,2,3,4,5,None,None,None,None,6,7,None,8,None,9],
            "target": 2,
            "K": 2,
            "expected": [6, 7, 3],
        },
        {
             "root": [0,1,None,2,None,3,4],
             "target": 3,
             "K": 0,
             "expected": [3]
        },
        {
            "root": [1, 0, 2],
            "target": 0,
            "K": 1,
            "expected": [1, 2],
        }
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        root_nodes = test_case["root"]
        target_val = test_case["target"]
        K = test_case["K"]
        expected = test_case["expected"]

        root = build_tree(root_nodes)
        target = find_node(root, target_val)

        result = distanceK(root, target, K)
        result.sort()
        expected.sort()

        if result == expected:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")

    print(f"{num_correct}/{total_tests}")

test_distanceK()