def max_average_subarray(nums, k):
    """
    Finds the contiguous subarray of given length k that has the maximum average value.

    Args:
        nums: A list of integers.
        k: The length of the subarray.

    Returns:
        The maximum average value.
    """

    n = len(nums)
    if n < k or k <= 0:
        return 0.0

    current_sum = sum(nums[:k])
    max_sum = current_sum

    for i in range(k, n):
        current_sum = current_sum + nums[i] - nums[i - k]
        max_sum = max(max_sum, current_sum)

    return max_sum / k

def test_max_average_subarray():
    test_cases = [
        ([1, 12, -5, -6, 50, 3], 4, 12.75),
        ([4,2,1,3,3], 2, 3.0),
        ([1,1,1,1], 2, 1.0),
        ([-1,-1,-1,-1], 2, -1.0),
        ([0,0,0,0], 2, 0.0),
        ([5], 1, 5.0),
        ([-5], 1, -5.0),
        ([1,2,3,4,5], 5, 3.0),
        ([5,4,3,2,1], 5, 3.0),
        ([1,12,-5,-6,50,3], 1, 50.0),
        ([1,12,-5,-6,50,3], 6, 9.166666666666666)
    ]

    num_correct = 0
    for i, (nums, k, expected) in enumerate(test_cases):
        actual = max_average_subarray(nums, k)
        if abs(actual - expected) < 1e-6:
            print("True")
            num_correct += 1
        else:
            print("False")
            print(f"Test case {i+1}: Input: {nums}, {k}. Expected: {expected}, Actual: {actual}")

    print(f"{num_correct}/{len(test_cases)}")


if __name__ == "__main__":
    test_max_average_subarray()