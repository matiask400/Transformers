def is_k_palindrome(s: str, k: int) -> bool:
    """
    Given a string `s` and an integer `k`, return `true` if `s` is a `k`-palindrome.

    A string is `k`-palindrome if it can be transformed into a palindrome by removing at most `k` characters from it.
    """
    n = len(s)
    dp = [[0] * (n + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        for j in range(1, n + 1):
            if s[i - 1] == s[n - j]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])

    longest_palindrome_subsequence_length = dp[n][n]
    return n - longest_palindrome_subsequence_length <= k

def test_is_k_palindrome():
    test_cases = [
        ("abcdeca", 2, True),
        ("abbababa", 1, True),
        ("abdefghba", 0, False),
        ("abdefghba", 1, False),
        ("abdefghba", 2, False),
        ("abdefghba", 3, True),
        ("a", 0, True),
        ("a", 1, True),
        ("ab", 0, False),
        ("ab", 1, True),
        ("ab", 2, True),
        ("racecar", 0, True),
        ("racecar", 1, True),
        ("racecar", 2, True)

    ]
    
    correct_count = 0
    total_count = len(test_cases)

    for s, k, expected in test_cases:
        result = is_k_palindrome(s, k)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")
            
    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_is_k_palindrome()