def solve():
    def get_maximum_generated(n):
        if n == 0:
            return 0
        nums = [0] * (n + 1)
        nums[0] = 0
        nums[1] = 1
        max_num = 1
        for i in range(1, (n // 2) + 1):
            if 2 * i <= n:
                nums[2 * i] = nums[i]
                max_num = max(max_num, nums[2 * i])
            if 2 * i + 1 <= n:
                nums[2 * i + 1] = nums[i] + nums[i + 1]
                max_num = max(max_num, nums[2 * i + 1])
        return max_num

    test_cases = [
        (7, 3),
        (2, 1),
        (3, 2),
        (0, 0),
        (1, 1),
        (4, 2),
        (5, 3)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (n, expected) in enumerate(test_cases):
        result = get_maximum_generated(n)
        if result == expected:
            print(True)
            correct_count += 1
        else:
            print(False)
    
    print(f"{correct_count}/{total_count}")

solve()