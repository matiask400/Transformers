def possible_bipartition(N, dislikes):
    """
    Determines if it's possible to split N people into two groups such that no two disliked people are in the same group.

    Args:
        N: The number of people.
        dislikes: A list of dislike relationships, where dislikes[i] = [a, b] means person a dislikes person b.

    Returns:
        True if it's possible to split the people into two groups, False otherwise.
    """

    graph = [[] for _ in range(N)]
    for u, v in dislikes:
        graph[u - 1].append(v - 1)
        graph[v - 1].append(u - 1)

    color = [-1] * N  # -1: uncolored, 0: group 1, 1: group 2

    def dfs(node, c):
        color[node] = c
        for neighbor in graph[node]:
            if color[neighbor] == -1:
                if not dfs(neighbor, 1 - c):
                    return False
            elif color[neighbor] == c:
                return False
        return True

    for i in range(N):
        if color[i] == -1:
            if not dfs(i, 0):
                return False

    return True


def test_possible_bipartition():
    test_cases = [
        {"N": 4, "dislikes": [[1, 2], [1, 3], [2, 4]], "expected": True},
        {"N": 3, "dislikes": [[1, 2], [1, 3], [2, 3]], "expected": False},
        {"N": 5, "dislikes": [[1, 2], [2, 3], [3, 4], [4, 5], [1, 5]], "expected": False},
        {"N": 1, "dislikes": [], "expected": True},
        {"N": 2, "dislikes": [], "expected": True},
        {"N": 2, "dislikes": [[1, 2]], "expected": True},
        {"N": 5, "dislikes": [[1, 2], [3, 4]], "expected": True},
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        N = test_case["N"]
        dislikes = test_case["dislikes"]
        expected = test_case["expected"]

        result = possible_bipartition(N, dislikes)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_tests}")


if __name__ == "__main__":
    test_possible_bipartition()