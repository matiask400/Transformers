def solve():
    def solve_board(board):
        if not board:
            return board

        m, n = len(board), len(board[0])

        def dfs(i, j):
            if i < 0 or i >= m or j < 0 or j >= n or board[i][j] != 'O':
                return
            board[i][j] = 'T'  # Temporarily mark as 'T'
            dfs(i + 1, j)
            dfs(i - 1, j)
            dfs(i, j + 1)
            dfs(i, j - 1)

        # Mark 'O's connected to the border as 'T'
        for i in range(m):
            if board[i][0] == 'O':
                dfs(i, 0)
            if board[i][n - 1] == 'O':
                dfs(i, n - 1)
        for j in range(n):
            if board[0][j] == 'O':
                dfs(0, j)
            if board[m - 1][j] == 'O':
                dfs(m - 1, j)

        # Flip remaining 'O's to 'X' and restore 'T's to 'O's
        for i in range(m):
            for j in range(n):
                if board[i][j] == 'O':
                    board[i][j] = 'X'
                elif board[i][j] == 'T':
                    board[i][j] = 'O'

        return board

    test_cases = [
        {
            "input": [["X","X","X","X"],["X","O","O","X"],["X","X","O","X"],["X","O","X","X"]],
            "expected": [["X","X","X","X"],["X","X","X","X"],["X","X","X","X"],["X","O","X","X"]]
        },
        {
            "input": [["X"]],
            "expected": [["X"]]
        },
        {
            "input": [["O"]],
            "expected": [["O"]]
        },
        {
            "input": [["O","O"],["O","O"]],
            "expected": [["O","O"],["O","O"]]
        },
        {
            "input": [["X","O","X","O","X","O"],["O","X","O","X","O","X"],["X","O","X","O","X","O"],["O","X","O","X","O","X"]],
            "expected": [["X","O","X","O","X","O"],["O","X","O","X","O","X"],["X","O","X","O","X","O"],["O","X","O","X","O","X"]]
        }
    ]

    num_correct = 0
    for i, test_case in enumerate(test_cases):
        board = [row[:] for row in test_case["input"]]
        result = solve_board(board)
        expected = test_case["expected"]

        if result == expected:
            print("True")
            num_correct += 1
        else:
            print("False")
            print(f"Test case {i+1} failed:")
            print("Input:", test_case["input"])
            print("Expected:", expected)
            print("Got:", result)
    print(f"{num_correct}/{len(test_cases)}")

solve()