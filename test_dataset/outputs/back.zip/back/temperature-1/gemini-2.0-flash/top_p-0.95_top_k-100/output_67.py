def is_palindrome(x: int) -> bool:
    """
    Given an integer `x`, return `true` if `x` is a palindrome integer.

    An integer is a palindrome when it reads the same backward as forward. For example, `121` is palindrome while `123` is not.
    """
    if x < 0:
        return False
    
    original_number = x
    reversed_number = 0
    
    while x > 0:
        digit = x % 10
        reversed_number = reversed_number * 10 + digit
        x //= 10
        
    return original_number == reversed_number

def test_is_palindrome():
    test_cases = [
        (121, True),
        (-121, False),
        (10, False),
        (-101, False),
        (0, True),
        (1, True),
        (11, True),
        (12321, True),
        (12345, False)
    ]
    
    correct_count = 0
    total_count = len(test_cases)
    
    for input_x, expected_output in test_cases:
        actual_output = is_palindrome(input_x)
        if actual_output == expected_output:
            print("True")
            correct_count += 1
        else:
            print("False")
            print(f"Input: {input_x}, Expected: {expected_output}, Actual: {actual_output}")
            
    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_is_palindrome()