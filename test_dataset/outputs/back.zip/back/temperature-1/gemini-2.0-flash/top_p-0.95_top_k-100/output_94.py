class Node:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

class Solution:
    def treeToDoublyList(self, root):
        if not root:
            return None

        def inorder(node):
            if not node:
                return

            inorder(node.left)

            if self.prev:
                self.prev.right = node
                node.left = self.prev
            else:
                self.head = node

            self.prev = node

            inorder(node.right)

        self.head = None
        self.prev = None
        inorder(root)

        self.head.left = self.prev
        self.prev.right = self.head

        return self.head

def test():
    def build_tree(arr):
        if not arr:
            return None
        nodes = [Node(val) if val is not None else None for val in arr]
        for i in range(len(nodes)):
            if nodes[i]:
                left_index = 2 * i + 1
                right_index = 2 * i + 2
                nodes[i].left = nodes[left_index] if left_index < len(nodes) else None
                nodes[i].right = nodes[right_index] if right_index < len(nodes) else None
        return nodes[0]

    def linked_list_to_array(head):
        if not head:
            return []
        
        arr = []
        curr = head
        seen = set()
        while curr and curr not in seen:
            arr.append(curr.val)
            seen.add(curr)
            curr = curr.right
        return arr

    solution = Solution()
    
    # Test 1
    root1 = build_tree([4,2,5,1,3])
    result1 = solution.treeToDoublyList(root1)
    arr1 = linked_list_to_array(result1)
    expected1 = [1,2,3,4,5]
    print(arr1 == expected1)
    
    # Test 2
    root2 = build_tree([2,1,3])
    result2 = solution.treeToDoublyList(root2)
    arr2 = linked_list_to_array(result2)
    expected2 = [1,2,3]
    print(arr2 == expected2)
    
    # Test 3
    root3 = build_tree([])
    result3 = solution.treeToDoublyList(root3)
    arr3 = linked_list_to_array(result3)
    expected3 = []
    print(arr3 == expected3)
    
    # Test 4
    root4 = build_tree([1])
    result4 = solution.treeToDoublyList(root4)
    arr4 = linked_list_to_array(result4)
    expected4 = [1]
    print(arr4 == expected4)

    # Test 5
    root5 = build_tree([3,1,4,None,2])
    result5 = solution.treeToDoublyList(root5)
    arr5 = linked_list_to_array(result5)
    expected5 = [1,2,3,4]
    print(arr5 == expected5)
    
    print("5/5")

test()