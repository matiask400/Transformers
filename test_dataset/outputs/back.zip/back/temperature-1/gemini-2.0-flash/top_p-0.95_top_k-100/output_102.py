def max_a(n):
    """
    Calculates the maximum number of 'A's that can be printed on screen with N key presses.

    Args:
        n: The number of key presses.

    Returns:
        The maximum number of 'A's that can be printed on screen.
    """
    if n <= 6:
        return n

    dp = [0] * (n + 1)
    for i in range(1, 7):
        dp[i] = i

    for i in range(7, n + 1):
        dp[i] = max(dp[i - 1] + 1, 2 * dp[i - 3], 3 * dp[i - 4], 4 * dp[i - 5])

    return dp[n]


def test_max_a():
    """
    Tests the max_a function with several test cases.
    """
    test_cases = [
        (3, 3),
        (7, 9),
        (1, 1),
        (6, 6),
        (10, 20),
        (15, 81),
        (20, 576),
        (30, 1594323),
        (50, 1132486578)
    ]

    correct_tests = 0
    total_tests = len(test_cases)

    for i, (n, expected) in enumerate(test_cases):
        result = max_a(n)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_tests += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {n}")
            print(f"  Expected: {expected}")
            print(f"  Got: {result}")

    print(f"\nCorrect tests: {correct_tests}/{total_tests}")


if __name__ == "__main__":
    test_max_a()