def largest_component_size(A):
    def find(x):
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]

    def union(x, y):
        root_x = find(x)
        root_y = find(y)
        if root_x != root_y:
            parent[root_x] = root_y
            return True
        return False

    n = len(A)
    parent = list(range(n))
    prime_map = {}

    for i, num in enumerate(A):
        d = 2
        temp = num
        while d * d <= temp:
            if temp % d == 0:
                if d in prime_map:
                    union(i, prime_map[d])
                else:
                    prime_map[d] = i
                while temp % d == 0:
                    temp //= d
            d += 1
        if temp > 1:
            if temp in prime_map:
                union(i, prime_map[temp])
            else:
                prime_map[temp] = i

    count = {}
    for i in range(n):
        root = find(i)
        if root not in count:
            count[root] = 0
        count[root] += 1

    return max(count.values()) if count else 0


def test_largest_component_size():
    test_cases = [
        ([4, 6, 15, 35], 4),
        ([20, 50, 9, 63], 2),
        ([2, 3, 6, 7, 4, 12, 21, 39], 8),
        ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 6),
        ([1],1),
        ([2,3,4],3),
        ([1,5,12,11,20], 3)
    ]

    num_correct = 0
    for i, (input_arr, expected_output) in enumerate(test_cases):
        actual_output = largest_component_size(input_arr)
        if actual_output == expected_output:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")

    print(f"{num_correct}/{len(test_cases)}")

if __name__ == "__main__":
    test_largest_component_size()