def subarray_sum_equals_k(nums, k):
    """
    Given an array of integers `nums` and an integer `k`, return the total number of continuous subarrays whose sum equals to `k`.

    Example 1:
    Input: nums = [1,1,1], k = 2
    Output: 2

    Example 2:
    Input: nums = [1,2,3], k = 3
    Output: 2

    Constraints:
    `1 <= nums.length <= 2 * 104`
    `-1000 <= nums[i] <= 1000`
    `-107 <= k <= 107`
    """
    count = 0
    prefix_sum = {0: 1}
    current_sum = 0
    for num in nums:
        current_sum += num
        if current_sum - k in prefix_sum:
            count += prefix_sum[current_sum - k]
        if current_sum in prefix_sum:
            prefix_sum[current_sum] += 1
        else:
            prefix_sum[current_sum] = 1
    return count


def test_subarray_sum_equals_k():
    tests = [
        ([1, 1, 1], 2, 2),
        ([1, 2, 3], 3, 2),
        ([1], 0, 0),
        ([1, -1, 0], 0, 3),
        ([0, 0, 0, 0, 0], 0, 15),
        ([-1, -1, 1], 0, 1),
        ([1, 2, 1, 2, 1], 3, 4),
        ([28,54,7,-70,22,65,-6], 100, 0),
        ([-3,-1,-1,1,3], 0, 3),
        ([-1,1,0,-1,1], 0, 5)
    ]
    
    correct_count = 0
    total_count = len(tests)

    for nums, k, expected in tests:
        result = subarray_sum_equals_k(nums, k)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_subarray_sum_equals_k()