def reorder_logs(logs):
    letter_logs = []
    digit_logs = []
    for log in logs:
        parts = log.split()
        if parts[1].isdigit():
            digit_logs.append(log)
        else:
            letter_logs.append(log)

    letter_logs.sort(key=lambda x: (x.split(maxsplit=1)[1], x.split()[0]))
    return letter_logs + digit_logs


def test_reorder_logs():
    test_cases = [
        {
            "input": ["dig1 8 1 5 1", "let1 art can", "dig2 3 6", "let2 own kit dig", "let3 art zero"],
            "expected": ["let1 art can", "let3 art zero", "let2 own kit dig", "dig1 8 1 5 1", "dig2 3 6"]
        },
        {
            "input": ["a1 9 2 3 1", "g1 act car", "zo4 4 7", "ab1 off key dog", "a8 act zoo"],
            "expected": ["g1 act car", "a8 act zoo", "ab1 off key dog", "a1 9 2 3 1", "zo4 4 7"]
        },
        {
            "input": ["jly 8 9 5 2", "lyr1 9 6 0 8", "ktm act car"],
            "expected": ["ktm act car", "jly 8 9 5 2", "lyr1 9 6 0 8"]
        },
        {
            "input": ["g1 act car", "a8 act zoo", "ab1 off key dog"],
            "expected": ["g1 act car", "a8 act zoo", "ab1 off key dog"]
        },
        {
            "input": ["dig1 8 1 5 1", "dig2 3 6"],
            "expected": ["dig1 8 1 5 1", "dig2 3 6"]
        },
        {
            "input": ["let1 art can", "let2 own kit dig"],
            "expected": ["let1 art can", "let2 own kit dig"]
        },
        {
            "input": [],
            "expected": []
        }
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        input_logs = test_case["input"]
        expected_output = test_case["expected"]
        actual_output = reorder_logs(input_logs)

        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {input_logs}")
            print(f"  Expected: {expected_output}")
            print(f"  Actual: {actual_output}")

    print(f"\nCorrect: {num_correct}/{total_tests}")


if __name__ == "__main__":
    test_reorder_logs()