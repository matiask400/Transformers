def numMagicSquaresInside(grid):
    rows = len(grid)
    cols = len(grid[0]) if rows > 0 else 0
    count = 0

    def isMagicSquare(subgrid):
        nums = set()
        for i in range(3):
            for j in range(3):
                num = subgrid[i][j]
                if num < 1 or num > 9 or num in nums:
                    return False
                nums.add(num)

        magic_sum = sum(subgrid[0])

        for i in range(3):
            if sum(subgrid[i]) != magic_sum:
                return False

        for j in range(3):
            col_sum = 0
            for i in range(3):
                col_sum += subgrid[i][j]
            if col_sum != magic_sum:
                return False

        diag1_sum = 0
        for i in range(3):
            diag1_sum += subgrid[i][i]
        if diag1_sum != magic_sum:
            return False

        diag2_sum = 0
        for i in range(3):
            diag2_sum += subgrid[i][2 - i]
        if diag2_sum != magic_sum:
            return False

        return True

    if rows < 3 or cols < 3:
        return 0

    for r in range(rows - 2):
        for c in range(cols - 2):
            subgrid = [
                [grid[r + i][c + j] for j in range(3)]
                for i in range(3)
            ]
            if isMagicSquare(subgrid):
                count += 1

    return count

def test_numMagicSquaresInside():
    test_cases = [
        ([[4,3,8,4],[9,5,1,9],[2,7,6,2]], 1),
        ([[8]], 0),
        ([[4,4],[3,3]], 0),
        ([[4,7,8],[9,5,1],[2,3,6]], 0),
        ([[1, 8, 6], [10, 5, 0], [4, 2, 9]], 0),
        ([[2,7,6],[9,5,1],[4,3,8]], 1),
        ([[10,3,5],[1,6,11],[7,9,2]], 0),
        ([[5,5,5],[5,5,5],[5,5,5]], 0),
        ([[1,2,3],[4,5,6],[7,8,9]], 0),
        ([[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]], 0)
    ]
    
    num_correct = 0
    total_tests = len(test_cases)
    
    for i, (grid, expected) in enumerate(test_cases):
        result = numMagicSquaresInside(grid)
        if result == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {grid}")
            print(f"  Expected: {expected}")
            print(f"  Got: {result}")
            
    print(f"\n{num_correct}/{total_tests} correct")

test_numMagicSquaresInside()