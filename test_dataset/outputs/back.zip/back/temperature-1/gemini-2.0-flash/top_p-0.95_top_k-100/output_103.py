import heapq

class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def closestKValues(root, target, k):
    """
    Finds the k values in the BST that are closest to the target.

    Args:
        root: The root of the binary search tree.
        target: The target value.
        k: The number of closest values to return.

    Returns:
        A list of the k values in the BST that are closest to the target.
    """

    heap = []
    def inorder(node):
        if not node:
            return
        inorder(node.left)
        diff = abs(node.val - target)
        if len(heap) < k:
            heapq.heappush(heap, (-diff, node.val))
        elif diff < -heap[0][0]:
            heapq.heappop(heap)
            heapq.heappush(heap, (-diff, node.val))
        inorder(node.right)

    inorder(root)
    result = [val for _, val in heap]
    return result

def run_tests():
    test_cases = [
        {
            "root": TreeNode(4, TreeNode(2, TreeNode(1), TreeNode(3)), TreeNode(5)),
            "target": 3.714286,
            "k": 2,
            "expected": [4, 3],
        },
        {
            "root": TreeNode(1),
            "target": 0.000000,
            "k": 1,
            "expected": [1],
        },
        {
            "root": TreeNode(4, TreeNode(2, TreeNode(1), TreeNode(3)), TreeNode(5)),
            "target": 3,
            "k": 2,
            "expected": [2,3]
        },
        {
            "root": TreeNode(4, TreeNode(2, TreeNode(1), TreeNode(3)), TreeNode(5)),
            "target": 6,
            "k": 2,
            "expected": [4, 5]
        }

    ]

    num_correct = 0
    for i, test_case in enumerate(test_cases):
        root = test_case["root"]
        target = test_case["target"]
        k = test_case["k"]
        expected = test_case["expected"]
        actual = closestKValues(root, target, k)
        actual.sort()
        expected.sort()
        if actual == expected:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")
            print(f"Test case {i + 1} failed:")
            print(f"  Input: root={root}, target={target}, k={k}")
            print(f"  Expected: {expected}")
            print(f"  Actual: {actual}")

    print(f"{num_correct}/{len(test_cases)}")

if __name__ == "__main__":
    run_tests()