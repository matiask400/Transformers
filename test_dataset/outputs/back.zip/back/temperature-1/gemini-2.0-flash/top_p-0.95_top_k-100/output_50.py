def candy(ratings):
    n = len(ratings)
    candies = [1] * n

    # Traverse from left to right
    for i in range(1, n):
        if ratings[i] > ratings[i - 1]:
            candies[i] = candies[i - 1] + 1

    # Traverse from right to left
    for i in range(n - 2, -1, -1):
        if ratings[i] > ratings[i + 1]:
            candies[i] = max(candies[i], candies[i + 1] + 1)

    return sum(candies)

def test_candy():
    test_cases = [
        ([1, 0, 2], 5),
        ([1, 2, 2], 4),
        ([1, 2, 3, 4, 5], 15),
        ([5, 4, 3, 2, 1], 15),
        ([1, 2, 3, 4, 5, 4, 3, 2, 1], 21),
        ([1, 1, 1, 1, 1], 5),
        ([10, 2, 3, 4, 5, 6], 13),
        ([6, 5, 4, 3, 2, 10], 13),
        ([0], 1),
        ([0,1,2,3,2,1],11)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (ratings, expected) in enumerate(test_cases):
        result = candy(ratings)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Expected: {expected}, Got: {result})")

    print(f"\nCorrect: {correct_count}/{total_count}")

if __name__ == "__main__":
    test_candy()