class RangeModule:
    def __init__(self):
        self.ranges = []

    def addRange(self, left: int, right: int) -> None:
        new_ranges = []
        i = 0
        while i < len(self.ranges) and self.ranges[i][1] < left:
            new_ranges.append(self.ranges[i])
            i += 1

        new_ranges.append([left, right])

        while i < len(self.ranges):
            if self.ranges[i][0] <= right:
                new_ranges[-1][0] = min(new_ranges[-1][0], self.ranges[i][0])
                new_ranges[-1][1] = max(new_ranges[-1][1], self.ranges[i][1])
            else:
                new_ranges.append(self.ranges[i])
            i += 1

        self.ranges = []
        if len(new_ranges) > 0:
            self.ranges.append(new_ranges[0])
            for i in range(1, len(new_ranges)):
                if new_ranges[i][0] <= self.ranges[-1][1]:
                    self.ranges[-1][1] = max(self.ranges[-1][1], new_ranges[i][1])
                else:
                    self.ranges.append(new_ranges[i])


    def queryRange(self, left: int, right: int) -> bool:
        for start, end in self.ranges:
            if start <= left and right <= end:
                return True
        return False


    def removeRange(self, left: int, right: int) -> None:
        new_ranges = []
        for start, end in self.ranges:
            if end <= left or start >= right:
                new_ranges.append([start, end])
            else:
                if start < left:
                    new_ranges.append([start, left])
                if right < end:
                    new_ranges.append([right, end])
        self.ranges = new_ranges

def test_range_module():
    range_module = RangeModule()
    
    # Test Case 1
    range_module.addRange(10, 20)
    range_module.removeRange(14, 16)
    test1_1 = range_module.queryRange(10, 14)
    test1_2 = range_module.queryRange(13, 15)
    test1_3 = range_module.queryRange(16, 17)
    print(f"{test1_1 == True}")
    print(f"{test1_2 == False}")
    print(f"{test1_3 == True}")
    test_results = [test1_1 == True, test1_2 == False, test1_3 == True]
    num_correct = sum(test_results)

    # Test Case 2
    range_module = RangeModule()
    range_module.addRange(5,8)
    range_module.removeRange(3, 6)
    test2_1 = range_module.queryRange(2, 3)
    test2_2 = range_module.queryRange(2, 8)
    test2_3 = range_module.queryRange(7, 9)

    print(f"{test2_1 == False}")
    print(f"{test2_2 == False}")
    print(f"{test2_3 == True}")
    test_results2 = [test2_1 == False, test2_2 == False, test2_3 == True]
    num_correct += sum(test_results2)

    #Test Case 3
    range_module = RangeModule()
    range_module.addRange(1, 3)
    range_module.addRange(5, 7)
    range_module.addRange(10, 12)
    test3_1 = range_module.queryRange(0, 1)
    test3_2 = range_module.queryRange(1, 3)
    test3_3 = range_module.queryRange(3, 4)
    test3_4 = range_module.queryRange(4, 5)
    test3_5 = range_module.queryRange(5, 7)
    test3_6 = range_module.queryRange(7, 8)

    print(f"{test3_1 == False}")
    print(f"{test3_2 == True}")
    print(f"{test3_3 == False}")
    print(f"{test3_4 == False}")
    print(f"{test3_5 == True}")
    print(f"{test3_6 == False}")

    test_results3 = [test3_1 == False, test3_2 == True, test3_3 == False, test3_4 == False, test3_5 == True, test3_6 == False]
    num_correct += sum(test_results3)
    
    total_tests = len(test_results) + len(test_results2) + len(test_results3)
    print(f"{num_correct} / {total_tests}")


test_range_module()