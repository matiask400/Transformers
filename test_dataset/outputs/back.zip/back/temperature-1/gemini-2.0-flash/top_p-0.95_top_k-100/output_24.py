def hit_bricks(grid, hits):
    m, n = len(grid), len(grid[0])
    
    def is_valid(row, col):
        return 0 <= row < m and 0 <= col < n
    
    def dfs(row, col, visited):
        if not is_valid(row, col) or grid[row][col] == 0 or (row, col) in visited:
            return 0
        
        visited.add((row, col))
        
        count = 1
        count += dfs(row + 1, col, visited)
        count += dfs(row - 1, col, visited)
        count += dfs(row, col + 1, visited)
        count += dfs(row, col - 1, visited)
        
        return count
    
    # Mark the hits as -1 temporarily
    for row, col in hits:
        if grid[row][col] == 1:
            grid[row][col] = -1
    
    # Make the stable bricks as 1
    for col in range(n):
        if grid[0][col] == 1:
            dfs(0, col, set())
    
    result = []
    for row, col in reversed(hits):
        if grid[row][col] == -1:
            grid[row][col] = 1
            
            # Check if any bricks fall
            visited = set()
            initial_stable = 0
            if row == 0:
                initial_stable = dfs(row, col, visited)
            else:
                neighbor_stable = False
                for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                    new_row, new_col = row + dr, col + dc
                    if is_valid(new_row, new_col) and grid[new_row][new_col] == 1:
                        neighbor_stable = True
                        break
                if neighbor_stable:
                     initial_stable = dfs(row, col, visited)

            total_stable_before = 0
            for r in range(m):
                for c in range(n):
                    if grid[r][c] == 1:
                        total_stable_before +=1
            
            visited = set()
            total_stable_after = 0
            for c in range(n):
                if grid[0][c] == 1:
                    dfs(0, c, visited)
            
            for r in range(m):
                for c in range(n):
                    if grid[r][c] == 1:
                        total_stable_after +=1
            
            fallen_bricks = max(0,total_stable_after - (total_stable_before - 1))
            
            result.append(fallen_bricks)
        else:
            result.append(0)
    
    return result[::-1]
    
def test_hit_bricks():
    test_cases = [
        {
            "grid": [[1,0,0,0],[1,1,1,0]],
            "hits": [[1,0]],
            "expected": [2]
        },
        {
            "grid": [[1,0,0,0],[1,1,0,0]],
            "hits": [[1,1],[1,0]],
            "expected": [0,0]
        },
        {
          "grid": [[1,1,1],[0,1,0],[0,0,0]],
          "hits": [[0,2],[2,0],[0,1],[1,2]],
          "expected": [0,0,1,0]
        },
        {
          "grid": [[1],[1],[1],[1],[1]],
          "hits": [[3,0],[4,0],[1,0],[2,0],[0,0]],
          "expected": [1,1,1,1,0]
        },
    ]
    
    num_tests = len(test_cases)
    num_correct = 0
    
    for i, test_case in enumerate(test_cases):
        grid = [row[:] for row in test_case["grid"]]  # Create a deep copy to avoid modifying the original grid
        hits = test_case["hits"]
        expected = test_case["expected"]
        
        result = hit_bricks(grid, hits)
        
        if result == expected:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")
            print(f"Test case: {i+1}")
            print(f"Input grid: {test_case['grid']}")
            print(f"Input hits: {hits}")
            print(f"Expected: {expected}")
            print(f"Got: {result}")
            print(f"Grid after the execution: {grid}")
    
    print(f"{num_correct}/{num_tests}")

test_hit_bricks()