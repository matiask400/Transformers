import collections

class GridMaster:
    def __init__(self, grid):
        self.grid = grid
        self.row, self.col = -1, -1
        for r in range(len(grid)):
            for c in range(len(grid[0])):
                if grid[r][c] == -1:
                    self.row, self.col = r, c
                    break
            if self.row != -1:
                break

    def canMove(self, direction):
        new_row, new_col = self.row, self.col
        if direction == 'U':
            new_row -= 1
        elif direction == 'D':
            new_row += 1
        elif direction == 'L':
            new_col -= 1
        elif direction == 'R':
            new_col += 1

        if 0 <= new_row < len(self.grid) and 0 <= new_col < len(self.grid[0]) and self.grid[new_row][new_col] != 0:
            return True
        return False

    def move(self, direction):
        if self.canMove(direction):
            if direction == 'U':
                self.row -= 1
            elif direction == 'D':
                self.row += 1
            elif direction == 'L':
                self.col -= 1
            elif direction == 'R':
                self.col += 1

    def isTarget(self):
        return self.grid[self.row][self.col] == 2


def findShortestPath(grid):
    """
    :type master: GridMaster
    :rtype: int
    """
    master = GridMaster(grid)
    
    def solve():
        graph = collections.defaultdict(list)
        visited = set()

        def explore(r, c):
            visited.add((r, c))

            directions = {'U': (-1, 0), 'D': (1, 0), 'L': (0, -1), 'R': (0, 1)}
            char_directions = ['U', 'D', 'L', 'R']

            for char_dir in char_directions:
                if master.canMove(char_dir):
                    dr, dc = directions[char_dir]
                    new_r, new_c = r + dr, c + dc
                    
                    if (new_r, new_c) not in visited:
                        graph[(r, c)].append((new_r, new_c))
                        graph[(new_r, new_c)].append((r, c))
                        
                        master.move(char_dir)
                        explore(new_r, new_c)
                        if char_dir == 'U': master.move('D')
                        elif char_dir == 'D': master.move('U')
                        elif char_dir == 'L': master.move('R')
                        elif char_dir == 'R': master.move('L')

        start_row, start_col = -1, -1
        for r in range(len(grid)):
            for c in range(len(grid[0])):
                if grid[r][c] == -1:
                    start_row, start_col = r, c
                    break

        explore(start_row, start_col)

        q = collections.deque([(start_row, start_col, 0)])
        visited = set()
        visited.add((start_row, start_col))

        while q:
            row, col, dist = q.popleft()
            if grid[row][col] == 2:
                return dist

            for neighbor_row, neighbor_col in graph[(row, col)]:
                if (neighbor_row, neighbor_col) not in visited:
                    visited.add((neighbor_row, neighbor_col))
                    q.append((neighbor_row, neighbor_col, dist + 1))

        return -1
    
    return solve()


def test_cases():
    tests = [
        ([[1,2],[-1,0]], 2),
        ([[0,0,-1],[1,1,1],[2,0,0]], 4),
        ([[-1,0],[0,2]], -1),
        ([[1, 1, 1, 1, 1], [1, 0, 1, 0, 1], [1, 1, 2, 1, 1], [1, 0, 1, 0, 1], [-1, 1, 1, 1, 1]], 6)
    ]
    
    correct_count = 0
    total_tests = len(tests)
    
    for i, (grid, expected) in enumerate(tests):
        result = findShortestPath(grid)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Expected: {expected}, Got: {result})")
            
    print(f"{correct_count}/{total_tests}")

if __name__ == '__main__':
    test_cases()