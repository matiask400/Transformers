def num_times_all_blue(light):
    n = len(light)
    rightmost = 0
    on = [False] * n
    count = 0
    for i in range(n):
        on[light[i] - 1] = True
        rightmost = max(rightmost, light[i])
        
        blue = True
        for j in range(rightmost):
            if not on[j]:
                blue = False
                break
        
        if blue:
            count += 1
            
    return count

def test_num_times_all_blue():
    test_cases = [
        ([2,1,3,5,4], 3),
        ([3,2,4,1,5], 2),
        ([4,1,2,3], 1),
        ([2,1,4,3,6,5], 3),
        ([1,2,3,4,5,6], 6),
        ([1], 1),
        ([2,1], 1),
        ([3,1,2], 2)
    ]
    
    num_tests = len(test_cases)
    correct_tests = 0
    
    for i, (light, expected) in enumerate(test_cases):
        result = num_times_all_blue(light)
        if result == expected:
            print("True")
            correct_tests += 1
        else:
            print("False")
    
    print(f"{correct_tests}/{num_tests}")

if __name__ == "__main__":
    test_num_times_all_blue()