def largestMerge(word1: str, word2: str) -> str:
    """
    Given two strings word1 and word2. You want to construct a string merge in the following way: while either word1 or word2 are non-empty, choose one of the following options:
        If word1 is non-empty, append the first character in word1 to merge and delete it from word1.
        For example, if word1 = "abc" and merge = "dv", then after choosing this operation, word1 = "bc" and merge = "dva".
        If word2 is non-empty, append the first character in word2 to merge and delete it from word2.
        For example, if word2 = "abc" and merge = "", then after choosing this operation, word2 = "bc" and merge = "a".

    Return the lexicographically largest merge you can construct.
    """

    merge = ""
    i, j = 0, 0
    while i < len(word1) or j < len(word2):
        if i < len(word1) and j < len(word2):
            if word1[i:] > word2[j:]:
                merge += word1[i]
                i += 1
            else:
                merge += word2[j]
                j += 1
        elif i < len(word1):
            merge += word1[i]
            i += 1
        else:
            merge += word2[j]
            j += 1
    return merge

def test_largestMerge():
    tests = [
        {
            "word1": "cabaa",
            "word2": "bcaaa",
            "expected": "cbcabaaaaa"
        },
        {
            "word1": "abcabc",
            "word2": "abdcaba",
            "expected": "abdcabcabcaba"
        },
        {
            "word1": "leetcode",
            "word2": "coder",
            "expected": "leetcodecoder"
        },
        {
            "word1": "abc",
            "word2": "def",
            "expected": "defabc"
        },
        {
            "word1": "",
            "word2": "abc",
            "expected": "abc"
        },
        {
            "word1": "abc",
            "word2": "",
            "expected": "abc"
        },
        {
            "word1": "a",
            "word2": "a",
            "expected": "aa"
        },
        {
            "word1": "aba",
            "word2": "ababa",
            "expected": "abababa"
        }
    ]

    correct_tests = 0
    total_tests = len(tests)

    for test in tests:
        word1 = test["word1"]
        word2 = test["word2"]
        expected = test["expected"]
        actual = largestMerge(word1, word2)

        if actual == expected:
            print("True")
            correct_tests += 1
        else:
            print("False")
            print(f"  Input: word1 = '{word1}', word2 = '{word2}'")
            print(f"  Expected: '{expected}'")
            print(f"  Actual: '{actual}'")

    print(f"{correct_tests}/{total_tests}")

if __name__ == "__main__":
    test_largestMerge()