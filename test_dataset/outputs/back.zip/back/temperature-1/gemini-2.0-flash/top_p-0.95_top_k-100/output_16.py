def solve():
    def max_four_person_groups(n, reservedSeats):
        """
        Calculates the maximum number of four-person groups that can be assigned in a cinema.

        Args:
            n: The number of rows in the cinema.
            reservedSeats: A list of reserved seats, where each element is a list [row, seat].

        Returns:
            The maximum number of four-person groups that can be assigned.
        """

        reserved = {}
        for row, seat in reservedSeats:
            if row not in reserved:
                reserved[row] = set()
            reserved[row].add(seat)

        count = 0
        for i in range(1, n + 1):
            if i not in reserved:
                count += 2
            else:
                seats = reserved[i]
                can_assign = 0
                if 2 not in seats and 3 not in seats and 4 not in seats and 5 not in seats:
                    can_assign += 1
                if 6 not in seats and 7 not in seats and 8 not in seats and 9 not in seats:
                    can_assign += 1
                if can_assign == 0:
                    if 4 not in seats and 5 not in seats and 6 not in seats and 7 not in seats:
                        can_assign += 1
                count += can_assign
        return count
    
    test_cases = [
        (3, [[1, 2], [1, 3], [1, 8], [2, 6], [3, 1], [3, 10]], 4),
        (2, [[2, 1], [1, 8], [2, 6]], 2),
        (4, [[4, 3], [1, 4], [4, 6], [1, 7]], 4),
        (1, [], 2),
        (1, [[1, 2], [1, 3], [1, 4], [1, 5]], 1),
        (1, [[1, 6], [1, 7], [1, 8], [1, 9]], 1),
        (1, [[1, 4], [1, 5], [1, 6], [1, 7]], 1),
        (1, [[1, 2], [1, 3], [1, 4], [1, 5], [1, 6], [1, 7], [1, 8], [1, 9]], 0),
        (1, [[1, 1], [1, 2], [1, 3], [1, 4], [1, 5], [1, 6], [1, 7], [1, 8], [1, 9], [1, 10]], 0),
        (4, [[1,1],[1,2],[1,3],[1,4],[1,5],[1,6],[1,7],[1,8],[1,9],[1,10],[2,1],[2,2],[2,3],[2,4],[2,5],[2,6],[2,7],[2,8],[2,9],[2,10],[3,1],[3,2],[3,3],[3,4],[3,5],[3,6],[3,7],[3,8],[3,9],[3,10],[4,1],[4,2],[4,3],[4,4],[4,5],[4,6],[4,7],[4,8],[4,9],[4,10]], 0)

    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (n, reservedSeats, expected) in enumerate(test_cases):
        result = max_four_person_groups(n, reservedSeats)
        if result == expected:
            print(f"True")
            correct_count += 1
        else:
            print(f"False")

    print(f"{correct_count}/{total_count}")

solve()