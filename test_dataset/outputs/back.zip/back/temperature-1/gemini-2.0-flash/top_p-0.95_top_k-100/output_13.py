def advantageCount(A, B):
    """
    Given two arrays A and B of equal size, the advantage of A with respect to B is the number of indices i for which A[i] > B[i].

    Return any permutation of A that maximizes its advantage with respect to B.
    """
    n = len(A)
    A = sorted(A)
    idx = sorted(range(n), key=lambda i: B[i])
    res = [0] * n
    left, right = 0, n - 1
    for i in idx:
        if A[left] > B[i]:
            res[i] = A[left]
            left += 1
        else:
            res[i] = A[right]
            right -= 1
    return res


def test_advantageCount():
    test_cases = [
        {
            "A": [2, 7, 11, 15],
            "B": [1, 10, 4, 11],
            "expected": [2, 11, 7, 15],
        },
        {
            "A": [12, 24, 8, 32],
            "B": [13, 25, 32, 11],
            "expected": [24, 32, 8, 12],
        },
        {
            "A": [2, 0, 4, 1, 2],
            "B": [1, 3, 0, 0, 2],
            "expected": [2, 0, 4, 2, 1],
        },
        {
            "A": [1, 2, 3, 4, 5],
            "B": [5, 4, 3, 2, 1],
            "expected": [2, 3, 4, 5, 1],
        },
        {
            "A": [5, 4, 3, 2, 1],
            "B": [1, 2, 3, 4, 5],
            "expected": [2, 1, 5, 4, 3],
        }
    ]

    correct_count = 0
    total_count = len(test_cases)

    for test_case in test_cases:
        A = test_case["A"]
        B = test_case["B"]
        expected = test_case["expected"]
        actual = advantageCount(A, B)

        # Check if the advantage is maximized. Due to permutation, we can't just
        # compare the output directly.
        adv_expected = sum(1 for i in range(len(A)) if expected[i] > B[i])
        adv_actual = sum(1 for i in range(len(A)) if actual[i] > B[i])

        
        
        if adv_actual == adv_expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")


if __name__ == "__main__":
    test_advantageCount()