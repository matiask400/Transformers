def ip_to_int(ip):
    parts = ip.split('.')
    result = 0
    for part in parts:
        result = (result << 8) + int(part)
    return result

def int_to_ip(num):
    parts = []
    for i in range(4):
        parts.insert(0, str(num & 255))
        num >>= 8
    return '.'.join(parts)

def ip_to_cidr(ip, n):
    start = ip_to_int(ip)
    result = []
    while n > 0:
        bits = 0
        while (start % (1 << bits) != 0) or (1 << bits > n):
            bits += 1
        bits -= 1
        result.append(int_to_ip(start) + '/' + str(32 - bits))
        start += (1 << bits)
        n -= (1 << bits)
    return result

def test_ip_to_cidr():
    tests = [
        {
            "ip": "255.0.0.7",
            "n": 10,
            "expected": ["255.0.0.7/32", "255.0.0.8/29", "255.0.0.16/32"]
        },
        {
            "ip": "1.2.3.4",
            "n": 1,
            "expected": ["1.2.3.4/32"]
        },
        {
            "ip": "1.2.3.4",
            "n": 2,
            "expected": ["1.2.3.4/31"]
        },
        {
            "ip": "1.2.3.4",
            "n": 3,
            "expected": ["1.2.3.4/31", "1.2.3.6/32"]
        },
        {
            "ip": "1.2.3.4",
            "n": 4,
            "expected": ["1.2.3.4/30"]
        },
        {
            "ip": "0.0.0.0",
            "n": 8,
            "expected": ["0.0.0.0/29"]
        },
        {
            "ip": "170.224.236.136",
            "n": 4,
            "expected": ["170.224.236.136/30"]
        }
    ]

    correct_count = 0
    total_tests = len(tests)

    for test in tests:
        ip = test["ip"]
        n = test["n"]
        expected = test["expected"]
        actual = ip_to_cidr(ip, n)

        if actual == expected:
            print("True")
            correct_count += 1
        else:
            print("False")
            print(f"  Input: ip={ip}, n={n}")
            print(f"  Expected: {expected}")
            print(f"  Actual: {actual}")

    print(f"{correct_count}/{total_tests}")

test_ip_to_cidr()