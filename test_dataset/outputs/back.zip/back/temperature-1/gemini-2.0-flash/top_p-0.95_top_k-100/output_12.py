def is_n_straight_hand(hand, W):
    """
    Determines if Alice can rearrange her hand of cards into groups of size W,
    where each group consists of W consecutive cards.

    Args:
        hand (list of int): The list of cards in Alice's hand.
        W (int): The size of each group.

    Returns:
        bool: True if Alice can rearrange her hand, False otherwise.
    """
    if len(hand) % W != 0:
        return False

    counts = {}
    for card in hand:
        counts[card] = counts.get(card, 0) + 1

    import heapq
    heap = list(counts.keys())
    heapq.heapify(heap)

    while heap:
        first = heapq.heappop(heap)
        if counts[first] == 0:
            continue
        counts[first] -= 1

        for i in range(1, W):
            next_card = first + i
            if next_card not in counts or counts[next_card] == 0:
                return False
            counts[next_card] -= 1

    return True

def test_is_n_straight_hand():
    """
    Tests the is_n_straight_hand function with various test cases.
    """
    test_cases = [
        ([1, 2, 3, 6, 2, 3, 4, 7, 8], 3, True),
        ([1, 2, 3, 4, 5], 4, False),
        ([1, 2, 3, 4, 5, 6], 2, True),
        ([1, 2, 3, 4, 5, 6], 3, True),
        ([1, 2, 3, 4, 5, 6, 7], 3, False),
        ([1, 2, 3], 1, True),
        ([1, 2, 3, 4], 2, True),
        ([1, 1, 2, 2, 3, 3], 2, True),
        ([1, 1, 2, 2, 3, 3], 3, True),
        ([1, 1, 2, 2, 3, 3, 4], 3, False),
        ([1, 2, 3, 4, 5], 1, True),
        ([0,1,2,3,4,5], 2, True),
        ([8,10,12], 3, False),
        ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 3, True),
        ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 4, True)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for hand, W, expected in test_cases:
        result = is_n_straight_hand(hand, W)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_is_n_straight_hand()