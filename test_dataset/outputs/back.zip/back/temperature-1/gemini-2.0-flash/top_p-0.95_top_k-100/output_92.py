def to_hexspeak(num: str) -> str:
    """
    Given a string `num` representing a decimal integer `N`, return the Hexspeak representation of `N` if it is valid, otherwise return `"ERROR"`.

    A decimal number can be converted to its Hexspeak representation by first converting it to an uppercase hexadecimal string, then replacing all occurrences of the digit `0` with the letter `O`, and the digit `1` with the letter `I`.  Such a representation is valid if and only if it consists only of the letters in the set `{"A", "B", "C", "D", "E", "F", "I", "O"}`.

    Example 1:
    Input: num = "257"
    Output: "IOI"
    Explanation:  257 is 101 in hexadecimal.


    Example 2:
    Input: num = "3"
    Output: "ERROR"

    Constraints:
    `1 <= N <= 10^12`
    There are no leading zeros in the given string.

    All answers must be in uppercase letters.
    """
    n = int(num)
    hex_str = hex(n)[2:].upper()
    hexspeak = hex_str.replace("0", "O").replace("1", "I")
    for char in hexspeak:
        if char not in "ABCDEFIO":
            return "ERROR"
    return hexspeak


def test_to_hexspeak():
    test_cases = [
        {"input": "257", "expected": "IOI"},
        {"input": "3", "expected": "ERROR"},
        {"input": "42", "expected": "2A"},
        {"input": "11", "expected": "B"},
        {"input": "741845564379569116", "expected": "BABEFACEFEED"},
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, test_case in enumerate(test_cases):
        input_num = test_case["input"]
        expected_output = test_case["expected"]
        actual_output = to_hexspeak(input_num)

        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {input_num}")
            print(f"  Expected: {expected_output}")
            print(f"  Actual: {actual_output}")

    print(f"\nCorrect: {correct_count}/{total_count}")


if __name__ == "__main__":
    test_to_hexspeak()