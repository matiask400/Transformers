def smallest_repunit_div_by_k(k: int) -> int:
    """
    Given a positive integer `K`, you need to find the length of the smallest positive integer `N` such that `N` is divisible by `K`, and `N` only contains the digit `1`.

    Return the length of `N`. If there is no such `N`, return -1.

    Note: `N` may not fit in a 64-bit signed integer.
    """
    if k % 2 == 0 or k % 5 == 0:
        return -1

    remainder = 0
    length = 0
    for i in range(1, k + 1):
        remainder = (remainder * 10 + 1) % k
        length += 1
        if remainder == 0:
            return length
    return -1


def test_smallest_repunit_div_by_k():
    test_cases = [
        (1, 1),
        (2, -1),
        (3, 3),
        (7, 6),
        (11, 2),
        (13, 6),
        (17, 16),
        (19, 18),
        (23, 22),
        (99991, 5),
        (10000, -1),
        (9,9)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for k, expected in test_cases:
        result = smallest_repunit_div_by_k(k)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")


if __name__ == "__main__":
    test_smallest_repunit_div_by_k()