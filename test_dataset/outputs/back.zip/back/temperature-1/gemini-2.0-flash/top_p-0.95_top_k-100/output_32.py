def subarraysDivByK(A, K):
    count = 0
    for i in range(len(A)):
        current_sum = 0
        for j in range(i, len(A)):
            current_sum += A[j]
            if current_sum % K == 0:
                count += 1
    return count

def test_subarraysDivByK():
    test_cases = [
        (([4, 5, 0, -2, -3, 1], 5), 7),
        (([5], 5), 1),
        (([5, 0], 5), 2),
        (([5, 0, -2, -3], 5), 4),
        (([0], 5), 1),
        (([0, -2, -3], 5), 2),
        (([-2, -3], 5), 1),
        (([1, 2, 3], 5), 0),
        (([5, 5, 5], 5), 6),
        (([10, 20, 30], 10), 6),
        (([10, 20, 30], 5), 6),
        (([-1,-2,-3],3), 3),
        (([2,-2,2,-4],6), 4)

    ]
    
    correct_count = 0
    total_count = len(test_cases)
    
    for i, ((A, K), expected) in enumerate(test_cases):
        result = subarraysDivByK(A, K)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Expected: {expected}, Got: {result})")
            
    print(f"\n{correct_count}/{total_count}")

test_subarraysDivByK()