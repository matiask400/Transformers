def maxJumps(arr, d):
    n = len(arr)
    dp = [0] * n

    def dfs(i):
        if dp[i] != 0:
            return dp[i]
        
        dp[i] = 1
        
        # Jump to the right
        for j in range(i + 1, min(i + d + 1, n)):
            valid_jump = True
            for k in range(i + 1, j):
                if arr[i] <= arr[k]:
                    valid_jump = False
                    break
            if valid_jump and arr[i] > arr[j]:
                dp[i] = max(dp[i], 1 + dfs(j))

        # Jump to the left
        for j in range(i - 1, max(i - d - 1, -1), -1):
            valid_jump = True
            for k in range(j + 1, i):
                if arr[i] <= arr[k]:
                    valid_jump = False
                    break
            if valid_jump and arr[i] > arr[j]:
                dp[i] = max(dp[i], 1 + dfs(j))
        
        return dp[i]

    max_reachable = 0
    for i in range(n):
        max_reachable = max(max_reachable, dfs(i))
    
    return max_reachable

def test_maxJumps():
    test_cases = [
        ([6,4,14,6,8,13,9,7,10,6,12], 2, 4),
        ([3,3,3,3,3], 3, 1),
        ([7,6,5,4,3,2,1], 1, 7),
        ([7,1,7,1,7,1], 2, 2),
        ([66], 1, 1),
        ([1,2,3,4,5,6,7,8,9,10], 1, 1),
        ([10,9,8,7,6,5,4,3,2,1], 1, 10),
        ([1, 2, 1, 2, 1, 2], 2, 2)
    ]
    
    num_correct = 0
    total_tests = len(test_cases)
    
    for i, (arr, d, expected) in enumerate(test_cases):
        result = maxJumps(arr, d)
        if result == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: arr={arr}, d={d}")
            print(f"  Expected: {expected}, Got: {result}")
    
    print(f"\nCorrect: {num_correct} / {total_tests}")

if __name__ == "__main__":
    test_maxJumps()