def remove_vowels(s):
  """Removes vowels from a string.

  Args:
    s: The input string.

  Returns:
    The string with vowels removed.
  """
  vowels = "aeiou"
  result = ""
  for char in s:
    if char not in vowels:
      result += char
  return result

def test_remove_vowels():
  """Tests the remove_vowels function."""
  test_cases = [
      {"input": "leetcodeisacommunityforcoders", "expected": "ltcdscmmntyfrcdrs"},
      {"input": "aeiou", "expected": ""},
      {"input": "bcdfghjklmnpqrstvwxyz", "expected": "bcdfghjklmnpqrstvwxyz"},
      {"input": "a", "expected": ""},
      {"input": "e", "expected": ""},
      {"input": "i", "expected": ""},
      {"input": "o", "expected": ""},
      {"input": "u", "expected": ""},
      {"input": "", "expected": ""},
      {"input": "hello", "expected": "hll"},
      {"input": "world", "expected": "wrld"}
  ]

  correct_count = 0
  total_count = len(test_cases)

  for i, test_case in enumerate(test_cases):
    input_str = test_case["input"]
    expected_output = test_case["expected"]
    actual_output = remove_vowels(input_str)

    if actual_output == expected_output:
      print(f"Test {i+1}: True")
      correct_count += 1
    else:
      print(f"Test {i+1}: False")

  print(f"\nCorrect: {correct_count}/{total_count}")


if __name__ == "__main__":
  test_remove_vowels()