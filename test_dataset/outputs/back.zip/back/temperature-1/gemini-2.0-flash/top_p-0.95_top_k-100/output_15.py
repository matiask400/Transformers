def can_cross(stones):
    """
    Determines if the frog can cross the river by landing on the last stone.

    Args:
        stones: A list of stone positions (in units) in sorted ascending order.

    Returns:
        True if the frog can cross the river, False otherwise.
    """

    if not stones or stones[0] != 0:
        return False

    n = len(stones)
    if n == 2:
        return stones[1] == 1

    stone_set = set(stones)
    reachable = {0: {0}}  # stone_index: possible k values

    for i in range(n - 1):
        stone = stones[i]
        if stone not in reachable:
            continue
        
        for k in reachable[stone]:
            for jump in [k - 1, k, k + 1]:
                if jump > 0 and stone + jump in stone_set:
                    next_stone = stone + jump
                    if next_stone == stones[-1]:
                        return True

                    if next_stone not in reachable:
                        reachable[next_stone] = set()
                    reachable[next_stone].add(jump)
    
    return False


def test_can_cross():
    """
    Tests the can_cross function with multiple test cases.
    """

    test_cases = [
        ([0, 1, 3, 5, 6, 8, 12, 17], True),
        ([0, 1, 2, 3, 4, 8, 9, 11], False),
        ([0, 1], True),
        ([0, 2], False),
        ([0, 1, 3, 6, 10, 15, 21], True),
        ([0, 1, 3, 5, 6, 8, 12, 17], True),
        ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10], True),
        ([0, 1, 2, 3, 5, 6, 7, 9, 11, 13], False),
        ([0,2,5,6,7,9,11,13], False),
        ([0,1,2,3,5,6,7,9,10,12], False),

    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (stones, expected) in enumerate(test_cases):
        actual = can_cross(stones)
        if actual == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Input: {stones}, Expected: {expected}, Actual: {actual})")

    print(f"\nCorrect: {correct_count}/{total_count}")


if __name__ == "__main__":
    test_can_cross()