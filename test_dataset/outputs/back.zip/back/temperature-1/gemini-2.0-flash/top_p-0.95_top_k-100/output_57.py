def total_money(n: int) -> int:
    """
    Hercy wants to save money for his first car. He puts money in the Leetcode bank every day.

    He starts by putting in $1 on Monday, the first day. Every day from Tuesday to Sunday, he will put in $1 more than the day before.
    On every subsequent Monday, he will put in $1 more than the previous Monday.
    Given n, return the total amount of money he will have in the Leetcode bank at the end of the nth day.
    """
    total = 0
    week = 0
    day = 0
    while n > 0:
        week += 1
        daily = week
        for i in range(min(n, 7)):
            total += daily
            daily += 1
            day += 1
        n -= 7
    return total


def test_total_money():
    test_cases = [
        (4, 10),
        (10, 37),
        (20, 96),
        (1, 1),
        (7, 28),
        (14, 70),
        (21, 126),
        (28, 196),
        (365, 6440),
        (1000, 53500)
    ]
    
    correct_count = 0
    total_tests = len(test_cases)

    for i, (n, expected) in enumerate(test_cases):
        actual = total_money(n)
        if actual == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Input: {n}, Expected: {expected}, Actual: {actual})")

    print(f"\n{correct_count}/{total_tests}")

if __name__ == "__main__":
    test_total_money()