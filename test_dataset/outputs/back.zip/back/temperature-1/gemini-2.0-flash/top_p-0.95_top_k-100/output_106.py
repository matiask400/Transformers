import heapq
from collections import Counter

def rearrange_string(s: str, k: int) -> str:
    """
    Rearranges a string such that the same characters are at least distance k from each other.

    Args:
        s: The string to rearrange.
        k: The minimum distance between the same characters.

    Returns:
        The rearranged string, or an empty string if it is not possible to rearrange the string.
    """

    if k == 0:
        return s

    counts = Counter(s)
    heap = [(-count, char) for char, count in counts.items()]
    heapq.heapify(heap)

    result = ""
    queue = []

    while heap:
        count, char = heapq.heappop(heap)
        result += char
        queue.append((char, len(result) + k))

        while queue and queue[0][1] <= len(result):
            c, _ = queue.pop(0)
            counts[c] -= 1
            if counts[c] > 0:
                heapq.heappush(heap, (-counts[c], c))

    if len(result) == len(s):
        return result
    else:
        return ""

def test_rearrange_string():
    test_cases = [
        ("aabbcc", 3, "abcabc"),
        ("aaabc", 3, ""),
        ("aaadbbcc", 2, "abacabcd"),
        ("a", 0, "a"),
        ("a", 1, "a"),
        ("abc", 0, "abc"),
        ("abc", 1, "abc"),
        ("aa", 2, ""),
        ("aaa", 2, ""),
        ("aab", 2, "aba"),
        ("aab", 3, ""),
        ("aabb", 2, "abab"),
        ("aabb", 3, ""),
        ("aaabb", 2, "ababa"),
        ("aaabb", 3, ""),
        ("aaaa", 2, ""),
        ("aaaa", 0, "aaaa"),
    ]

    correct_count = 0
    total_count = len(test_cases)

    for s, k, expected in test_cases:
        result = rearrange_string(s, k)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_rearrange_string()