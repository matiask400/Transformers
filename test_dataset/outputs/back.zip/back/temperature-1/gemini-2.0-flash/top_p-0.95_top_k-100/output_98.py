def find_fixed_point(arr):
    """
    Finds the smallest index i in a sorted array arr such that arr[i] == i.

    Args:
        arr: A sorted array of distinct integers.

    Returns:
        The smallest index i such that arr[i] == i. If no such index exists, returns -1.
    """
    left, right = 0, len(arr) - 1
    result = -1

    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == mid:
            result = mid
            right = mid - 1  # Look for smaller index
        elif arr[mid] < mid:
            left = mid + 1
        else:
            right = mid - 1

    return result


def test_find_fixed_point():
    test_cases = [
        ([-10, -5, 0, 3, 7], 3),
        ([0, 2, 5, 8, 17], 0),
        ([-10, -5, 3, 4, 7, 9], -1),
        ([0], 0),
        ([1], -1),
        ([-1, 0, 1, 2, 3, 4], 1),
        ([-2,-1,0,1,2], 2),
        ([-1,1,3,5,7], -1)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for arr, expected in test_cases:
        actual = find_fixed_point(arr)
        if actual == expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")


if __name__ == "__main__":
    test_find_fixed_point()