def find_median_sorted_arrays(nums1, nums2):
    """
    Finds the median of two sorted arrays.

    Args:
        nums1: The first sorted array.
        nums2: The second sorted array.

    Returns:
        The median of the two sorted arrays.
    """
    merged_array = sorted(nums1 + nums2)
    total_length = len(merged_array)

    if total_length % 2 == 0:
        # Even number of elements, median is the average of the two middle elements
        mid1 = merged_array[total_length // 2 - 1]
        mid2 = merged_array[total_length // 2]
        median = (mid1 + mid2) / 2.0
    else:
        # Odd number of elements, median is the middle element
        median = float(merged_array[total_length // 2])

    return median

def test_find_median_sorted_arrays():
    """
    Tests the find_median_sorted_arrays function.
    """
    tests = [
        (([1, 3], [2]), 2.0),
        (([1, 2], [3, 4]), 2.5),
        (([0, 0], [0, 0]), 0.0),
        (([], [1]), 1.0),
        (([2], []), 2.0),
        (([1,5], [2,3,4,6]), 3.5),
        (([1, 2, 5], [3, 4]), 3.0)
    ]

    correct_count = 0
    total_count = len(tests)

    for i, (input_arrays, expected_output) in enumerate(tests):
        nums1, nums2 = input_arrays
        actual_output = find_median_sorted_arrays(nums1, nums2)
        if abs(actual_output - expected_output) < 1e-5:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: nums1={nums1}, nums2={nums2}")
            print(f"  Expected Output: {expected_output}")
            print(f"  Actual Output: {actual_output}")

    print(f"\nCorrect Tests: {correct_count}/{total_count}")

if __name__ == "__main__":
    test_find_median_sorted_arrays()