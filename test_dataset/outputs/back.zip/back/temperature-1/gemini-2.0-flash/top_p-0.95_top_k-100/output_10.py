def count_substrings(s):
    """
    Counts the number of substrings containing at least one occurrence of 'a', 'b', and 'c'.

    Args:
        s: The input string consisting of 'a', 'b', and 'c' characters.

    Returns:
        The number of substrings containing at least one occurrence of 'a', 'b', and 'c'.
    """

    n = len(s)
    count = 0
    for i in range(n):
        for j in range(i, n):
            sub = s[i:j+1]
            if 'a' in sub and 'b' in sub and 'c' in sub:
                count += 1
    return count

def test_count_substrings():
    """
    Tests the count_substrings function with several test cases.
    """

    test_cases = [
        {"input": "abcabc", "expected": 10},
        {"input": "aaacb", "expected": 3},
        {"input": "abc", "expected": 1},
        {"input": "abca", "expected": 3},
        {"input": "aaabbbccc", "expected": 28},
        {"input": "abcabcabc", "expected": 21},
        {"input": "cababc", "expected": 10},
        {"input": "cccaaaabbbb", "expected": 35},
        {"input": "a", "expected": 0},
        {"input": "ab", "expected": 0},
        {"input": "ca", "expected": 0},
        {"input": "bc", "expected": 0},
        {"input": "aaaaaa", "expected": 0},
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        input_string = test_case["input"]
        expected_output = test_case["expected"]
        actual_output = count_substrings(input_string)

        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False (Input: {input_string}, Expected: {expected_output}, Actual: {actual_output})")

    print(f"\nCorrect: {num_correct} / {total_tests}")

if __name__ == "__main__":
    test_count_substrings()