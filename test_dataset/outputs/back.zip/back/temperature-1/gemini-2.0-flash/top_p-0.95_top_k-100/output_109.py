def generate_possible_next_moves(currentState):
    """
    Given a string currentState that contains only '+' and '-', return all possible states of the string currentState after one valid move.
    You may return the answer in any order. If there is no valid move, return an empty list [].

    For example:
    generate_possible_next_moves("++++") == ["--++","+--+","++--"]
    generate_possible_next_moves("+") == []
    """
    possible_states = []
    for i in range(len(currentState) - 1):
        if currentState[i:i+2] == "++":
            possible_states.append(currentState[:i] + "--" + currentState[i+2:])
    return possible_states

def test_generate_possible_next_moves():
    test_cases = [
        ("++++", ["--++","+--+","++--"]),
        ("+", []),
        ("++", ["--"]),
        ("-+", []),
        ("+-+", []),
        ("+++", ["--+", "+--"]),
        ("+-++", ["+--+"]),
        ("+++++", ["--+++", "+--++", "++--+","+++--"]),
        ("-----------------",[])
    ]
    
    correct_count = 0
    total_count = len(test_cases)
    
    for i, (input_str, expected_output) in enumerate(test_cases):
        result = generate_possible_next_moves(input_str)
        
        # Sort both lists to ensure order doesn't matter in comparison
        result.sort()
        expected_output.sort()

        if result == expected_output:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {input_str}")
            print(f"  Expected: {expected_output}")
            print(f"  Got: {result}")
            
    print(f"{correct_count}/{total_count}")

if __name__ == '__main__':
    test_generate_possible_next_moves()