class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def isValidBST(root: TreeNode) -> bool:
    def isValidBSTHelper(node: TreeNode, min_val: float, max_val: float) -> bool:
        if not node:
            return True

        if node.val <= min_val or node.val >= max_val:
            return False

        return (isValidBSTHelper(node.left, min_val, node.val) and
                isValidBSTHelper(node.right, node.val, max_val))

    return isValidBSTHelper(root, float('-inf'), float('inf'))


def test_isValidBST():
    test_cases = [
        ([2, 1, 3], True),
        ([5, 1, 4, None, None, 3, 6], False),
        ([1, None, 2], True),
        ([0, None, 0], False),
        ([1, 1, None], False),
        ([2, 2, 2], False),
        ([3,1,5,0,2,4,6,None,None,None,3], False),
        ([5,4,6,None,None,3,7], False),
        ([10,5,15,None,None,6,20], False),
        ([10,5,15,None,None,6,20], False),
        ([32,26,47,19,None,None,56,None,27,None,None,None,None], False),
        ([120,70,140,50,100,130,160,20,55,75,110,119,135,150,200], False),
    ]
    
    num_correct = 0
    total_tests = len(test_cases)
    
    for i, (input_tree, expected_output) in enumerate(test_cases):
        # Construct tree from list representation
        def construct_tree(arr):
            if not arr:
                return None
            
            nodes = [TreeNode(val) if val is not None else None for val in arr]
            
            for i in range(len(nodes)):
                if nodes[i]:
                    left_child_index = 2 * i + 1
                    right_child_index = 2 * i + 2
                    
                    if left_child_index < len(nodes):
                        nodes[i].left = nodes[left_child_index]
                    if right_child_index < len(nodes):
                        nodes[i].right = nodes[right_child_index]
                        
            return nodes[0]
        
        root = construct_tree(input_tree)
        
        actual_output = isValidBST(root)
        
        if actual_output == expected_output:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")
            
    print(f"{num_correct}/{total_tests}")

test_isValidBST()