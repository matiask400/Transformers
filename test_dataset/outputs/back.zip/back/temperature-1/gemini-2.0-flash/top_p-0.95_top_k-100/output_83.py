class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def sumRootToLeaf(root: TreeNode) -> int:
    def dfs(node, current_number):
        if not node:
            return 0
        current_number = (current_number << 1) | node.val
        if not node.left and not node.right:
            return current_number
        return dfs(node.left, current_number) + dfs(node.right, current_number)

    return dfs(root, 0)

def test_sumRootToLeaf():
    # Test case 1
    root1 = TreeNode(1, TreeNode(0, TreeNode(0), TreeNode(1)), TreeNode(1, TreeNode(0), TreeNode(1)))
    expected1 = 22
    result1 = sumRootToLeaf(root1)
    print(result1 == expected1)
    
    # Test case 2
    root2 = TreeNode(0)
    expected2 = 0
    result2 = sumRootToLeaf(root2)
    print(result2 == expected2)
    
    # Test case 3
    root3 = TreeNode(1)
    expected3 = 1
    result3 = sumRootToLeaf(root3)
    print(result3 == expected3)

    # Test case 4
    root4 = TreeNode(1, TreeNode(1), None)
    expected4 = 3
    result4 = sumRootToLeaf(root4)
    print(result4 == expected4)

    # Test case 5
    root5 = TreeNode(1, None, TreeNode(0))
    expected5 = 2
    result5 = sumRootToLeaf(root5)
    print(result5 == expected5)

    # Test case 6
    root6 = TreeNode(1, TreeNode(0, TreeNode(0,TreeNode(0),TreeNode(1))), TreeNode(1, TreeNode(0, TreeNode(1)), TreeNode(1)))
    expected6 = 25
    result6 = sumRootToLeaf(root6)
    print(result6 == expected6)

    correct_tests = 0
    total_tests = 6

    if result1 == expected1:
        correct_tests += 1
    if result2 == expected2:
        correct_tests += 1
    if result3 == expected3:
        correct_tests += 1
    if result4 == expected4:
        correct_tests += 1
    if result5 == expected5:
        correct_tests += 1
    if result6 == expected6:
        correct_tests += 1

    print(f"{correct_tests}/{total_tests}")
    
test_sumRootToLeaf()