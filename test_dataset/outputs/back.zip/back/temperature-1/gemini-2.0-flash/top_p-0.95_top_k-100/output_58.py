def min_start_value(nums):
    start_value = 1
    while True:
        current_sum = start_value
        valid = True
        for num in nums:
            current_sum += num
            if current_sum < 1:
                valid = False
                break
        if valid:
            return start_value
        start_value += 1

def test_min_start_value():
    test_cases = [
        ([-3, 2, -3, 4, 2], 5),
        ([1, 2], 1),
        ([1, -2, -3], 5),
        ([-1, -2, -3], 7),
        ([3, -1, -2], 1)
    ]
    
    num_tests = len(test_cases)
    correct_tests = 0
    
    for i, (nums, expected) in enumerate(test_cases):
        result = min_start_value(nums)
        if result == expected:
            print("True")
            correct_tests += 1
        else:
            print("False")
            
    print(f"{correct_tests}/{num_tests}")

test_min_start_value()