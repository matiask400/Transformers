def assign_bikes(workers, bikes):
    """
    Assigns bikes to workers based on Manhattan distance.

    Args:
        workers: A list of worker coordinates (list of lists).
        bikes: A list of bike coordinates (list of lists).

    Returns:
        A list of bike indices assigned to each worker.
    """

    n = len(workers)
    m = len(bikes)
    ans = [0] * n
    worker_assigned = [False] * n
    bike_assigned = [False] * m

    distances = []
    for i in range(n):
        for j in range(m):
            dist = abs(workers[i][0] - bikes[j][0]) + abs(workers[i][1] - bikes[j][1])
            distances.append((dist, i, j))

    distances.sort()

    for dist, worker_index, bike_index in distances:
        if not worker_assigned[worker_index] and not bike_assigned[bike_index]:
            ans[worker_index] = bike_index
            worker_assigned[worker_index] = True
            bike_assigned[bike_index] = True

    return ans


def test_assign_bikes():
    """
    Tests the assign_bikes function with different test cases.
    """

    test_cases = [
        (
            [[0, 0], [2, 1]],
            [[1, 2], [3, 3]],
            [1, 0],
        ),
        (
            [[0, 0], [1, 1], [2, 0]],
            [[1, 0], [2, 2], [2, 1]],
            [0, 2, 1],
        ),
        (
            [[0, 0]],
            [[1, 1]],
            [0]
        ),
        (
            [[0, 0], [0, 1]],
            [[1, 1], [0, 2]],
            [1, 0],
        ),
        (
            [[0, 0], [1, 0], [2, 0]],
            [[0, 1], [1, 1], [2, 1]],
            [0, 1, 2],
        ),
        (
            [[77, 17], [37, 65], [32, 74], [88, 72], [3, 16], [61, 3], [4, 92], [3, 78], [30, 45], [79, 44]],
            [[71, 2], [2, 75], [10, 9], [45, 2], [30, 49], [88, 69], [5, 80], [48, 8], [67, 45], [22, 54]],
            [0, 6, 1, 5, 2, 3, 7, 4, 9, 8]
        )

    ]

    correct_count = 0
    for i, (workers, bikes, expected) in enumerate(test_cases):
        result = assign_bikes(workers, bikes)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: workers={workers}, bikes={bikes}")
            print(f"  Expected: {expected}")
            print(f"  Got: {result}")

    print(f"\n{correct_count}/{len(test_cases)}")


if __name__ == "__main__":
    test_assign_bikes()