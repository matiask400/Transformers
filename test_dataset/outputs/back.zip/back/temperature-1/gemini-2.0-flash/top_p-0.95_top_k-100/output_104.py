def solve():
    def count_remaining_nodes(nodes, parent, value):
        """
        Removes subtrees with sum of values equal to zero and returns the number of remaining nodes.

        Args:
            nodes: The number of nodes in the tree.
            parent: A list representing the parent of each node. parent[i] is the parent of node i.
            value: A list representing the value of each node. value[i] is the value of node i.

        Returns:
            The number of remaining nodes after removing zero-sum subtrees.
        """

        children = [[] for _ in range(nodes)]
        for i in range(1, nodes):
            children[parent[i]].append(i)

        subtree_sums = [0] * nodes
        remaining_nodes = [True] * nodes

        def calculate_subtree_sum(node):
            subtree_sums[node] = value[node]
            for child in children[node]:
                calculate_subtree_sum(child)
                subtree_sums[node] += subtree_sums[child]

        def remove_zero_sum_subtrees(node):
            for child in children[node]:
                remove_zero_sum_subtrees(child)
                if subtree_sums[child] == 0:
                    remaining_nodes[child] = False

        calculate_subtree_sum(0)
        remove_zero_sum_subtrees(0)

        if subtree_sums[0] == 0:
            return 0

        count = 0
        for i in range(nodes):
            if remaining_nodes[i]:
                count += 1
        return count

    test_cases = [
        (7, [-1, 0, 0, 1, 2, 2, 2], [1, -2, 4, 0, -2, -1, -1], 2),
        (7, [-1, 0, 0, 1, 2, 2, 2], [1, -2, 4, 0, -2, -1, -2], 6),
        (5, [-1, 0, 1, 0, 0], [-672, 441, 18, 728, 378], 5),
        (5, [-1, 0, 0, 1, 1], [-686, -842, 616, -739, -746], 5)
    ]

    num_correct = 0
    for i, (nodes, parent, value, expected) in enumerate(test_cases):
        result = count_remaining_nodes(nodes, parent, value)
        if result == expected:
            print(f"True")
            num_correct += 1
        else:
            print(f"False")
    print(f"{num_correct}/{len(test_cases)}")
    
solve()