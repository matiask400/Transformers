import collections

def solve():
    def max_value_of_equation(points, k):
        """
        Finds the maximum value of the equation yi + yj + |xi - xj| where |xi - xj| <= k.

        Args:
            points: A list of lists, where each inner list represents a point [xi, yi].
            k: An integer representing the maximum allowed difference between x-values.

        Returns:
            The maximum value of the equation.
        """
        max_val = float('-inf')
        for i in range(len(points)):
            for j in range(i + 1, len(points)):
                xi, yi = points[i]
                xj, yj = points[j]
                if abs(xi - xj) <= k:
                    max_val = max(max_val, yi + yj + abs(xi - xj))
        return max_val

    def run_test(points, k, expected):
        """
        Runs a test case and prints whether it passed or failed.

        Args:
            points: The input list of points.
            k: The input integer k.
            expected: The expected output value.

        Returns:
            True if the test passed, False otherwise.
        """
        result = max_value_of_equation(points, k)
        if result == expected:
            print('True')
            return True
        else:
            print('False')
            return False

    # Test cases
    test_cases = [
        ([[1, 3], [2, 0], [5, 10], [6, -10]], 1, 4),
        ([[0, 0], [3, 0], [9, 2]], 3, 3),
        ([[1, 0], [2, 0], [3, 0]], 1, 1),
        ([[1, 0], [5, 0], [7, 0]], 3, float('-inf')),  # Should not calculate since no pair matches
        ([[1,1],[2,2],[3,3],[4,4],[5,5],[6,6],[7,7],[8,8],[9,9],[10,10]], 3, 29)
    ]

    num_correct = 0
    for points, k, expected in test_cases:
        if run_test(points, k, expected):
            num_correct += 1

    print(f'{num_correct}/{len(test_cases)}')


solve()