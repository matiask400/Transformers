def max_increase_keeping_skyline(grid):
    """
    Calculates the maximum total sum that the height of the buildings can be increased
    without changing the skyline.

    Args:
        grid: A 2D array representing the height of buildings.

    Returns:
        The maximum total sum of the increase.
    """

    n = len(grid)
    row_maxes = [max(row) for row in grid]
    col_maxes = [max(grid[i][j] for i in range(n)) for j in range(n)]

    increase_sum = 0
    for i in range(n):
        for j in range(n):
            increase_sum += min(row_maxes[i], col_maxes[j]) - grid[i][j]

    return increase_sum


def test_max_increase_keeping_skyline():
    """
    Tests the max_increase_keeping_skyline function with several test cases.
    """

    test_cases = [
        {
            "grid": [[3, 0, 8, 4], [2, 4, 5, 7], [9, 2, 6, 3], [0, 3, 1, 0]],
            "expected_output": 35,
        },
        {
            "grid": [[0, 0, 0], [0, 0, 0], [0, 0, 0]],
            "expected_output": 0,
        },
        {
            "grid": [[1, 2], [3, 4]],
            "expected_output": 0,
        },
        {
            "grid": [[5, 4, 3], [2, 1, 0], [6, 7, 8]],
            "expected_output": 21,
        },
    ]

    num_tests = len(test_cases)
    num_correct = 0

    for i, test_case in enumerate(test_cases):
        grid = test_case["grid"]
        expected_output = test_case["expected_output"]
        actual_output = max_increase_keeping_skyline(grid)

        if actual_output == expected_output:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {grid}")
            print(f"  Expected: {expected_output}")
            print(f"  Actual: {actual_output}")

    print(f"\nCorrect: {num_correct} / {num_tests}")


if __name__ == "__main__":
    test_max_increase_keeping_skyline()