from collections import deque

def sliding_puzzle(board):
    """
    Solves the sliding puzzle problem.

    Args:
        board: A 2x3 list of lists representing the puzzle board.

    Returns:
        The least number of moves required to solve the puzzle, or -1 if it is impossible.
    """

    def board_to_tuple(board):
        return tuple(board[0] + board[1])

    def tuple_to_board(board_tuple):
        return [list(board_tuple[:3]), list(board_tuple[3:])]

    def get_neighbors(board_tuple):
        board = tuple_to_board(board_tuple)
        zero_index = board[0].index(0) if 0 in board[0] else board[1].index(0) + 3
        row = zero_index // 3
        col = zero_index % 3
        neighbors = []

        # Possible moves (up, down, left, right)
        moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]

        for dr, dc in moves:
            new_row = row + dr
            new_col = col + dc

            if 0 <= new_row < 2 and 0 <= new_col < 3:
                new_index = new_row * 3 + new_col
                new_board = list(board_tuple)
                new_board[zero_index], new_board[new_index] = new_board[new_index], new_board[zero_index]
                neighbors.append(tuple(new_board))

        return neighbors

    start_state = board_to_tuple(board)
    target_state = (1, 2, 3, 4, 5, 0)

    if start_state == target_state:
        return 0

    queue = deque([(start_state, 0)])
    visited = {start_state}

    while queue:
        current_state, moves = queue.popleft()

        for neighbor in get_neighbors(current_state):
            if neighbor == target_state:
                return moves + 1

            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, moves + 1))

    return -1


def test_sliding_puzzle():
    tests = [
        ([[1, 2, 3], [4, 0, 5]], 1),
        ([[1, 2, 3], [5, 4, 0]], -1),
        ([[4, 1, 2], [5, 0, 3]], 5),
        ([[3, 2, 4], [1, 5, 0]], 14),
        ([[1,2,3],[4,5,0]], 0),
        ([[0, 1, 2], [3, 4, 5]], -1),
        ([[1, 0, 2], [3, 4, 5]], -1)

    ]

    correct_count = 0
    total_tests = len(tests)

    for i, (board, expected) in enumerate(tests):
        result = sliding_puzzle(board)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False (Expected {expected}, got {result})")

    print(f"\n{correct_count}/{total_tests}")

test_sliding_puzzle()