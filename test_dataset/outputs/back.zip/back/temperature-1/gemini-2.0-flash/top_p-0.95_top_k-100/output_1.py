def count_prime_set_bits(L, R):
    def is_prime(n):
        if n <= 1:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True

    def count_set_bits(n):
        count = 0
        while n > 0:
            n &= (n - 1)
            count += 1
        return count

    count = 0
    for i in range(L, R + 1):
        set_bits = count_set_bits(i)
        if is_prime(set_bits):
            count += 1
    return count

def test_count_prime_set_bits():
    test_cases = [
        ((6, 10), 4),
        ((10, 15), 5),
        ((1, 10), 4),
        ((1, 1), 0),
        ((2, 2), 1),
        ((3, 3), 1),
        ((4, 4), 0),
        ((5, 5), 0),
        ((6, 6), 1),
        ((7, 7), 1),
        ((8, 8), 0),
        ((9, 9), 1),
        ((10, 10), 1),
        ((100,120), 12),
        ((1, 10000), 3338),
        ((1, 100), 35)
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, (args, expected) in enumerate(test_cases):
        result = count_prime_set_bits(*args)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {args}")
            print(f"  Expected: {expected}")
            print(f"  Got: {result}")

    print(f"\n{correct_count}/{total_tests} tests passed")


if __name__ == "__main__":
    test_count_prime_set_bits()