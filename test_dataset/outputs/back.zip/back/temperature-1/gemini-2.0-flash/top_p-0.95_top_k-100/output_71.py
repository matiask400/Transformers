def canReorderDoubled(arr):
    """
    Given an array of integers `arr` of even length, return `true` if and only if it is possible to reorder it such that `arr[2 * i + 1] = 2 * arr[2 * i]` for every `0 <= i < len(arr) / 2`.

    Args:
        arr (list[int]): A list of integers.

    Returns:
        bool: True if it is possible to reorder the array as described, False otherwise.
    """
    from collections import Counter
    count = Counter(arr)

    for x in sorted(count, key=abs):
        if count[x] > 0:
            if count[2 * x] < count[x]:
                return False
            count[2 * x] -= count[x]
    return True

def test_canReorderDoubled():
    test_cases = [
        ([3,1,3,6], False),
        ([2,1,2,6], False),
        ([4,-2,2,-4], True),
        ([1,2,4,16,8,4], False),
        ([0,0,0,0], True),
        ([0,0], True),
        ([1,2], True),
        ([-1,-2], True),
        ([-2,-4], True),
        ([2,4], True),
        ([1,2,2,4], True),
        ([1,2,3,6], False),
        ([-1,2,4,-2,-4,1], True),
        ([-4,-2,2,-2,-3,8], False)

    ]
    num_correct = 0
    for i, (arr, expected) in enumerate(test_cases):
        result = canReorderDoubled(arr)
        if result == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
    print(f"{num_correct}/{len(test_cases)}")

if __name__ == "__main__":
    test_canReorderDoubled()