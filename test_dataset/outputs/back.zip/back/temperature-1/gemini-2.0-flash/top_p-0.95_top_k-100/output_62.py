def longest_subarray_with_k_flips(A, K):
    """
    Finds the length of the longest subarray with at most K flips.

    Args:
        A: A list of 0s and 1s.
        K: The maximum number of flips allowed.

    Returns:
        The length of the longest subarray containing only 1s after at most K flips.
    """
    window_start = 0
    max_length = 0
    flipped_count = 0
    for window_end in range(len(A)):
        if A[window_end] == 0:
            flipped_count += 1
        while flipped_count > K:
            if A[window_start] == 0:
                flipped_count -= 1
            window_start += 1
        max_length = max(max_length, window_end - window_start + 1)
    return max_length

def test_longest_subarray_with_k_flips():
    """
    Tests the longest_subarray_with_k_flips function with various test cases.
    """
    test_cases = [
        ([1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0], 2, 6),
        ([0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1], 3, 10),
        ([0, 0, 0, 0, 0], 2, 2),
        ([1, 1, 1, 1, 1], 0, 5),
        ([0, 0, 0, 1, 1, 1, 0, 0, 0], 2, 5),
        ([0], 0, 0),
        ([1], 0, 1),
        ([0], 1, 1)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for A, K, expected in test_cases:
        result = longest_subarray_with_k_flips(A, K)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")
            print(f"Input: A={A}, K={K}")
            print(f"Expected: {expected}, Got: {result}")
    print(f"{correct_count}/{total_count}")
test_longest_subarray_with_k_flips()