import re
from collections import Counter

def mostCommonWord(paragraph, banned):
    words = re.findall(r'\b\w+\b', paragraph.lower())
    count = Counter(w for w in words if w not in banned)
    return count.most_common(1)[0][0]

def test_mostCommonWord():
    test_cases = [
        {
            "paragraph": "Bob hit a ball, the hit BALL flew far after it was hit.",
            "banned": ["hit"],
            "expected": "ball"
        },
        {
            "paragraph": "a.",
            "banned": [],
            "expected": "a"
        },
        {
            "paragraph": "a, a, a, a, b,b,b,c, c",
            "banned": ["a"],
            "expected": "b"
        }
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        paragraph = test_case["paragraph"]
        banned = test_case["banned"]
        expected = test_case["expected"]
        
        result = mostCommonWord(paragraph, banned)
        
        if result == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Expected: {expected}")
            print(f"  Got: {result}")

    print(f"\n{num_correct}/{total_tests} correct")

if __name__ == "__main__":
    test_mostCommonWord()