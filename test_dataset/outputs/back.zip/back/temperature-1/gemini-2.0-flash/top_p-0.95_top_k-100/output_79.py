def get_smallest_string(n: int, k: int) -> str:
    """
    Given two integers n and k, return the lexicographically smallest string with length equal to n and numeric value equal to k.

    Args:
        n: The length of the string.
        k: The numeric value of the string.

    Returns:
        The lexicographically smallest string with length equal to n and numeric value equal to k.
    """
    result = ['a'] * n
    k -= n
    for i in range(n - 1, -1, -1):
        if k == 0:
            break
        value = min(k, 25)
        result[i] = chr(ord('a') + value)
        k -= value
    return ''.join(result)

def test_get_smallest_string():
    tests = [
        {"n": 3, "k": 27, "expected": "aay"},
        {"n": 5, "k": 73, "expected": "aaszz"},
        {"n": 1, "k": 1, "expected": "a"},
        {"n": 1, "k": 26, "expected": "z"},
        {"n": 2, "k": 2, "expected": "aa"},
        {"n": 2, "k": 52, "expected": "zz"},
        {"n": 4, "k": 60, "expected": "aaaz"},
        {"n": 10, "k": 260, "expected": "zzzzzzzzzz"},
        {"n": 10, "k": 10, "expected": "aaaaaaaaaa"},
        {"n": 5, "k": 130, "expected": "zzzzz"},
        {"n": 5, "k": 5, "expected": "aaaaa"}
    ]

    correct_tests = 0
    total_tests = len(tests)

    for test in tests:
        n = test["n"]
        k = test["k"]
        expected = test["expected"]
        actual = get_smallest_string(n, k)

        if actual == expected:
            print("True")
            correct_tests += 1
        else:
            print("False")

    print(f"{correct_tests}/{total_tests}")

if __name__ == '__main__':
    test_get_smallest_string()