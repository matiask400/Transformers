import heapq

def getSkyline(buildings):
    """
    :type buildings: List[List[int]]
    :rtype: List[List[int]]
    """
    events = []
    for l, r, h in buildings:
        events.append((l, -h, r))  # Start event, negative height
        events.append((r, 0, 0))  # End event, height 0

    events.sort()

    skyline = []
    live_buildings = [(0, float('inf'))]  # (height, right)
    heapq.heapify(live_buildings)
    current_height = 0

    for x, neg_h, r in events:
        # Add new buildings to the heap
        while live_buildings and live_buildings[0][1] <= x:
            heapq.heappop(live_buildings)

        if neg_h != 0:
            heapq.heappush(live_buildings, (neg_h, r))

        # Check if the current height has changed
        max_height = -live_buildings[0][0]
        if max_height != current_height:
            current_height = max_height
            skyline.append([x, current_height])

    # Remove consecutive horizontal lines of equal height
    result = []
    for i in range(len(skyline)):
        if i == 0 or skyline[i][1] != skyline[i - 1][1]:
            result.append(skyline[i])

    return result

def test_getSkyline():
    test_cases = [
        {
            "input": [[2,9,10],[3,7,15],[5,12,12],[15,20,10],[19,24,8]],
            "expected": [[2,10],[3,15],[7,12],[12,0],[15,10],[20,8],[24,0]]
        },
        {
            "input": [[0,2,3],[2,5,3]],
            "expected": [[0,3],[5,0]]
        },
        {
            "input": [[1,2,1],[1,2,2],[1,2,3]],
            "expected": [[1,3],[2,0]]
        },
        {
            "input": [[1,5,3],[1,5,3],[1,5,3]],
            "expected": [[1,3],[5,0]]
        },
        {
            "input": [[0,2,3],[1,4,5],[3,6,2]],
            "expected": [[0,3],[1,5],[4,2],[6,0]]
        },
        {
            "input": [],
            "expected": []
        }
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        buildings = test_case["input"]
        expected = test_case["expected"]
        actual = getSkyline(buildings)
        if actual == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {buildings}")
            print(f"  Expected: {expected}")
            print(f"  Actual: {actual}")

    print(f"\n{num_correct}/{total_tests} correct")

if __name__ == "__main__":
    test_getSkyline()