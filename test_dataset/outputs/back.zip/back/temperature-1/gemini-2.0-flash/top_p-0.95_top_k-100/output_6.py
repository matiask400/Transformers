def reconstruct_matrix(upper, lower, colsum):
    n = len(colsum)
    matrix = [[0] * n for _ in range(2)]
    
    for i in range(n):
        if colsum[i] == 2:
            matrix[0][i] = 1
            matrix[1][i] = 1
            upper -= 1
            lower -= 1
        elif colsum[i] == 1:
            if upper > lower:
                matrix[0][i] = 1
                upper -= 1
            else:
                matrix[1][i] = 1
                lower -= 1
                
    if upper < 0 or lower < 0 or upper + lower != 0:
        return []
    
    return matrix

def test_reconstruct_matrix():
    test_cases = [
        (2, 1, [1,1,1], [[1,1,0],[0,0,1]]),
        (2, 3, [2,2,1,1], []),
        (5, 5, [2,1,2,0,1,0,1,2,0,1], [[1,1,1,0,1,0,0,1,0,0],[1,0,1,0,0,0,1,1,0,1]]),
        (2, 2, [2,2], [[1,1],[1,1]]),
        (0, 0, [0,0], [[0,0],[0,0]]),
        (1, 0, [1,0], [[1,0],[0,0]]),
        (0, 1, [0,1], [[0,0],[0,1]]),
        (1, 1, [1,1], [[1,0],[0,1]]),
        (3, 2, [1,1,2,1], [[1,0,1,1],[0,1,1,0]]),
        (2, 3, [1,1,2,1], [[0,1,1,0],[1,0,1,1]])
    ]
    
    correct_count = 0
    total_count = len(test_cases)
    
    for upper, lower, colsum, expected in test_cases:
        result = reconstruct_matrix(upper, lower, colsum)
        
        def matrix_equal(m1, m2):
            if not m1 and not m2:
                return True
            if not m1 or not m2 or len(m1) != len(m2) or len(m1[0]) != len(m2[0]):
                return False
            for i in range(len(m1)):
                for j in range(len(m1[0])):
                    if m1[i][j] != m2[i][j]:
                        return False
            return True
        
        
        if result == [] and expected == []:
            print("True")
            correct_count += 1
        elif result != [] and expected != []:
            
            def validate_result(res, upper, lower, colsum):
                if len(res) != 2 or len(res[0]) != len(colsum):
                    return False

                upper_sum = sum(res[0])
                lower_sum = sum(res[1])

                if upper_sum != upper or lower_sum != lower:
                    return False

                for i in range(len(colsum)):
                    if res[0][i] + res[1][i] != colsum[i]:
                        return False
                return True

            if validate_result(result, upper, lower, colsum):
                  print("True")
                  correct_count += 1
            else:
                print("False")
        
        else:
            print("False")
    
    print(f"{correct_count}/{total_count}")

test_reconstruct_matrix()