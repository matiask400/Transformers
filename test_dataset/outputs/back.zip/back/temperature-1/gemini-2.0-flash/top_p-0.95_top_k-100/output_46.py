def sort_array_by_parity(A):
    """
    Given an array A of non-negative integers, return an array consisting of all the even elements of A, followed by all the odd elements of A.

    You may return any answer array that satisfies this condition.
    """
    even_nums = []
    odd_nums = []
    for num in A:
        if num % 2 == 0:
            even_nums.append(num)
        else:
            odd_nums.append(num)
    return even_nums + odd_nums

def test_sort_array_by_parity():
    test_cases = [
        ([3, 1, 2, 4], [2, 4, 3, 1]),
        ([0, 1, 2], [0, 2, 1]),
        ([1, 3, 5], [1, 3, 5]),
        ([2, 4, 6], [2, 4, 6]),
        ([0], [0]),
        ([1], [1]),
        ([], []),
        ([1, 0, 3, 2, 5, 4], [0, 2, 4, 1, 3, 5])
    ]

    correct_count = 0
    total_count = len(test_cases)

    for input_array, expected_output in test_cases:
        actual_output = sort_array_by_parity(input_array)
        
        # Check if the lengths are the same first to avoid errors when comparing.
        if len(actual_output) != len(input_array):
            print("False")
            continue

        even_part_expected = [x for x in expected_output if x % 2 == 0]
        odd_part_expected = [x for x in expected_output if x % 2 != 0]

        even_part_actual = [x for x in actual_output if x % 2 == 0]
        odd_part_actual = [x for x in actual_output if x % 2 != 0]
        
        if sorted(even_part_actual) == sorted(even_part_expected) and sorted(odd_part_actual) == sorted(odd_part_expected):
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_sort_array_by_parity()