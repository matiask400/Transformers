class TreeNode:
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

def distanceK(root, target, K):
    """
    Finds all nodes that are a distance K from the target node in a binary tree.

    Args:
        root: The root node of the binary tree.
        target: The target node in the binary tree.
        K: The distance from the target node.

    Returns:
        A list of the values of all nodes that have a distance K from the target node.
    """

    adj = {}

    def build_graph(node, parent):
        if node:
            if node.val not in adj:
                adj[node.val] = []
            if parent:
                if parent.val not in adj:
                    adj[parent.val] = []
                adj[node.val].append(parent.val)
                adj[parent.val].append(node.val)
            build_graph(node.left, node)
            build_graph(node.right, node)

    build_graph(root, None)

    q = [(target.val, 0)]
    visited = {target.val}
    result = []

    while q:
        node, dist = q.pop(0)
        if dist == K:
            result.append(node)
        else:
            for neighbor in adj.get(node, []):
                if neighbor not in visited:
                    q.append((neighbor, dist + 1))
                    visited.add(neighbor)

    return result

def test_distanceK():
    """
    Tests the distanceK function with several test cases.
    """

    def create_tree(nodes, i=0):
        if i >= len(nodes) or nodes[i] is None:
            return None
        root = TreeNode(nodes[i])
        root.left = create_tree(nodes, 2 * i + 1)
        root.right = create_tree(nodes, 2 * i + 2)
        return root

    def find_node(root, target_val):
        if not root:
            return None
        if root.val == target_val:
            return root
        left_search = find_node(root.left, target_val)
        if left_search:
            return left_search
        return find_node(root.right, target_val)

    test_cases = [
        ([3, 5, 1, 6, 2, 0, 8, None, None, 7, 4], 5, 2, [7, 4, 1]),
        ([0, 1, None, None, 2, None, 3, None, 4], 2, 3, [0]),
        ([0, 2, 1, None, None, 3], 3, 3, [2]),
        ([1], 1, 3, []),
        ([0, 1, 3, None, 2], 2, 1, [1]),
        ([0, 1, None, None, 2, None, 3, None, 4], 0, 4, [4]),
        ([0, 1, None, None, 2, None, 3, None, 4], 4, 0, [4]),
        ([0, 1, None, None, 2, None, 3, None, 4], 4, 1, [3]),
        ([0, 1, None, None, 2, None, 3, None, 4], 4, 2, [2]),
        ([0, 1, None, None, 2, None, 3, None, 4], 4, 3, [1]),
        ([0, 1, None, None, 2, None, 3, None, 4], 4, 4, [0]),
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, (tree_nodes, target_val, K, expected) in enumerate(test_cases):
        root = create_tree(tree_nodes)
        target = find_node(root, target_val)
        result = distanceK(root, target, K)
        result.sort()
        expected.sort()
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: root={tree_nodes}, target={target_val}, K={K}")
            print(f"  Expected: {expected}")
            print(f"  Got: {result}")

    print(f"\nCorrect: {correct_count}/{total_count}")

if __name__ == "__main__":
    test_distanceK()