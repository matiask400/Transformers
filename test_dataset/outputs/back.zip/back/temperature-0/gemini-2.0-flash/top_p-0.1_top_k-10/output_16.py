def solve():
    def max_four_person_groups(n, reservedSeats):
        """
        Calculates the maximum number of four-person groups that can be assigned in a cinema.

        Args:
            n: The number of rows in the cinema.
            reservedSeats: A list of reserved seats, where each seat is represented as [row, seat_number].

        Returns:
            The maximum number of four-person groups that can be assigned.
        """

        reserved_rows = {}
        for row, seat in reservedSeats:
            if row not in reserved_rows:
                reserved_rows[row] = set()
            reserved_rows[row].add(seat)

        count = 0
        for row in reserved_rows:
            row_seats = reserved_rows[row]
            
            # Check for groups in the left section (2-5)
            if all(seat not in row_seats for seat in range(2, 6)):
                count += 1
                # Mark seats as used (optional, but can prevent double-counting if needed)
                # for seat in range(2, 6):
                #     row_seats.add(seat)
            
            # Check for groups in the middle section (4-7)
            if all(seat not in row_seats for seat in range(4, 8)):
                count += 1
                # for seat in range(4, 8):
                #     row_seats.add(seat)
            
            # Check for groups in the right section (6-9)
            if all(seat not in row_seats for seat in range(6, 10)):
                count += 1
                # for seat in range(6, 10):
                #     row_seats.add(seat)
        
        # Calculate the number of rows without any reservations
        unreserved_rows = n - len(reserved_rows)
        count += unreserved_rows * 2

        return count

    # Test cases
    test_cases = [
        (3, [[1, 2], [1, 3], [1, 8], [2, 6], [3, 1], [3, 10]], 4),
        (2, [[2, 1], [1, 8], [2, 6]], 2),
        (4, [[4, 3], [1, 4], [4, 6], [1, 7]], 4),
        (1, [], 2),
        (1, [[1,1],[1,2],[1,3],[1,4],[1,5],[1,6],[1,7],[1,8],[1,9],[1,10]], 0),
        (1, [[1,2],[1,3],[1,4],[1,5]], 1),
        (1, [[1,6],[1,7],[1,8],[1,9]], 1),
        (1, [[1,4],[1,5],[1,6],[1,7]], 1),
        (2, [[1,2],[1,3],[1,4],[1,5],[2,6],[2,7],[2,8],[2,9]], 0),
        (2, [[1,2],[1,3],[1,4],[1,5]], 2),
        (2, [[1,6],[1,7],[1,8],[1,9]], 2),
        (2, [[1,4],[1,5],[1,6],[1,7]], 2),
        (2, [[1,1],[1,2],[1,3],[1,4],[1,5],[1,6],[1,7],[1,8],[1,9],[1,10],[2,1],[2,2],[2,3],[2,4],[2,5],[2,6],[2,7],[2,8],[2,9],[2,10]], 0),
        (10, [], 20),
        (10, [[1,1],[1,2],[1,3],[1,4],[1,5],[1,6],[1,7],[1,8],[1,9],[1,10],[2,1],[2,2],[2,3],[2,4],[2,5],[2,6],[2,7],[2,8],[2,9],[2,10],[3,1],[3,2],[3,3],[3,4],[3,5],[3,6],[3,7],[3,8],[3,9],[3,10],[4,1],[4,2],[4,3],[4,4],[4,5],[4,6],[4,7],[4,8],[4,9],[4,10],[5,1],[5,2],[5,3],[5,4],[5,5],[5,6],[5,7],[5,8],[5,9],[5,10],[6,1],[6,2],[6,3],[6,4],[6,5],[6,6],[6,7],[6,8],[6,9],[6,10],[7,1],[7,2],[7,3],[7,4],[7,5],[7,6],[7,7],[7,8],[7,9],[7,10],[8,1],[8,2],[8,3],[8,4],[8,5],[8,6],[8,7],[8,8],[8,9],[8,10],[9,1],[9,2],[9,3],[9,4],[9,5],[9,6],[9,7],[9,8],[9,9],[9,10],[10,1],[10,2],[10,3],[10,4],[10,5],[10,6],[10,7],[10,8],[10,9],[10,10]], 0)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for n, reservedSeats, expected in test_cases:
        result = max_four_person_groups(n, reservedSeats)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")
            print(f"Input: n={n}, reservedSeats={reservedSeats}")
            print(f"Expected: {expected}, Got: {result}")

    print(f"{correct_count}/{total_count}")

solve()