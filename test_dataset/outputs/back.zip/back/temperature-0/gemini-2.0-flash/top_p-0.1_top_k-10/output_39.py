def shortest_encoding(words):
    """
    Calculates the length of the shortest reference string possible of any valid encoding of words.

    Args:
        words: A list of strings.

    Returns:
        The length of the shortest reference string.
    """
    words = list(set(words))  # Remove duplicates
    words.sort(key=len, reverse=True)  # Sort by length in descending order
    s = ""
    for word in words:
        if word + "#" not in s:
            s += word + "#"
    return len(s)

def test_shortest_encoding():
    """
    Tests the shortest_encoding function with several test cases.
    """
    test_cases = [
        (["time", "me", "bell"], 10),
        (["t"], 2),
        (["me", "time"], 5),
        (["time", "me", "time"], 5),
        (["time", "me", "bell", "time"], 10),
        (["time", "me", "bell", "time", "me"], 10),
        (["time", "me", "bell", "time", "me", "bell"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me"], 10),
        (["time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell", "time", "me", "bell"], 10),
        (["feffee", "effe", "ee"], 10),
        (["time", "atime"], 5),
        (["atime", "time"], 6),
        (["time", "btime"], 11),
        (["btime", "time"], 11),
        (["time", "time"], 5),
        (["time", "time", "time"], 5),
        (["time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
        (["time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time", "time"], 5),
    ]

    correct_count = 0
    total_count = len(test_cases)

    for words, expected in test_cases:
        result = shortest_encoding(words)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")
            print(f"Input: {words}, Expected: {expected}, Got: {result}")

    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_shortest_encoding()