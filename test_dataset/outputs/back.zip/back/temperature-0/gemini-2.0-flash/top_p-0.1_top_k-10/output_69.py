import subprocess

def test_word_frequency_script(script_content, input_file_content, expected_output):
    """
    Tests a bash script that calculates word frequencies in a text file.

    Args:
        script_content: The content of the bash script as a string.
        input_file_content: The content of the input file "words.txt" as a string.
        expected_output: The expected output of the script as a string.

    Returns:
        True if the script's output matches the expected output, False otherwise.
    """

    try:
        # Create a temporary file for the script
        with open("temp_script.sh", "w") as f:
            f.write(script_content)
        subprocess.run(["chmod", "+x", "temp_script.sh"])

        # Create a temporary file for the input
        with open("words.txt", "w") as f:
            f.write(input_file_content)

        # Execute the script and capture the output
        result = subprocess.run(["./temp_script.sh"], capture_output=True, text=True)
        actual_output = result.stdout.strip()

        # Compare the actual output with the expected output
        return actual_output == expected_output

    except Exception as e:
        print(f"Error during execution: {e}")
        return False
    finally:
        # Clean up temporary files
        try:
            subprocess.run(["rm", "temp_script.sh", "words.txt"])
        except FileNotFoundError:
            pass  # Ignore if files don't exist


def run_tests():
    """
    Runs a series of tests for the word frequency script.
    """

    script_content = """
    #!/bin/bash
    tr -s ' ' '\\n' < words.txt | sort | uniq -c | sort -nr | awk '{print $2, $1}'
    """

    tests = [
        {
            "input": "the day is sunny the the\nthe sunny is is",
            "expected": "the 4\nis 3\nsunny 2\nday 1"
        },
        {
            "input": "one two three\ntwo three four\nthree four five",
            "expected": "three 3\ntwo 2\none 1\nfour 2\nfive 1" # Order doesn't matter as long as frequencies are correct
        },
        {
            "input": "apple banana apple orange banana apple",
            "expected": "apple 3\nbanana 2\norange 1"
        },
        {
            "input": "a a a a a",
            "expected": "a 5"
        },
        {
            "input": "  a   b  c   ",
            "expected": "a 1\nb 1\nc 1"
        }
    ]

    num_correct = 0
    total_tests = len(tests)

    for i, test in enumerate(tests):
        result = test_word_frequency_script(script_content, test["input"], test["expected"])
        print(f"Test {i+1}: {result}")
        if result:
            num_correct += 1

    print(f"\nCorrect: {num_correct}/{total_tests}")


if __name__ == "__main__":
    run_tests()