def can_cross(stones):
    """
    Determines if the frog can cross the river by landing on the last stone.

    Args:
        stones: A list of stones' positions (in units) in sorted ascending order.

    Returns:
        True if the frog can cross the river, False otherwise.
    """

    n = len(stones)
    if n <= 1:
        return True

    stone_positions = set(stones)
    possible_jumps = {0: {0}}  # {stone_index: {possible_jump_sizes}}

    for i in range(n):
        if i in possible_jumps:
            for k in possible_jumps[i]:
                for jump in [k - 1, k, k + 1]:
                    if jump > 0 and stones[i] + jump in stone_positions:
                        next_stone = stones[i] + jump
                        next_stone_index = stones.index(next_stone)
                        if next_stone_index not in possible_jumps:
                            possible_jumps[next_stone_index] = set()
                        possible_jumps[next_stone_index].add(jump)

    return n - 1 in possible_jumps


def test_can_cross():
    """
    Tests the can_cross function with several test cases.
    """

    test_cases = [
        ([0, 1, 3, 5, 6, 8, 12, 17], True),
        ([0, 1, 2, 3, 4, 8, 9, 11], False),
        ([0, 1], True),
        ([0, 2], False),
        ([0, 1, 3, 6, 10, 15], False),
        ([0, 1, 2, 3, 5, 6, 8, 12, 17], True),
        ([0, 1, 2, 3, 5, 6, 7, 9, 13, 17], True),
        ([0, 1, 2, 3, 5, 6, 7, 9, 13, 18], False),
        ([0, 1, 2, 3, 5, 6, 7, 9, 13, 17, 22], True),
        ([0, 1, 2, 3, 5, 6, 7, 9, 13, 17, 23], False),
        ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], True),
        ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 21], False),
        ([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200], True)
    ]

    correct_count = 0
    total_count = len(test_cases)

    for stones, expected in test_cases:
        result = can_cross(stones)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")

    print(f"{correct_count}/{total_count}")


if __name__ == "__main__":
    test_can_cross()