def matrix_rank_transform(matrix):
    """
    Given an m x n matrix, return a new matrix answer where answer[row][col] is the rank of matrix[row][col].

    The rank is an integer that represents how large an element is compared to other elements. It is calculated using the following rules:
    The rank is an integer starting from 1.

    If two elements p and q are in the same row or column, then:

    If p < q then rank(p) < rank(q)
    If p == q then rank(p) == rank(q)
    If p > q then rank(p) > rank(q)
    The rank should be as small as possible.

    It is guaranteed that answer is unique under the given rules.
    """
    m, n = len(matrix), len(matrix[0])
    ranks = [0] * (m + n)
    indices = sorted([(matrix[i][j], i, j) for i in range(m) for j in range(n)])
    
    def find(x):
        if parent[x] != x:
            parent[x] = find(parent[x])
        return parent[x]
    
    def union(x, y):
        rootX = find(x)
        rootY = find(y)
        if rootX != rootY:
            parent[rootX] = rootY
    
    ans = [[0] * n for _ in range(m)]
    
    i = 0
    while i < len(indices):
        j = i
        group = []
        while j < len(indices) and indices[i][0] == indices[j][0]:
            _, row, col = indices[j]
            group.append((row, col))
            j += 1
        
        parent = list(range(m + n))
        row_ranks = ranks[:m]
        col_ranks = ranks[m:]
        
        for row, col in group:
            union(row, col + m)
        
        rank_for_group = {}
        for row, col in group:
            root = find(row)
            rank_for_group[root] = max(row_ranks[row], col_ranks[col])
        
        for row, col in group:
            root = find(row)
            rank = rank_for_group[root] + 1
            ans[row][col] = rank
            ranks[row] = max(ranks[row], rank)
            ranks[col + m] = max(ranks[col + m], rank)
        
        i = j
    
    return ans

def test_matrix_rank_transform():
    test_cases = [
        ([[1, 2], [3, 4]], [[1, 2], [2, 3]]),
        ([[7, 7], [7, 7]], [[1, 1], [1, 1]]),
        ([[20, -21, 14], [-19, 4, 19], [22, -47, 24], [-19, 4, 19]], [[4, 2, 3], [1, 3, 4], [5, 1, 6], [1, 3, 4]]),
        ([[7, 3, 6], [1, 4, 5], [9, 8, 2]], [[5, 1, 4], [1, 2, 3], [6, 3, 1]])
    ]
    
    correct_count = 0
    total_count = len(test_cases)
    
    for matrix, expected in test_cases:
        result = matrix_rank_transform(matrix)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")
    
    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_matrix_rank_transform()