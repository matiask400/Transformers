class Node:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def treeToDoublyList(root):
    if not root:
        return None

    first = None
    last = None

    def inorder(node):
        nonlocal first, last
        if not node:
            return

        inorder(node.left)

        if last:
            last.right = node
            node.left = last
        else:
            first = node

        last = node

        inorder(node.right)

    inorder(root)

    last.right = first
    first.left = last

    return first

def test_treeToDoublyList():
    tests = []
    expected = []

    # Test Case 1
    root1 = Node(4, Node(2, Node(1), Node(3)), Node(5))
    tests.append(root1)
    expected.append([1, 2, 3, 4, 5])

    # Test Case 2
    root2 = Node(2, Node(1), Node(3))
    tests.append(root2)
    expected.append([1, 2, 3])

    # Test Case 3
    root3 = None
    tests.append(root3)
    expected.append([])

    # Test Case 4
    root4 = Node(1)
    tests.append(root4)
    expected.append([1])

    # Test Case 5
    root5 = Node(10, Node(5, Node(2), Node(7)), Node(15, Node(12), Node(17)))
    tests.append(root5)
    expected.append([2, 5, 7, 10, 12, 15, 17])

    num_correct = 0
    for i in range(len(tests)):
        root = tests[i]
        result_list = []
        head = treeToDoublyList(root)

        if not head:
            if not expected[i]:
                print("True")
                num_correct += 1
                continue
            else:
                print("False")
                continue

        curr = head
        result_list.append(curr.val)
        curr = curr.right
        while curr != head:
            result_list.append(curr.val)
            curr = curr.right

        if result_list == expected[i]:
            print("True")
            num_correct += 1
        else:
            print("False")

    print(f"{num_correct}/{len(tests)}")

if __name__ == "__main__":
    test_treeToDoublyList()