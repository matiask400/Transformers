def nextGreaterElement(nums1, nums2):
    """
    Finds the next greater numbers for nums1's elements in nums2.

    Args:
        nums1: An integer array of unique elements, a subset of nums2.
        nums2: An integer array of unique elements.

    Returns:
        A list of the next greater numbers for each element in nums1.
    """
    result = []
    for num1 in nums1:
        found = False
        for i in range(nums2.index(num1) + 1, len(nums2)):
            if nums2[i] > num1:
                result.append(nums2[i])
                found = True
                break
        if not found:
            result.append(-1)
    return result

def test_nextGreaterElement():
    """
    Tests the nextGreaterElement function with several test cases.
    """
    test_cases = [
        ([4, 1, 2], [1, 3, 4, 2], [-1, 3, -1]),
        ([2, 4], [1, 2, 3, 4], [3, -1]),
        ([1,3,5,2,4], [6,5,4,3,2,1,7], [7,7,7,7,7]),
        ([1,3,5,2,4], [5,4,3,2,1,6,7], [6,6,6,6,6]),
        ([1,3,5,2,4], [1,2,3,4,5], [2,4,-1,-1,5]),
        ([1,3,5,2,4], [5,4,3,2,1], [-1,-1,-1,-1,-1]),
        ([1], [1,2,3,4,5], [-1]),
        ([5], [1,2,3,4,5], [-1]),
        ([5], [5,4,3,2,1], [-1]),
        ([1,2,3], [1,2,3], [-1,-1,-1]),
        ([3,2,1], [1,2,3], [-1,-1,-1]),
        ([1,2,3], [3,2,1], [-1,-1,-1]),
        ([3,2,1], [3,2,1], [-1,-1,-1]),
        ([1,2,3], [1,2,3,4,5], [-1,-1,-1]),
        ([3,2,1], [1,2,3,4,5], [4,3,2]),
        ([1,2,3], [5,4,3,2,1], [-1,-1,-1]),
        ([3,2,1], [5,4,3,2,1], [-1,-1,-1]),
        ([1,2,3], [1,2,3,4,5,6,7,8,9,10], [-1,-1,-1]),
        ([3,2,1], [1,2,3,4,5,6,7,8,9,10], [4,3,2]),
        ([1,2,3], [10,9,8,7,6,5,4,3,2,1], [10,9,4]),
        ([3,2,1], [10,9,8,7,6,5,4,3,2,1], [4,3,2]),
        ([1,2,3], [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20], [-1,-1,-1]),
        ([3,2,1], [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20], [4,3,2]),
        ([1,2,3], [20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1], [20,19,4]),
        ([3,2,1], [20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1], [4,3,2]),
    ]

    correct_count = 0
    total_count = len(test_cases)

    for nums1, nums2, expected in test_cases:
        result = nextGreaterElement(nums1, nums2)
        if result == expected:
            print("True")
            correct_count += 1
        else:
            print("False")
            print(f"Input: nums1={nums1}, nums2={nums2}")
            print(f"Expected: {expected}, Got: {result}")

    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_nextGreaterElement()