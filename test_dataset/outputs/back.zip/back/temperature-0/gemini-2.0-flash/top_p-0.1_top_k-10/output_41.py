import heapq

def mincostToHireWorkers(quality, wage, K):
    N = len(quality)
    workers = []
    for i in range(N):
        workers.append((wage[i] / quality[i], quality[i]))
    workers.sort()
    
    heap = []
    quality_sum = 0
    min_cost = float('inf')
    
    for ratio, q in workers:
        heapq.heappush(heap, -q)
        quality_sum += q
        
        if len(heap) > K:
            quality_sum += heapq.heappop(heap)
        
        if len(heap) == K:
            min_cost = min(min_cost, ratio * quality_sum)
            
    return min_cost

def test_mincostToHireWorkers():
    test_cases = [
        (([10, 20, 5], [70, 50, 30], 2), 105.00000),
        (([3, 1, 10, 10, 1], [4, 8, 2, 2, 7], 3), 30.66667),
        (([4,5,6], [10,20,30], 3), 65.00000),
        (([3,1,10,10,1], [4,8,2,2,7], 4), 34.00000),
        (([1,2,3,4,5], [5,4,3,2,1], 3), 6.00000),
        (([1,2,3,4,5], [5,4,3,2,1], 1), 1.00000),
        (([1,2,3,4,5], [5,4,3,2,1], 5), 15.00000),
        (([10,20,5], [70,50,30], 1), 35.00000),
        (([10,20,5], [70,50,30], 3), 150.00000),
        (([25,68,35,95,25,30,71,34,46,80], [100,100,100,100,100,100,100,100,100,100], 6), 600.00000)
    ]
    
    correct_count = 0
    total_count = len(test_cases)
    
    for (quality, wage, K), expected in test_cases:
        result = mincostToHireWorkers(quality, wage, K)
        if abs(result - expected) < 1e-5:
            print("True")
            correct_count += 1
        else:
            print("False")
    
    print(f"{correct_count}/{total_count}")

test_mincostToHireWorkers()