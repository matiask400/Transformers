def hit_bricks(grid, hits):
    m = len(grid)
    n = len(grid[0])
    
    def is_valid(r, c):
        return 0 <= r < m and 0 <= c < n
    
    def dfs(r, c, visited):
        if not is_valid(r, c) or grid[r][c] != 1 or (r, c) in visited:
            return 0
        
        visited.add((r, c))
        
        count = 1
        count += dfs(r + 1, c, visited)
        count += dfs(r - 1, c, visited)
        count += dfs(r, c + 1, visited)
        count += dfs(r, c - 1, visited)
        
        return count
    
    # Mark hits as -1 temporarily
    for r, c in hits:
        if grid[r][c] == 1:
            grid[r][c] = -1
    
    # Make stable bricks as 1
    for c in range(n):
        if grid[0][c] == 1:
            dfs(0, c, set())
    
    result = []
    for r, c in reversed(hits):
        if grid[r][c] == -1:
            grid[r][c] = 1
            
            # Check if the brick is connected to the top or adjacent to a stable brick
            is_connected = False
            if r == 0:
                is_connected = True
            else:
                if is_valid(r + 1, c) and grid[r + 1][c] == 1:
                    is_connected = True
                if is_valid(r - 1, c) and grid[r - 1][c] == 1:
                    is_connected = True
                if is_valid(r, c + 1) and grid[r][c + 1] == 1:
                    is_connected = True
                if is_valid(r, c - 1) and grid[r][c - 1] == 1:
                    is_connected = True
            
            if is_connected:
                visited = set()
                fallen_bricks = dfs(r, c, visited) - 1  # Subtract the current brick
                result.append(fallen_bricks)
            else:
                grid[r][c] = 0
                result.append(0)
        else:
            result.append(0)
    
    result.reverse()
    return result

def test_hit_bricks():
    test_cases = [
        {
            "grid": [[1,0,0,0],[1,1,1,0]],
            "hits": [[1,0]],
            "expected": [2]
        },
        {
            "grid": [[1,0,0,0],[1,1,0,0]],
            "hits": [[1,1],[1,0]],
            "expected": [0,0]
        },
        {
            "grid": [[1,1,1],[0,1,0],[0,0,0]],
            "hits": [[0,2],[2,0],[0,0]],
            "expected": [0,0,1]
        },
        {
            "grid": [[1,1,1],[1,1,1],[1,1,1]],
            "hits": [[1,1],[0,1]],
            "expected": [0,0]
        },
        {
            "grid": [[1,0],[1,1]],
            "hits": [[0,0],[0,1],[1,0]],
            "expected": [0,0,0]
        }
    ]
    
    num_correct = 0
    total_tests = len(test_cases)
    
    for i, test_case in enumerate(test_cases):
        grid = [row[:] for row in test_case["grid"]]  # Create a deep copy
        hits = test_case["hits"]
        expected = test_case["expected"]
        
        result = hit_bricks(grid, hits)
        
        if result == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: grid={test_case['grid']}, hits={hits}")
            print(f"  Expected: {expected}")
            print(f"  Got: {result}")
    
    print(f"\nCorrect: {num_correct}/{total_tests}")

if __name__ == "__main__":
    test_hit_bricks()