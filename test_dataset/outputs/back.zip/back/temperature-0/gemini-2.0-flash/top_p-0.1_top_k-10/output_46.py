def sort_array_by_parity(A):
    """
    Given an array A of non-negative integers, return an array consisting of all the even elements of A, followed by all the odd elements of A.

    You may return any answer array that satisfies this condition.

    Example 1:
    Input: [3,1,2,4]
    Output: [2,4,3,1]
    The outputs [4,2,3,1], [2,4,1,3], and [4,2,1,3] would also be accepted.

    Note:
    1 <= A.length <= 5000
    0 <= A[i] <= 5000
    """
    even = []
    odd = []
    for num in A:
        if num % 2 == 0:
            even.append(num)
        else:
            odd.append(num)
    return even + odd

def test_sort_array_by_parity():
    test_cases = [
        ([3, 1, 2, 4], [2, 4, 3, 1]),
        ([0, 1, 2], [0, 2, 1]),
        ([1, 3, 5], [1, 3, 5]),
        ([2, 4, 6], [2, 4, 6]),
        ([0], [0]),
        ([1], [1]),
        ([4, 1, 3, 2, 5], [4, 2, 1, 3, 5]),
        ([1, 0, 3, 2, 4], [0, 2, 4, 1, 3])
    ]

    correct_count = 0
    total_count = len(test_cases)

    for input_array, expected_output in test_cases:
        result = sort_array_by_parity(input_array)
        
        even_result = [x for x in result if x % 2 == 0]
        odd_result = [x for x in result if x % 2 != 0]
        
        even_expected = [x for x in expected_output if x % 2 == 0]
        odd_expected = [x for x in expected_output if x % 2 != 0]
        
        if even_result == [x for x in result if x % 2 == 0] and odd_result == [x for x in result if x % 2 != 0] and len(even_result) + len(odd_result) == len(result):
            
            even_input = [x for x in input_array if x % 2 == 0]
            odd_input = [x for x in input_array if x % 2 != 0]
            
            if len(even_result) == len(even_input) and len(odd_result) == len(odd_input):
                
                is_correct = True
                
                even_index = 0
                odd_index = 0
                
                for num in result:
                    if num % 2 == 0:
                        if num not in [x for x in input_array if x % 2 == 0]:
                            is_correct = False
                            break
                        even_index += 1
                    else:
                        if num not in [x for x in input_array if x % 2 != 0]:
                            is_correct = False
                            break
                        odd_index += 1
                
                if is_correct:
                    print("True")
                    correct_count += 1
                else:
                    print("False")
            else:
                print("False")
        else:
            print("False")

    print(f"{correct_count}/{total_count}")

if __name__ == "__main__":
    test_sort_array_by_parity()