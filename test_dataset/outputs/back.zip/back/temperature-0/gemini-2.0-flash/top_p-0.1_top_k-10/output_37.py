def solve():
    def subarray_sum(nums, n, left, right):
        subarray_sums = []
        for i in range(n):
            current_sum = 0
            for j in range(i, n):
                current_sum += nums[j]
                subarray_sums.append(current_sum)
        
        subarray_sums.sort()
        
        total_sum = 0
        for i in range(left - 1, right):
            total_sum = (total_sum + subarray_sums[i]) % (10**9 + 7)
        
        return total_sum

    def test_cases():
        test_data = [
            ([1,2,3,4], 4, 1, 5, 13),
            ([1,2,3,4], 4, 3, 4, 6),
            ([1,2,3,4], 4, 1, 10, 50),
            ([4,5,6], 3, 1, 3, 19),
            ([4,5,6], 3, 4, 6, 26),
            ([1,1,1], 3, 1, 6, 13)
        ]

        num_correct = 0
        total_tests = len(test_data)

        for nums, n, left, right, expected in test_data:
            result = subarray_sum(nums, n, left, right)
            if result == expected:
                print("True")
                num_correct += 1
            else:
                print("False")
        
        print(f"{num_correct}/{total_tests}")

    test_cases()

solve()