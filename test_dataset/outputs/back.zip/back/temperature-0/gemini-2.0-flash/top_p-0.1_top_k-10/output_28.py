import re
from collections import Counter

def mostCommonWord(paragraph, banned):
    """
    Given a string `paragraph` and a string array of the banned words `banned`,
    return the most frequent word that is not banned.
    It is guaranteed there is at least one word that is not banned, and that the answer is unique.

    The words in `paragraph` are case-insensitive and the answer should be returned in lowercase.
    """
    words = re.findall(r'\b\w+\b', paragraph.lower())
    count = Counter(w for w in words if w not in banned)
    return count.most_common(1)[0][0]

def test_mostCommonWord():
    test_cases = [
        {
            "paragraph": "Bob hit a ball, the hit BALL flew far after it was hit.",
            "banned": ["hit"],
            "expected": "ball"
        },
        {
            "paragraph": "a.",
            "banned": [],
            "expected": "a"
        },
        {
            "paragraph": "Bob. hIt, baLl",
            "banned": ["bob", "hit"],
            "expected": "ball"
        },
        {
            "paragraph": "a, a, a, a, b,b,b,c, c",
            "banned": ["a"],
            "expected": "b"
        },
        {
            "paragraph": "abc abc? abcd abc!",
            "banned": ["abcda"],
            "expected": "abc"
        }
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, test_case in enumerate(test_cases):
        paragraph = test_case["paragraph"]
        banned = test_case["banned"]
        expected = test_case["expected"]
        
        actual = mostCommonWord(paragraph, banned)
        
        if actual == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Expected: {expected}")
            print(f"  Actual:   {actual}")

    print(f"\n{num_correct}/{total_tests} correct")

if __name__ == "__main__":
    test_mostCommonWord()