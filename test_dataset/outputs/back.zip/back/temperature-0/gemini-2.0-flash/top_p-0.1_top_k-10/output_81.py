class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def print_tree(root):
    def get_height(node):
        if not node:
            return 0
        return 1 + max(get_height(node.left), get_height(node.right))

    def fill_array(node, arr, row, left, right):
        if not node:
            return
        mid = (left + right) // 2
        arr[row][mid] = str(node.val)
        fill_array(node.left, arr, row + 1, left, mid - 1)
        fill_array(node.right, arr, row + 1, mid + 1, right)

    height = get_height(root)
    width = 2 ** height - 1
    arr = [[""] * width for _ in range(height)]
    fill_array(root, arr, 0, 0, width - 1)
    return arr

def test_print_tree():
    test_cases = [
        (TreeNode(1, TreeNode(2)), [["", "1", ""], ["2", "", ""]]),
        (TreeNode(1, TreeNode(2, None, TreeNode(4)), TreeNode(3)), [["", "", "", "1", "", "", ""], ["", "2", "", "", "", "3", ""], ["", "", "4", "", "", "", ""]]),
        (TreeNode(1, TreeNode(2, TreeNode(3, TreeNode(4))), TreeNode(5)), [["", "", "", "", "", "", "", "1", "", "", "", "", "", "", ""], ["", "", "", "2", "", "", "", "", "", "", "", "5", "", "", ""], ["", "3", "", "", "", "", "", "", "", "", "", "", "", "", ""], ["4", "", "", "", "", "", "", "", "", "", "", "", "", "", ""]])
    ]

    num_tests = len(test_cases)
    num_correct = 0

    for i, (root, expected) in enumerate(test_cases):
        actual = print_tree(root)
        if actual == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print("Expected:")
            for row in expected:
                print(row)
            print("Actual:")
            for row in actual:
                print(row)

    print(f"{num_correct}/{num_tests}")

if __name__ == "__main__":
    test_print_tree()