def maxIncreaseKeepingSkyline(grid):
    """
    In a 2 dimensional array grid, each value grid[i][j] represents the height of a building located there.
    We are allowed to increase the height of any number of buildings, by any amount (the amounts can be different for different buildings). Height 0 is considered to be a building as well.
    At the end, the "skyline" when viewed from all four directions of the grid, i.e. top, bottom, left, and right, must be the same as the skyline of the original grid. A city's skyline is the outer contour of the rectangles formed by all the buildings when viewed from a distance. See the following example.

    What is the maximum total sum that the height of the buildings can be increased?

    Example:
    Input: grid = [[3,0,8,4],[2,4,5,7],[9,2,6,3],[0,3,1,0]]
    Output: 35
    Explanation:
    The grid is:
    [ [3, 0, 8, 4],
      [2, 4, 5, 7],
      [9, 2, 6, 3],
      [0, 3, 1, 0] ]
    The skyline viewed from top or bottom is: [9, 4, 8, 7]
    The skyline viewed from left or right is: [8, 7, 9, 3]
    The grid after increasing the height of buildings without affecting skylines is:
    gridNew = [ [8, 4, 8, 7],
                [7, 4, 7, 7],
                [9, 4, 8, 7],
                [3, 3, 3, 3] ]
    Notes:
    1 < grid.length = grid[0].length <= 50.

    All heights grid[i][j] are in the range [0, 100].

    All buildings in grid[i][j] occupy the entire grid cell: that is, they are a 1 x 1 x grid[i][j] rectangular prism.
    """
    n = len(grid)
    row_max = [0] * n
    col_max = [0] * n

    for i in range(n):
        for j in range(n):
            row_max[i] = max(row_max[i], grid[i][j])
            col_max[j] = max(col_max[j], grid[i][j])

    increase = 0
    for i in range(n):
        for j in range(n):
            increase += min(row_max[i], col_max[j]) - grid[i][j]

    return increase

def test_maxIncreaseKeepingSkyline():
    test_cases = [
        ([[3,0,8,4],[2,4,5,7],[9,2,6,3],[0,3,1,0]], 35),
        ([[0,0,0],[0,0,0],[0,0,0]], 0),
        ([[1,2],[3,4]], 0),
        ([[1]], 0),
        ([[100,100],[100,100]], 0)
    ]

    num_correct = 0
    for i, (grid, expected) in enumerate(test_cases):
        result = maxIncreaseKeepingSkyline(grid)
        if result == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: {grid}")
            print(f"  Expected: {expected}")
            print(f"  Got: {result}")

    print(f"\n{num_correct}/{len(test_cases)} correct")

if __name__ == "__main__":
    test_maxIncreaseKeepingSkyline()