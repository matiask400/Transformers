def shortest_subarray_to_remove(arr):
    """
    Given an integer array `arr`, remove a subarray (can be empty) from `arr` such that the remaining elements in `arr` are non-decreasing.
    A subarray is a contiguous subsequence of the array.
    Return the length of the shortest subarray to remove.
    """
    n = len(arr)
    if n <= 1:
        return 0

    # Find the length of the longest non-decreasing prefix
    left = 0
    while left < n - 1 and arr[left] <= arr[left + 1]:
        left += 1

    # If the entire array is non-decreasing, return 0
    if left == n - 1:
        return 0

    # Find the length of the longest non-decreasing suffix
    right = n - 1
    while right > 0 and arr[right - 1] <= arr[right]:
        right -= 1

    # Initialize the result with the length of the subarray to remove
    result = right - left - 1

    # Iterate through the prefix and suffix to find the shortest subarray to remove
    i = 0
    j = right
    while i <= left and j < n:
        if arr[i] <= arr[j]:
            result = min(result, j - i - 1)
            i += 1
        else:
            j += 1

    return result


def test_shortest_subarray_to_remove():
    test_cases = [
        ([1, 2, 3, 10, 4, 2, 3, 5], 3, "Test Case 1"),
        ([5, 4, 3, 2, 1], 4, "Test Case 2"),
        ([1, 2, 3], 0, "Test Case 3"),
        ([1], 0, "Test Case 4"),
        ([2, 2, 2, 1, 1, 1], 3, "Test Case 5"),
        ([1, 3, 2, 4, 5], 1, "Test Case 6"),
        ([1, 2, 3, 4, 5], 0, "Test Case 7"),
        ([5, 4, 3, 2, 1, 0], 5, "Test Case 8"),
        ([1, 2, 3, 4, 0], 1, "Test Case 9"),
        ([0, 1, 2, 3, 4], 0, "Test Case 10"),
        ([4, 3, 2, 1, 0], 4, "Test Case 11"),
        ([1, 2, 3, 0, 1, 2], 1, "Test Case 12"),
        ([1, 2, 0, 3, 4], 1, "Test Case 13"),
        ([1, 2, 3, 4, 5, 0], 1, "Test Case 14"),
        ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0], 1, "Test Case 15"),
        ([10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0], 10, "Test Case 16"),
        ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], 0, "Test Case 17"),
        ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 9], 1, "Test Case 18"),
        ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1], 9, "Test Case 19"),
        ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10], 0, "Test Case 20"),
        ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 0], 1, "Test Case 21")
    ]

    correct_count = 0
    total_count = len(test_cases)

    for arr, expected, test_name in test_cases:
        result = shortest_subarray_to_remove(arr)
        if result == expected:
            print(f"True")
            correct_count += 1
        else:
            print(f"False")

    print(f"{correct_count}/{total_count}")


if __name__ == "__main__":
    test_shortest_subarray_to_remove()