def ip_to_int(ip):
    parts = ip.split('.')
    result = 0
    for part in parts:
        result = (result << 8) + int(part)
    return result

def int_to_ip(ip_int):
    parts = []
    for i in range(4):
        parts.insert(0, str(ip_int & 255))
        ip_int >>= 8
    return '.'.join(parts)

def ip_to_cidr(ip, n):
    start = ip_to_int(ip)
    result = []
    while n > 0:
        mask = 32
        while mask > 0:
            masked_start = start & ((1 << mask) - 1) ^ start
            if masked_start != 0 or (n < (1 << (32 - mask))):
                mask -= 1
            else:
                break
        result.append(int_to_ip(start) + '/' + str(mask))
        start += (1 << (32 - mask))
        n -= (1 << (32 - mask))
    return result

def test_ip_to_cidr():
    test_cases = [
        {
            "ip": "255.0.0.7",
            "n": 10,
            "expected": ["255.0.0.7/32", "255.0.0.8/29", "255.0.0.16/32"]
        },
        {
            "ip": "1.2.3.4",
            "n": 1,
            "expected": ["1.2.3.4/32"]
        },
        {
            "ip": "1.2.3.4",
            "n": 2,
            "expected": ["1.2.3.4/31"]
        },
        {
            "ip": "1.2.3.4",
            "n": 4,
            "expected": ["1.2.3.4/30"]
        },
        {
            "ip": "1.2.3.4",
            "n": 8,
            "expected": ["1.2.3.4/29"]
        },
        {
            "ip": "1.2.3.4",
            "n": 16,
            "expected": ["1.2.3.4/28"]
        },
        {
            "ip": "1.2.3.4",
            "n": 32,
            "expected": ["1.2.3.4/27"]
        },
        {
            "ip": "1.2.3.4",
            "n": 64,
            "expected": ["1.2.3.4/26"]
        },
        {
            "ip": "1.2.3.4",
            "n": 128,
            "expected": ["1.2.3.4/25"]
        },
        {
            "ip": "1.2.3.4",
            "n": 256,
            "expected": ["1.2.3.4/24"]
        },
        {
            "ip": "1.2.3.4",
            "n": 512,
            "expected": ["1.2.3.4/23"]
        },
        {
            "ip": "1.2.3.4",
            "n": 1000,
            "expected": ['1.2.3.4/22', '1.2.7.0/29', '1.2.7.8/31', '1.2.7.10/31', '1.2.7.12/30', '1.2.7.16/32']
        },
        {
            "ip": "10.0.0.0",
            "n": 8,
            "expected": ["10.0.0.0/29"]
        },
        {
            "ip": "10.0.0.0",
            "n": 9,
            "expected": ["10.0.0.0/29", "10.0.0.8/32"]
        }
    ]

    correct_count = 0
    total_count = len(test_cases)

    for i, test_case in enumerate(test_cases):
        ip = test_case["ip"]
        n = test_case["n"]
        expected = test_case["expected"]
        actual = ip_to_cidr(ip, n)

        if actual == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False")
            print(f"  Input: ip={ip}, n={n}")
            print(f"  Expected: {expected}")
            print(f"  Actual: {actual}")

    print(f"\nCorrect: {correct_count}/{total_count}")

if __name__ == "__main__":
    test_ip_to_cidr()