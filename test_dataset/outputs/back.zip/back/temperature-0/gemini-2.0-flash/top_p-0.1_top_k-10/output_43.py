def num_times_all_blue(light):
    """
    Calculates the number of moments in which all turned on bulbs are blue.

    Args:
        light: A list of integers representing the order in which bulbs are turned on.

    Returns:
        The number of moments in which all turned on bulbs are blue.
    """
    n = len(light)
    turned_on = [False] * n
    count = 0
    max_bulb = 0
    for i in range(n):
        turned_on[light[i] - 1] = True
        max_bulb = max(max_bulb, light[i])
        all_blue = True
        for j in range(max_bulb):
            if not turned_on[j]:
                all_blue = False
                break
        if all_blue and sum(turned_on[:max_bulb]) == max_bulb:
            count += 1
    return count

def test_num_times_all_blue():
    """
    Tests the num_times_all_blue function with several test cases.
    """
    test_cases = [
        ([2, 1, 3, 5, 4], 3),
        ([3, 2, 4, 1, 5], 2),
        ([4, 1, 2, 3], 1),
        ([2, 1, 4, 3, 6, 5], 3),
        ([1, 2, 3, 4, 5, 6], 6),
        ([6,5,4,3,2,1], 1),
        ([1], 1),
        ([2,1], 1)
    ]

    num_correct = 0
    total_tests = len(test_cases)

    for i, (light, expected) in enumerate(test_cases):
        actual = num_times_all_blue(light)
        if actual == expected:
            print(f"Test {i+1}: True")
            num_correct += 1
        else:
            print(f"Test {i+1}: False (Input: {light}, Expected: {expected}, Actual: {actual})")

    print(f"\n{num_correct}/{total_tests} correct")

if __name__ == "__main__":
    test_num_times_all_blue()