import sys
import io

def largeGroupPositions(s: str) -> list[list[int]]:
    """
    Finds the start and end indices of all large groups in a string.
    A large group is a consecutive sequence of the same character with length 3 or more.

    Args:
        s: The input string of lowercase letters.

    Returns:
        A list of lists, where each inner list [start, end] represents the 
        interval of a large group, sorted by start index.
    """
    result = []
    n = len(s)
    if n < 3:
        return []

    i = 0
    while i < n:
        start = i
        current_char = s[i]
        
        # Find the end of the current group
        j = i
        while j < n and s[j] == current_char:
            j += 1
        
        # Calculate the length of the group
        length = j - start
        
        # If the group is large, add its interval to the result
        if length >= 3:
            result.append([start, j - 1])
            
        # Move the starting point for the next potential group
        i = j 
        
    return result

# --- Testing Framework ---

def run_tests():
    test_cases = [
        ("abbxxxxzzy", [[3, 6]]),
        ("abc", []),
        ("abcdddeeeeaabbbcd", [[3, 5], [6, 9], [12, 14]]),
        ("aba", []),
        ("aaa", [[0, 2]]),
        ("aaabbb", [[0, 2], [3, 5]]),
        ("babaaa", [[3, 5]]),
        ("nnnhaaannnm", [[0, 2], [6, 8]]),
        ("abcdddeeeeaabbbcddd", [[3, 5], [6, 9], [12, 14], [17, 19]]),
        ("a", []),
        ("aa", []),
        ("aaaaaaaaaa", [[0, 9]]), # 10 'a's
    ]

    correct_count = 0
    total_tests = len(test_cases)

    # Redirect stdout to capture print statements
    old_stdout = sys.stdout
    sys.stdout = captured_output = io.StringIO()

    for i, (input_s, expected_output) in enumerate(test_cases):
        result = largeGroupPositions(input_s)
        passed = (result == expected_output)
        print(passed)
        if passed:
            correct_count += 1

    # Restore stdout
    sys.stdout = old_stdout
    # Print captured output to screen
    print(captured_output.getvalue(), end="")

    # Print summary
    print(f"{correct_count}/{total_tests}")

if __name__ == "__main__":
    run_tests()