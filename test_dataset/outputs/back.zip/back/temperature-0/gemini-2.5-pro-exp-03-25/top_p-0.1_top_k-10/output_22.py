import collections
from typing import List

def uniqueOccurrences(arr: List[int]) -> bool:
    """
    Checks if the number of occurrences of each value in the array is unique.

    Args:
        arr: A list of integers.

    Returns:
        True if the number of occurrences of each value is unique, False otherwise.
    """
    # 1. Count the occurrences of each number
    counts = collections.Counter(arr)

    # 2. Get the frequencies (the counts themselves)
    frequencies = list(counts.values())

    # 3. Check if all frequencies are unique
    # We can do this by comparing the number of frequencies
    # with the number of unique frequencies (using a set)
    return len(frequencies) == len(set(frequencies))

# --- Testing Framework ---
def run_tests():
    """
    Runs predefined test cases against the uniqueOccurrences function.
    """
    test_cases = [
        # Input array, Expected output
        ([1, 2, 2, 1, 1, 3], True),
        ([1, 2], False),
        ([-3, 0, 1, -3, 1, 1, 1, -3, 10, 0], True),
        ([1], True),  # Single element array
        ([1, 1, 1], True), # All elements are the same
        ([1, 1, 2, 2], False), # Two pairs with same frequency
        ([1, 1, 2, 2, 3, 3], False), # Three pairs with same frequency
        ([4, 5, 6, 6], False), # One element unique, one pair
        ([26,2,16,16,5,5,26,2,5,20,20,5,2,20,2,16,20,16,17,16,2,16,20,26,16], False), # Provided complex case
        ([3,5,-2,-3,-6,-6], False), # Negative numbers and duplicates
    ]

    correct_count = 0
    total_tests = len(test_cases)

    print("Running tests...")
    for i, (arr_input, expected_output) in enumerate(test_cases):
        try:
            result = uniqueOccurrences(arr_input)
            passed = result == expected_output
            print(f"Test {i+1}: {passed}")
            if passed:
                correct_count += 1
        except Exception as e:
            print(f"Test {i+1}: Failed with error - {e}")

    print(f"\nResult: {correct_count}/{total_tests} tests passed.")

# --- Main Execution ---
if __name__ == "__main__":
    # Example usage (optional)
    # arr1 = [1, 2, 2, 1, 1, 3]
    # print(f"Input: {arr1}, Output: {uniqueOccurrences(arr1)}")
    # arr2 = [1, 2]
    # print(f"Input: {arr2}, Output: {uniqueOccurrences(arr2)}")

    # Run the automated tests
    run_tests()