import re
import collections
import sys
from io import StringIO

def solve():
    """
    Solves the most frequent non-banned word problem and runs tests.
    """

    def mostCommonWord(paragraph: str, banned: list[str]) -> str:
        """
        Finds the most frequent word in the paragraph that is not in the banned list.

        Args:
            paragraph: The input string paragraph.
            banned: A list of banned words.

        Returns:
            The most frequent non-banned word in lowercase.
        """
        # 1. Preprocess paragraph: lowercase, replace punctuation with space
        # The problem specifies only "!?',;." as punctuation.
        normalized_paragraph = paragraph.lower()
        for punc in "!?',;.":
            normalized_paragraph = normalized_paragraph.replace(punc, ' ')

        # 2. Split into words
        # split() handles multiple spaces between words correctly
        words = normalized_paragraph.split()

        # 3. Create banned set for efficient O(1) average time lookup
        banned_set = set(banned)

        # 4. Count frequencies of non-banned words
        word_counts = collections.Counter()
        for word in words:
            # The problem statement implies words are sequences of letters.
            # split() might produce empty strings if there are leading/trailing spaces
            # or multiple spaces together after punctuation replacement.
            # We only count actual words that are not banned.
            if word and word not in banned_set:
                word_counts[word] += 1

        # 5. Find the most frequent word
        # The problem guarantees at least one non-banned word and a unique answer.
        # Therefore, word_counts will not be empty.
        # most_common(1) returns a list containing the single most common element
        # as a tuple (element, count). We extract the element (the word).
        if not word_counts:
             # This case should not happen based on problem guarantees,
             # but included for robustness.
             return ""
        
        # Return the word part of the most common tuple
        return word_counts.most_common(1)[0][0]

    # Test cases
    tests = [
        {"input": {"paragraph": "Bob hit a ball, the hit BALL flew far after it was hit.", "banned": ["hit"]}, "expected": "ball"},
        {"input": {"paragraph": "a.", "banned": []}, "expected": "a"},
        {"input": {"paragraph": "Bob", "banned": []}, "expected": "bob"},
        {"input": {"paragraph": "a, a, a, a, b,b,b,c, c", "banned": ["a"]}, "expected": "b"},
        {"input": {"paragraph": "Bob? Hit? Ball!", "banned": ["hit"]}, "expected": "ball"},
        {"input": {"paragraph": "This is a test. This test is simple.", "banned": ["is", "a"]}, "expected": "test"},
        {"input": {"paragraph": " word ", "banned": []}, "expected": "word"}, # Test leading/trailing spaces
        {"input": {"paragraph": " L O L! ", "banned": ["l"]}, "expected": "o"}, # Test single letters and punctuation
        {"input": {"paragraph": "abc abc? abc! Abc. bcd BCD!", "banned": ["abc"]}, "expected": "bcd"}, # Test case sensitivity and punctuation mix
        {"input": {"paragraph": "...", "banned": []}, "expected": ""}, # Test only punctuation (should result in no valid words)
    ]

    correct_count = 0
    for i, test in enumerate(tests):
        inputs = test["input"]
        expected_output = test["expected"]
        # Redirect stdout to capture print statements if needed, though this function returns
        # old_stdout = sys.stdout
        # redirect_stdout = StringIO()
        # sys.stdout = redirect_stdout
        
        actual_output = mostCommonWord(inputs["paragraph"], inputs["banned"])
        
        # Restore stdout
        # sys.stdout = old_stdout
        # captured_output = redirect_stdout.getvalue()

        result = actual_output == expected_output
        print(f"Test {i + 1}: {result}")
        if result:
            correct_count += 1

    print(f"{correct_count}/{len(tests)} tests passed.")

# Execute the solve function
solve()