import sys
import io
from typing import List

# Define the function to be tested
def moveZeroes(nums: List[int]) -> None:
    """
    Do not return anything, modify nums in-place instead.
    Moves all 0's to the end of the list in-place, maintaining the relative order
    of the non-zero elements. Uses the two-pointer approach for minimal writes.
    """
    # write_pointer indicates the position where the next non-zero element should be placed.
    write_pointer = 0

    # First pass: Iterate through the array with a read_pointer.
    # Move all non-zero elements to the front of the array, maintaining their order.
    for read_pointer in range(len(nums)):
        # If the element at read_pointer is non-zero...
        if nums[read_pointer] != 0:
            # ...place it at the write_pointer position.
            # Optimization: If read_pointer and write_pointer are the same,
            # the non-zero element is already in its correct relative spot,
            # so we can avoid writing it over itself.
            if write_pointer != read_pointer:
                nums[write_pointer] = nums[read_pointer]
            # Increment write_pointer to position it for the next non-zero element.
            write_pointer += 1

    # Second pass: Fill the remaining positions with zeros.
    # All non-zero elements are now in nums[0...write_pointer-1].
    # The positions from write_pointer to the end of the array must be filled with zeros.
    for i in range(write_pointer, len(nums)):
        # Optimization: Only write if the element isn't already zero.
        # This slightly reduces writes if the tail already contained zeros.
        # However, the simpler nums[i] = 0 is also correct and common.
        # Let's use the simpler version for clarity and guaranteed O(n) writes total.
        nums[i] = 0


# Test runner function
def run_tests():
    """
    Runs predefined test cases against the moveZeroes function and prints the results.
    """
    test_cases = [
        # Input nums, Expected output nums after in-place modification
        ([0, 1, 0, 3, 12], [1, 3, 12, 0, 0]),
        ([0], [0]),
        ([1], [1]),
        ([1, 2, 3], [1, 2, 3]),
        ([0, 0, 0, 1], [1, 0, 0, 0]),
        ([1, 0, 2, 0, 3], [1, 2, 3, 0, 0]),
        ([], []), # Edge case: empty list
        ([0, 0, 0, 0], [0, 0, 0, 0]), # Edge case: all zeros
        ([2, 1], [2, 1]), # Edge case: no zeros
        ([-1, 0, 5, 0, -3], [-1, 5, -3, 0, 0]), # Negative numbers
        ([0, 0, 1, 0, 2, 0, 3, 0], [1, 2, 3, 0, 0, 0, 0, 0])
    ]

    correct_count = 0
    total_tests = len(test_cases)

    # Redirect stdout to capture prints within the loop for cleaner final output
    old_stdout = sys.stdout
    sys.stdout = captured_output = io.StringIO()

    for i, (nums_input, expected_output) in enumerate(test_cases):
        # Create a copy because moveZeroes modifies the list in-place
        # We need a fresh copy for each test run.
        nums_copy = list(nums_input)
        
        # Run the function to modify nums_copy in-place
        moveZeroes(nums_copy)
        
        # Compare the modified list with the expected output
        passed = nums_copy == expected_output
        
        # Print True or False for the current test
        print(passed) 
        
        if passed:
            correct_count += 1

    # Restore stdout
    sys.stdout = old_stdout

    # Print the captured output (True/False for each test) first
    print(captured_output.getvalue(), end="")

    # Print the final summary: number of correct tests / total tests
    print(f"{correct_count}/{total_tests}")

# Execute the tests when the script is run directly
if __name__ == "__main__":
    run_tests()