import sys
from typing import List

def eraseOverlapIntervals(intervals: List[List[int]]) -> int:
    """
    Given a collection of intervals, find the minimum number of intervals 
    you need to remove to make the rest of the intervals non-overlapping.

    Args:
        intervals: A list of lists, where each inner list represents an interval [start, end].

    Returns:
        The minimum number of intervals to remove.
    """
    if not intervals:
        return 0

    # Sort intervals based on their end points
    # This greedy approach works because by choosing the interval that finishes earliest,
    # we maximize the remaining time for subsequent intervals.
    intervals.sort(key=lambda x: x[1])

    n = len(intervals)
    count_kept = 1  # Keep the first interval (which finishes earliest)
    last_kept_end = intervals[0][1]

    for i in range(1, n):
        current_start = intervals[i][0]
        current_end = intervals[i][1]

        # If the current interval's start is greater than or equal to the
        # end of the last kept interval, it doesn't overlap.
        # We can keep this interval.
        if current_start >= last_kept_end:
            count_kept += 1
            last_kept_end = current_end
        # Else (current_start < last_kept_end), the current interval overlaps
        # with the last kept interval. Since we sorted by end times, the current
        # interval ends at or after the last kept one. To minimize removals (maximize kept),
        # we stick with the interval that finished earlier (the last_kept one)
        # and effectively "remove" the current one by not incrementing count_kept
        # and not updating last_kept_end.

    # The number of intervals to remove is the total number minus the maximum number we could keep.
    return n - count_kept

# --- Testing Framework ---

def run_tests():
    test_cases = [
        ([[1,2],[2,3],[3,4],[1,3]], 1),
        ([[1,2],[1,2],[1,2]], 2),
        ([[1,2],[2,3]], 0),
        ([], 0),
        ([[1,100],[2,3],[3,4],[4,5]], 1),
        ([[1,5],[2,4],[3,6]], 1), # Sort: [2,4], [1,5], [3,6]. Keep [2,4]. Skip [1,5]. Keep [3,6]? No, 3 < 4. Keep [2,4]. Remove 1. Wait, let's retrace.
                                  # Sort: [[2,4], [1,5], [3,6]]
                                  # Keep [2,4]. count=1, end=4.
                                  # Consider [1,5]. start=1. 1 < 4. Skip.
                                  # Consider [3,6]. start=3. 3 < 4. Skip.
                                  # Kept = 1. Removed = 3 - 1 = 2. Expected 1. What went wrong?
                                  # Ah, the greedy choice is *always* keep the one ending earliest if non-overlapping.
                                  # Sort: [[2,4], [1,5], [3,6]]
                                  # Keep [2,4]. count=1, end=4.
                                  # Consider [1,5]. start=1. 1 < 4. Skip.
                                  # Consider [3,6]. start=3. 3 < 4. Skip.
                                  # Result: 2 removed.
                                  # Let's try keeping [1,5] and [3,6]. They overlap.
                                  # Let's try keeping [2,4] and [3,6]. They overlap.
                                  # Let's try keeping [1,5]. Remove [2,4], [3,6]. Removed 2.
                                  # Let's try keeping [2,4]. Remove [1,5], [3,6]. Removed 2.
                                  # Let's try keeping [3,6]. Remove [1,5], [2,4]. Removed 2.
                                  # The example explanation must be wrong or my understanding.
                                  # Let's re-read the problem: "minimum number of intervals you need to remove"
                                  # Input: [[1,5],[2,4],[3,6]]
                                  # If we remove [1,5], we have [[2,4], [3,6]]. These overlap (4 > 3).
                                  # If we remove [2,4], we have [[1,5], [3,6]]. These overlap (5 > 3).
                                  # If we remove [3,6], we have [[1,5], [2,4]]. These overlap (5 > 2).
                                  # If we remove [1,5] and [3,6], we have [[2,4]]. Non-overlapping. Removed 2.
                                  # If we remove [1,5] and [2,4], we have [[3,6]]. Non-overlapping. Removed 2.
                                  # If we remove [2,4] and [3,6], we have [[1,5]]. Non-overlapping. Removed 2.
                                  # It seems the minimum number to remove is 2. Let's update the test case.
        ([[1,5],[2,4],[3,6]], 2),
        ([[0,2],[1,3],[2,4],[3,5],[4,6]], 2), # Sort: [0,2], [1,3], [2,4], [3,5], [4,6]
                                             # Keep [0,2]. count=1, end=2.
                                             # Consider [1,3]. start=1. 1 < 2. Skip.
                                             # Consider [2,4]. start=2. 2 >= 2. Keep. count=2, end=4.
                                             # Consider [3,5]. start=3. 3 < 4. Skip.
                                             # Consider [4,6]. start=4. 4 >= 4. Keep. count=3, end=6.
                                             # Kept = 3. Removed = 5 - 3 = 2. Correct.
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, (intervals, expected) in enumerate(test_cases):
        # Create a copy to avoid modifying the original test case list if the function mutates the input
        intervals_copy = [list(interval) for interval in intervals]
        result = eraseOverlapIntervals(intervals_copy)
        passed = result == expected
        print(f"Test {i+1}: {passed}")
        if passed:
            correct_count += 1
        # else:
        #     print(f"  Input: {intervals}")
        #     print(f"  Expected: {expected}")
        #     print(f"  Got: {result}")


    print(f"\nPassed {correct_count} out of {total_tests} tests.")

if __name__ == "__main__":
    run_tests()