import collections
from typing import List

def find_center(edges: List[List[int]]) -> int:
    """
    Finds the center of a star graph given its edges.

    A star graph has one central node connected to all other n-1 nodes.
    Every edge must include the center node. Therefore, the center node
    must be the node common to any two distinct edges. We only need to
    examine the first two edges.

    Args:
        edges: A list of edges, where each edge is a list of two connected nodes.
               It's guaranteed that the input represents a valid star graph.

    Returns:
        The label of the center node.
    """
    # Get the nodes from the first edge
    node1_edge1, node2_edge1 = edges[0]

    # Get the nodes from the second edge
    node1_edge2, node2_edge2 = edges[1]

    # The center node must be present in both edges.
    # Check if the first node of the first edge is present in the second edge.
    if node1_edge1 == node1_edge2 or node1_edge1 == node2_edge2:
        # If it is, then node1_edge1 is the center.
        return node1_edge1
    else:
        # Otherwise, the second node of the first edge (node2_edge1) must be the center.
        # This is because one of the nodes in the first edge *must* be the center,
        # and we've ruled out node1_edge1.
        return node2_edge1

# Test runner function
def run_tests():
    """
    Runs predefined test cases against the find_center function and prints results.
    Prints 'True' for passed tests, 'False' for failed tests, and a summary.
    """
    test_cases = [
        # Input: edges, Expected Output: center
        ([[1, 2], [2, 3], [4, 2]], 2),
        ([[1, 2], [5, 1], [1, 3], [1, 4]], 1),
        ([[10, 1], [1, 2], [1, 3], [1, 4], [1, 5], [1, 6], [1, 7], [1, 8], [1, 9]], 1), # n=10, center=1
        ([[2, 5], [1, 5], [5, 3], [5, 4]], 5), # n=5, center=5
        ([[3,1],[3,2],[3,4],[3,5]], 3), # n=5, center=3
        ([[1,100000],[2,100000]], 100000) # Large node value, n=3
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, (edges, expected_output) in enumerate(test_cases):
        result = find_center(edges)
        is_correct = (result == expected_output)
        print(f"{is_correct}") # Print True or False as requested
        if is_correct:
            correct_count += 1

    print(f"\n{correct_count} / {total_tests} correct tests.")

# Execute the tests when the script is run
if __name__ == "__main__":
    run_tests()