import collections

def solve():
    """
    Solves the Possible Bipartition problem using BFS-based graph coloring.
    """
    def possibleBipartition(N, dislikes):
        """
        Checks if N people can be split into two groups based on dislikes.

        Args:
            N: The number of people (1 to N).
            dislikes: A list of pairs [a, b] indicating person a dislikes person b.

        Returns:
            True if a valid two-group split is possible, False otherwise.
        """
        if not dislikes:
            return True # No dislikes means any split is possible

        # Build adjacency list representation of the graph
        # Use N+1 size to handle 1-based indexing easily
        adj = collections.defaultdict(list)
        for u, v in dislikes:
            adj[u].append(v)
            adj[v].append(u)

        # colors array: 0 = uncolored, 1 = group 1, -1 = group 2
        colors = [0] * (N + 1)

        for i in range(1, N + 1):
            # If person i is already colored, skip (part of a visited component)
            if colors[i] != 0:
                continue

            # Start BFS for this component
            colors[i] = 1 # Assign to group 1 initially
            queue = collections.deque([i])

            while queue:
                person = queue.popleft()
                current_color = colors[person]

                for neighbor in adj[person]:
                    if colors[neighbor] == 0:
                        # If neighbor is uncolored, assign the opposite color
                        colors[neighbor] = -current_color
                        queue.append(neighbor)
                    elif colors[neighbor] == current_color:
                        # If neighbor has the same color, conflict found
                        return False
                    # If neighbor has the opposite color, it's fine, continue

        # If BFS completes for all components without conflict
        return True

    # --- Test Cases ---
    test_cases = [
        (4, [[1,2],[1,3],[2,4]], True),
        (3, [[1,2],[1,3],[2,3]], False),
        (5, [[1,2],[2,3],[3,4],[4,5],[1,5]], False),
        (1, [], True),
        (2, [[1,2]], True),
        (10, [[1,2],[3,4],[5,6],[7,8],[9,10]], True), # Disconnected components
        (10, [[1,2],[2,3],[3,4],[4,5],[5,6],[6,7],[7,8],[8,9],[9,10],[10,1]], False), # 10-cycle (even) -> Bipartite
        (10, [[4,7],[4,8],[5,6],[1,6],[3,7],[2,5],[5,8],[1,2],[4,9],[6,10],[8,10],[3,6],[2,10],[9,10],[3,9],[2,3],[1,9],[4,6],[5,7],[3,8],[1,8],[1,7],[2,4]], False), # More complex graph
        (6, [[1,2],[1,3],[4,5],[4,6]], True), # Two separate bipartite components
        (5, [[1,2],[3,4],[1,5],[2,5]], False), # Component 1: 1-2, 1-5, 2-5 (odd cycle 1-2-5-1)
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, (N, dislikes, expected) in enumerate(test_cases):
        result = possibleBipartition(N, dislikes)
        if result == expected:
            print(f"Test {i+1}: True")
            correct_count += 1
        else:
            print(f"Test {i+1}: False") # Expected {expected}, Got {result}") # Optional: print details on failure

    print(f"{correct_count}/{total_tests} tests passed.")

# Execute the solver function that includes the tests
solve()