import collections
import sys

# Set higher recursion depth for potential large inputs (though not strictly needed for this iterative solution)
# sys.setrecursionlimit(3000) 

def subarraysDivByK(A, K):
    """
    Given an array A of integers, return the number of (contiguous, non-empty) 
    subarrays that have a sum divisible by K.

    Args:
        A: A list of integers.
        K: An integer divisor.

    Returns:
        The number of subarrays whose sum is divisible by K.
    """
    n = len(A)
    # Use a dictionary (or hash map) to store the frequency of prefix sum remainders.
    # Initialize with remainder 0 having a count of 1, representing the empty prefix sum (before index 0).
    remainder_counts = collections.defaultdict(int)
    remainder_counts[0] = 1
    
    current_sum = 0
    count = 0

    for x in A:
        current_sum += x
        
        # Calculate the remainder of the current prefix sum.
        # We use (current_sum % K + K) % K to handle potential negative results 
        # from the modulo operator in Python consistently, ensuring remainders are in [0, K-1].
        remainder = (current_sum % K + K) % K
        
        # If a prefix sum with the same remainder `remainder` has been seen before,
        # say at index i-1, then the subarray sum from index i to the current index j
        # (which is P[j] - P[i-1]) must be divisible by K.
        # The number of such previous occurrences is remainder_counts[remainder].
        # Add this number to our total count.
        count += remainder_counts[remainder]
        
        # Increment the frequency count for the current remainder.
        remainder_counts[remainder] += 1
            
    return count

def run_tests():
    """
    Runs predefined test cases against the subarraysDivByK function and prints the results.
    """
    test_cases = [
        # Example 1 from description
        {'input': {'A': [4, 5, 0, -2, -3, 1], 'K': 5}, 'expected': 7},
        # Single element divisible by K
        {'input': {'A': [5], 'K': 5}, 'expected': 1},
        # Single element not divisible by K
        {'input': {'A': [3], 'K': 5}, 'expected': 0},
        # Array with negative numbers
        {'input': {'A': [-1, 2, 9], 'K': 2}, 'expected': 2}, # Subarrays: [2] (sum 2), [-1, 2, 9] (sum 10)
        # Another case with negative numbers
        {'input': {'A': [2, -2, 2, -4], 'K': 6}, 'expected': 2}, # Subarrays: [2, -2] (sum 0), [-2, 2] (sum 0)
        # All zeros
        {'input': {'A': [0, 0, 0], 'K': 3}, 'expected': 6}, # [0], [0], [0], [0,0], [0,0], [0,0,0]
        # Larger K
        {'input': {'A': [1, 2, 3, 4, 5], 'K': 3}, 'expected': 4}, # [3], [1,2], [4,5], [1,2,3] (sums: 3, 3, 9, 6)
        # No divisible subarrays
        {'input': {'A': [1, 1, 1], 'K': 2}, 'expected': 0},
        # Empty array (edge case, though constraints say length >= 1)
        # {'input': {'A': [], 'K': 5}, 'expected': 0}, # Handled correctly by the code (loop won't run)
        # Large numbers
        {'input': {'A': [10000, -10000, 5000, -5000], 'K': 10000}, 'expected': 3}, # [10000], [-10000], [5000, -5000] (sums: 10k, -10k, 0) -> only [5000,-5000] sum=0 is divisible by 10k? No, 10k%10k=0, -10k%10k=0. So 3. Let's trace:
        # P[0]=10k, rem=0. count+=rem_counts[0]=1. rem_counts={0:2}. count=1.
        # P[1]=0, rem=0. count+=rem_counts[0]=2. rem_counts={0:3}. count=1+2=3.
        # P[2]=5k, rem=5k. count+=rem_counts[5k]=0. rem_counts={0:3, 5k:1}. count=3.
        # P[3]=0, rem=0. count+=rem_counts[0]=3. rem_counts={0:4, 5k:1}. count=3+3=6.
        # Let's re-evaluate [10000, -10000, 5000, -5000], K=10000
        # Subarrays:
        # [10000] sum=10k, 10k%10k=0. Yes (1)
        # [10000, -10000] sum=0, 0%10k=0. Yes (2)
        # [10000, -10000, 5000] sum=5k, 5k%10k!=0. No
        # [10000, -10000, 5000, -5000] sum=0, 0%10k=0. Yes (3)
        # [-10000] sum=-10k, -10k%10k=0. Yes (4)
        # [-10000, 5000] sum=-5k, -5k%10k!=0. No
        # [-10000, 5000, -5000] sum=-10k, -10k%10k=0. Yes (5)
        # [5000] sum=5k, 5k%10k!=0. No
        # [5000, -5000] sum=0, 0%10k=0. Yes (6)
        # [-5000] sum=-5k, -5k%10k!=0. No
        # Expected should be 6. Let's update the test case.
        {'input': {'A': [10000, -10000, 5000, -5000], 'K': 10000}, 'expected': 6}, 
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, test in enumerate(test_cases):
        A_input = test['input']['A']
        K_input = test['input']['K']
        expected_output = test['expected']
        
        # Make a copy if the function modifies the input, though this one doesn't
        # A_copy = list(A_input) 
        
        result = subarraysDivByK(A_input, K_input)
        
        passed = result == expected_output
        print(f"Test {i + 1}: {passed}")
        # Optional: print details on failure
        # if not passed:
        #     print(f"  Input A: {A_input}, K: {K_input}")
        #     print(f"  Expected: {expected_output}")
        #     print(f"  Got: {result}")
            
        if passed:
            correct_count += 1

    print(f"{correct_count}/{total_tests} tests passed.")

# Execute the tests when the script is run
if __name__ == "__main__":
    run_tests()