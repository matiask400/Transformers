import math

def findMedianSortedArrays(nums1, nums2):
    """
    Finds the median of two sorted arrays.

    Args:
        nums1: The first sorted list of numbers.
        nums2: The second sorted list of numbers.

    Returns:
        The median of the combined sorted array as a float.
    """
    m = len(nums1)
    n = len(nums2)

    # Ensure nums1 is the shorter array for optimization
    if m > n:
        nums1, nums2 = nums2, nums1
        m, n = n, m

    low = 0
    high = m
    total_len = m + n
    half_len = (total_len + 1) // 2 # For both odd and even total lengths

    while low <= high:
        partition1 = (low + high) // 2
        partition2 = half_len - partition1

        # Get elements around the partition points, handling edge cases
        max_left1 = nums1[partition1 - 1] if partition1 > 0 else float('-inf')
        min_right1 = nums1[partition1] if partition1 < m else float('inf')

        max_left2 = nums2[partition2 - 1] if partition2 > 0 else float('-inf')
        min_right2 = nums2[partition2] if partition2 < n else float('inf')

        # Check if the partition is correct
        if max_left1 <= min_right2 and max_left2 <= min_right1:
            # Found the correct partition
            if total_len % 2 == 1:
                # Odd total length, median is the max of the left parts
                return float(max(max_left1, max_left2))
            else:
                # Even total length, median is the average of the max of left
                # and min of right parts
                return (max(max_left1, max_left2) + min(min_right1, min_right2)) / 2.0
        elif max_left1 > min_right2:
            # partition1 is too large, move left in nums1
            high = partition1 - 1
        else: # max_left2 > min_right1
            # partition1 is too small, move right in nums1
            low = partition1 + 1

    # Should not be reached if inputs are valid sorted arrays
    raise ValueError("Input arrays are not sorted or other error occurred")


# --- Testing ---
def run_tests():
    test_cases = [
        ([1, 3], [2], 2.0),
        ([1, 2], [3, 4], 2.5),
        ([0, 0], [0, 0], 0.0),
        ([], [1], 1.0),
        ([2], [], 2.0),
        ([1], [1], 1.0),
        ([1, 2, 3], [4, 5, 6], 3.5),
        ([1, 3, 5, 7], [2, 4, 6, 8], 4.5),
        ([1, 1, 1], [1, 1, 1], 1.0),
        ([10], [1, 2, 3, 4, 5, 6, 7, 8, 9], 5.5),
        ([1, 2, 3, 4, 5], [6, 7, 8, 9, 10], 5.5),
        ([3], [-2, -1], -1.0),
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, (nums1, nums2, expected) in enumerate(test_cases):
        result = findMedianSortedArrays(list(nums1), list(nums2)) # Pass copies
        # Use math.isclose for floating point comparison
        passed = math.isclose(result, expected, rel_tol=1e-5)
        print(f"{passed}")
        if passed:
            correct_count += 1
        # else:
        #     print(f"Test Case {i+1} Failed:")
        #     print(f"  Input: nums1={nums1}, nums2={nums2}")
        #     print(f"  Expected: {expected}")
        #     print(f"  Got: {result}")


    print(f"{correct_count}/{total_tests}")

# Execute the tests
run_tests()