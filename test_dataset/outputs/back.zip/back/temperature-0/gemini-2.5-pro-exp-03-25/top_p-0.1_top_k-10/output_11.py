import sys
import io

def solve():
    """
    Implements the regular expression matching logic using dynamic programming.
    """
    def isMatch(s: str, p: str) -> bool:
        m, n = len(s), len(p)
        
        # dp[i][j] will be True if the first i characters of s
        # match the first j characters of p
        dp = [[False] * (n + 1) for _ in range(m + 1)]
        
        # Base case: empty string matches empty pattern
        dp[0][0] = True
        
        # Handle patterns like a*, a*b*, .* that can match an empty string
        # dp[0][j] corresponds to matching empty string s with pattern p[:j]
        for j in range(1, n + 1):
            # The j-th character in p is p[j-1]
            if p[j-1] == '*':
                # If we see a '*', it depends on the pattern two steps back
                # because '*' must follow a character.
                # dp[0][j-2] means the pattern p[:j-2] matched the empty string.
                # The x* part matches zero occurrences of x.
                if j >= 2:
                     dp[0][j] = dp[0][j-2]
                # else: if j=1, p[0] cannot be '*', based on constraints.
                # If j=1 and p[0] was '*', dp[0][1] would remain False.

        # Fill the rest of the dp table
        for i in range(1, m + 1):
            for j in range(1, n + 1):
                # Current characters: s[i-1] and p[j-1]
                
                # Case 1: The current pattern character p[j-1] is '.' or matches s[i-1]
                if p[j-1] == '.' or p[j-1] == s[i-1]:
                    # The result depends on whether the prefixes s[:i-1] and p[:j-1] matched
                    dp[i][j] = dp[i-1][j-1]
                    
                # Case 2: The current pattern character p[j-1] is '*'
                elif p[j-1] == '*':
                    # '*' must have a preceding character p[j-2]
                    
                    # Option 1: The x* matches zero occurrences of x (p[j-2]).
                    # In this case, the match depends on whether s[:i] matches p[:j-2].
                    if j >= 2:
                        dp[i][j] = dp[i][j-2]
                    
                    # Option 2: The x* matches one or more occurrences of x (p[j-2]).
                    # This is only possible if the current character s[i-1] matches x (p[j-2]).
                    # If it matches, the result depends on whether s[:i-1] matches p[:j]
                    # (because the '*' could potentially match more characters in s).
                    if j >= 2 and (p[j-2] == '.' or p[j-2] == s[i-1]):
                         dp[i][j] = dp[i][j] or dp[i-1][j]
                         
                # Case 3: The current pattern character p[j-1] is a letter
                # but does not match s[i-1], and it's not a '*'
                else:
                    # Mismatch, dp[i][j] remains False
                    dp[i][j] = False
                    
        return dp[m][n]

    # --- Test Runner ---
    def run_tests():
        test_cases = [
            ("aa", "a", False),
            ("aa", "a*", True),
            ("ab", ".*", True),
            ("aab", "c*a*b", True),
            ("mississippi", "mis*is*p*.", False),
            ("", "", True),
            ("a", "", False),
            ("", "a", False),
            ("", "a*", True),
            ("", ".*", True),
            ("", ".+", False), # '+' is not part of this problem, but good to consider similar cases
            ("a", "ab*", True), # b* matches zero 'b's
            ("a", "ab*a", False),
            ("bbbba", ".*a*a", True),
            ("ab", ".*c", False),
            ("aaa", "a*a", True),
            ("aaa", "ab*a*c*a", True),
            ("abcd", "d*", False),
            ("abc", ".*", True),
            ("aaaaaaaaaaaaab", "a*a*a*a*a*a*a*a*a*a*c", False), # Mismatch at the end
             ("aaaaaaaaaaaaab", "a*a*a*a*a*a*a*a*a*a*b", True), # Match
        ]

        correct_count = 0
        total_tests = len(test_cases)

        # Redirect stdout to capture print statements
        old_stdout = sys.stdout
        sys.stdout = captured_output = io.StringIO()

        for i, (s, p, expected) in enumerate(test_cases):
            result = isMatch(s, p)
            passed = result == expected
            print(passed)
            if passed:
                correct_count += 1

        # Restore stdout
        sys.stdout = old_stdout
        output_str = captured_output.getvalue()

        # Print captured output to the actual console
        print(output_str, end="")
        # Print the final summary
        print(f"{correct_count}/{total_tests}")

    run_tests()

# Execute the solve function
solve()