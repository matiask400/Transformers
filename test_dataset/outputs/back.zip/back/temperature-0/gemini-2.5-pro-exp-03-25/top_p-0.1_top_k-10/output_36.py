import sys

def solve():
    """
    Solves the problem: Given an integer n, add a dot (".") as the thousands separator
    and return it in string format.
    """

    def format_number(n: int) -> str:
        """
        Adds a dot (".") as the thousands separator to a non-negative integer.

        Args:
            n: A non-negative integer (0 <= n < 2^31).

        Returns:
            The integer formatted as a string with dots as thousands separators.
        """
        # Handle the base case of 0
        if n == 0:
            return "0"

        # Use Python's built-in formatting with comma as separator
        # Then replace the comma with a dot
        formatted_string = f"{n:,}".replace(",", ".")
        return formatted_string

    # --- Test Runner ---
    # Add UTF-8 encoding support for print
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')
    if sys.stderr.encoding != 'utf-8':
        sys.stderr.reconfigure(encoding='utf-8')

    test_cases = [
        # Input n, Expected Output
        (987, "987"),
        (1234, "1.234"),
        (12345, "12.345"),
        (123456, "123.456"),
        (1234567, "1.234.567"),
        (12345678, "12.345.678"),
        (123456789, "123.456.789"),
        (0, "0"),
        (1000, "1.000"),
        (999999, "999.999"),
        (1000000, "1.000.000"),
        (2**31 - 1, "2.147.483.647"), # Max value constraint test
        (1, "1"),
        (10, "10"),
        (100, "100"),
        (1001, "1.001"),
        (10000, "10.000"),
        (100000, "100.000"),
    ]

    correct_count = 0
    total_tests = len(test_cases)

    for i, (input_n, expected_output) in enumerate(test_cases):
        try:
            actual_output = format_number(input_n)
            result = actual_output == expected_output
            print(f"{result}")
            if result:
                correct_count += 1
        except Exception as e:
            print(f"False  # Error during test {i+1} for input {input_n}: {e}")

    print(f"\n{correct_count}/{total_tests}")

# Execute the solution function directly
solve()