import sys 
# Setting a higher recursion depth is generally not needed for this iterative solution
# but can be uncommented if stack depth issues arise in specific environments,
# though highly unlikely for this problem constraints.
# sys.setrecursionlimit(2000) 

def removeOuterParentheses(S: str) -> str:
    """
    Removes the outermost parentheses of every primitive string in the
    primitive decomposition of a valid parentheses string S.

    A valid parentheses string is primitive if it is nonempty, and there does not 
    exist a way to split it into S = A+B, with A and B nonempty valid parentheses strings.
    The primitive decomposition of S is S = P_1 + P_2 + ... + P_k, where P_i are 
    primitive valid parentheses strings.

    This function identifies the characters belonging to the inner parts of these
    primitive components and concatenates them.

    Args:
        S: A valid parentheses string.

    Returns:
        The modified string after removing outermost parentheses of primitive components.
    """
    res = []  # Use a list to collect characters for efficient appending
    balance = 0 # Counter to track the balance of parentheses
    
    for char in S:
        if char == '(':
            # If the balance is greater than 0, this opening parenthesis is not
            # the outermost one of a primitive component. Include it in the result.
            if balance > 0:
                res.append(char)
            # Increment balance for an opening parenthesis
            balance += 1
        else: # char == ')'
            # Decrement balance for a closing parenthesis *before* checking
            balance -= 1
            # If the balance is still greater than 0 after decrementing, this closing
            # parenthesis is not the outermost one of a primitive component. Include it.
            if balance > 0:
                res.append(char)
                
    # Join the collected characters to form the final result string
    return "".join(res)

# Define the test cases based on the examples and edge cases
test_cases = [
    {"input": "(()())(())", "expected_output": "()()()"},
    {"input": "(()())(())(()(()))", "expected_output": "()()()()(())"},
    {"input": "()()", "expected_output": ""},
    {"input": "()", "expected_output": ""},
    {"input": "(())", "expected_output": "()"},
    {"input": "", "expected_output": ""}, # Edge case: empty string
    {"input": "((()))", "expected_output": "(())"}, # Single primitive component
    {"input": "()(())", "expected_output": "()"}, # Decomposition: "()" + "(())" -> "" + "()" = "()"
    {"input": "(())(()())", "expected_output": "()()()"}, # Decomposition: "(())" + "(()())" -> "()" + "()()" = "()()()"
]

# Function to run the tests
def run_tests():
    """
    Runs the predefined test cases against the removeOuterParentheses function
    and prints the results, indicating pass ('True') or fail ('False') for each test,
    followed by a summary of the total passed tests.
    """
    correct_count = 0
    total_tests = len(test_cases)

    print("Running tests...")
    for i, test in enumerate(test_cases):
        input_str = test["input"]
        expected = test["expected_output"]
        
        # Execute the function under test
        try:
            result = removeOuterParentheses(input_str)
            # Compare the result with the expected output
            if result == expected:
                print(f"Test {i+1}: True")
                correct_count += 1
            else:
                print(f"Test {i+1}: False")
                # Uncomment the following lines to print details for failed tests
                # print(f"  Input: '{input_str}'")
                # print(f"  Expected: '{expected}'")
                # print(f"  Got: '{result}'")
        except Exception as e:
            print(f"Test {i+1}: Error - {e}")
            # print(f"  Input: '{input_str}'")


    # Print the final summary
    print(f"\n{correct_count}/{total_tests} tests passed.")

# Main execution block to run the tests when the script is executed
if __name__ == "__main__":
    run_tests()