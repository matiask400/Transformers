import collections
from typing import List, Optional

# Definition for a binary tree node.
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

    def __repr__(self):
        # Helper for debugging, represents the node and its direct children
        left_val = self.left.val if self.left else 'None'
        right_val = self.right.val if self.right else 'None'
        return f"Node({self.val}, L:{left_val}, R:{right_val})"

# Helper function to build a tree from a list (level-order with nulls)
def build_tree(nodes: List[Optional[int]]) -> Optional[TreeNode]:
    if not nodes:
        return None
    
    root = TreeNode(nodes[0])
    queue = collections.deque([root])
    i = 1
    while queue and i < len(nodes):
        current_node = queue.popleft()
        
        # Process left child
        if i < len(nodes) and nodes[i] is not None:
            left_child = TreeNode(nodes[i])
            current_node.left = left_child
            queue.append(left_child)
        i += 1
        
        # Process right child
        if i < len(nodes) and nodes[i] is not None:
            right_child = TreeNode(nodes[i])
            current_node.right = right_child
            queue.append(right_child)
        i += 1
            
    return root

# Helper function to convert a tree to a list (level-order with nulls, trimmed)
def tree_to_list(root: Optional[TreeNode]) -> List[Optional[int]]:
    if not root:
        return []
    
    result = []
    queue = collections.deque([root])
    
    while queue:
        node = queue.popleft()
        if node:
            result.append(node.val)
            # Important: Add children to queue even if they are None,
            # to maintain structure, but only if there might be nodes
            # further down. We'll handle trailing Nones later.
            queue.append(node.left)
            queue.append(node.right)
        else:
            result.append(None)
            
    # Trim trailing Nones
    while result and result[-1] is None:
        result.pop()
        
    return result

class Solution:
    def pruneTree(self, root: Optional[TreeNode]) -> Optional[TreeNode]:
        """
        Recursively prunes the tree. A node is kept if it's a 1,
        or if either of its subtrees (after pruning) contains a 1.
        Returns the potentially pruned node, or None if the entire
        subtree rooted at the original node should be removed.
        """
        if not root:
            return None

        # Recursively prune left and right subtrees
        root.left = self.pruneTree(root.left)
        root.right = self.pruneTree(root.right)

        # Check if the current node should be pruned
        # A node should be pruned if it's a 0 AND both its children are None
        # (meaning their subtrees didn't contain any 1s)
        if root.val == 0 and root.left is None and root.right is None:
            return None  # Prune this node
        else:
            return root  # Keep this node

# --- Test Framework ---

def run_tests():
    solver = Solution()
    
    test_cases = [
        # Input list, Expected output list
        ([1,None,0,0,1], [1,None,0,None,1]),
        ([1,0,1,0,0,0,1], [1,None,1,None,1]),
        ([1,1,0,1,1,0,1,0], [1,1,0,1,1,None,1]),
        ([0,None,0,0,0], []), # Tree with only 0s gets completely pruned
        ([1], [1]),
        ([0], []),
        ([], []),
        ([1,0,0,0,0], [1]),
        ([1,1,1,1,1], [1,1,1,1,1]),
        ([0,0,1], [0,None,1]), # Root 0 is kept because right child has 1
        ([1,None,0,None,1,None,0], [1,None,0,None,1]), # Test deeper pruning
    ]
    
    correct_count = 0
    total_tests = len(test_cases)
    
    for i, (input_list, expected_list) in enumerate(test_cases):
        # Build tree from input list
        root = build_tree(input_list)
        
        # Apply the pruneTree function
        pruned_root = solver.pruneTree(root)
        
        # Convert the result tree back to a list
        result_list = tree_to_list(pruned_root)
        
        # Compare result list with expected list
        passed = (result_list == expected_list)
        print(f"Test {i+1}: {passed}")
        if passed:
            correct_count += 1
            
    print(f"\nResult: {correct_count} / {total_tests} tests passed.")

# Execute the tests
if __name__ == "__main__":
    run_tests()