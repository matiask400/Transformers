import sys 

def balancedStringSplit(s: str) -> int:
    """
    Given a balanced string s, split it into the maximum number of balanced strings.
    A balanced string has an equal quantity of 'L' and 'R' characters.
    Return the maximum number of such balanced substrings s can be split into.

    Args:
        s: A balanced string consisting of 'L' and 'R' characters. 
           Constraints: 1 <= s.length <= 1000, s[i] is 'L' or 'R', s is balanced.

    Returns:
        The maximum number of balanced strings s can be split into.
    """
    balance = 0  # Tracks the balance of 'R' vs 'L' characters. +1 for R, -1 for L.
    count = 0    # Counts the number of balanced substrings found.
    
    # Iterate through the string character by character
    for char in s:
        # Update the balance based on the current character
        if char == 'L':
            balance -= 1
        elif char == 'R':
            balance += 1
        
        # When balance returns to 0, it signifies the end of a balanced